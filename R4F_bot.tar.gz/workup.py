"""What a finding typically prompts next — gated on how much the finding is
worth believing.

This feature sits DOWNSTREAM OF THE LEAST RELIABLE PART OF THE PIPELINE. A
hallucinated "mass" would otherwise produce a confident, well-formatted biopsy
recommendation, which is worse than producing nothing. So:

  * Workup only renders for findings that clear a confidence bar — committee
    agreement where there is a committee, self-reported confidence otherwise.
  * Curated steps are keyed on a controlled English category, not the free-text
    finding name, so the lookup works when the reply language is Russian.
  * Every step is framed as what such a finding typically prompts and what to
    raise with a treating clinician. Never as an instruction to a patient.
  * Steps sourced from the curated table are marked with the framework they come
    from; steps invented by the model are marked as such and are worth less.

The curated table is deliberately qualitative. Numeric thresholds (nodule sizes
under Fleischner, BI-RADS categories) are omitted on purpose: they depend on
measurements this pipeline cannot make from a screenshot, and a confidently
wrong threshold is worse than a pointer to the framework that owns it.
"""
from dataclasses import dataclass

# Controlled vocabulary the model classifies findings into. English regardless
# of reply language, which is what makes the lookup work — the same trick as
# REGIONS in profiles.py.
CATEGORIES = (
    "mass", "nodule", "cyst", "oedema", "haemorrhage", "infarct",
    "consolidation", "effusion", "calcification", "asymmetry",
    "architectural_distortion", "fracture", "lymphadenopathy",
    "atrophy", "hydrocephalus", "obstruction", "inflammation",
    "degenerative_change", "device_or_foreign_body", "other",
)


@dataclass(frozen=True)
class Step:
    step: str
    rationale: str
    guideline: str = ""
    source: str = "guideline"   # "guideline" (curated) or "model"


# Keyed on (modality, category). "*" matches any modality.
# ACR AC = ACR Appropriateness Criteria, the general evidence base for
# "given this finding, which study next".
CURATED: dict = {
    # --- Brain -----------------------------------------------------------
    ("CT", "mass"): (
        Step("MRI of the brain, with and without contrast",
             "MRI resolves soft-tissue character, enhancement and margins that "
             "CT cannot, and is the standard problem-solver for an "
             "indeterminate intracranial lesion.", "ACR AC"),
        Step("Tissue diagnosis (biopsy or resection) if imaging stays indeterminate",
             "Imaging narrows the differential but rarely settles it; histology "
             "is what establishes the diagnosis.", "ACR AC"),
    ),
    ("CT", "oedema"): (
        Step("MRI with contrast to look for an underlying cause",
             "Oedema is usually a secondary sign. The question is what is "
             "producing it — tumour, infection, infarct, or venous cause.",
             "ACR AC"),
        Step("Consider CT/MR venography if the distribution is non-arterial",
             "Venous infarction and sinus thrombosis produce oedema that does "
             "not respect arterial territories.", "ACR AC"),
    ),
    ("CT", "haemorrhage"): (
        Step("Urgent clinical assessment — this is a time-critical pathway",
             "Management of intracranial blood is driven by clinical status, "
             "anticoagulation, and timing, not by the image alone.", "ACR AC"),
        Step("CT angiography to look for a vascular cause",
             "Aneurysm, AVM or other vascular malformation changes management "
             "entirely.", "ACR AC"),
        Step("Interval non-contrast CT to assess stability",
             "Expansion in the first hours is common and changes decisions.",
             "ACR AC"),
    ),
    ("CT", "infarct"): (
        Step("Urgent stroke pathway assessment if this is acute",
             "Treatment is time-dependent and decided clinically; imaging is one "
             "input among several.", "ACR AC"),
        Step("Vascular imaging (CTA head and neck) and often MRI with DWI",
             "DWI is far more sensitive than CT for early ischaemia, and vessel "
             "imaging identifies a treatable occlusion or stenosis.", "ACR AC"),
    ),
    ("MRI", "mass"): (
        Step("Complete the multi-sequence study, with and without contrast",
             "A single sequence cannot characterise a lesion; enhancement "
             "pattern and diffusion behaviour carry most of the information.",
             "ACR AC"),
        Step("Advanced sequences (perfusion, spectroscopy) where available",
             "These help separate tumour from mimics such as abscess or "
             "demyelination.", "ACR AC"),
        Step("Multidisciplinary discussion and tissue diagnosis",
             "Definitive characterisation of an intracranial mass is "
             "histological.", "ACR AC"),
    ),

    # --- Chest -----------------------------------------------------------
    ("CT", "nodule"): (
        Step("Size- and risk-based follow-up under the Fleischner criteria",
             "Management is driven by nodule size, solid versus subsolid "
             "character, and patient risk — none of which can be measured "
             "reliably from a screenshot.", "Fleischner Society"),
        Step("PET-CT for larger or suspicious solid nodules",
             "Metabolic activity helps stratify risk before considering "
             "sampling.", "ACR AC"),
        Step("Tissue sampling if features or growth are suspicious",
             "Biopsy is what converts a suspicious nodule into a diagnosis.",
             "ACR AC"),
    ),
    ("X-ray", "nodule"): (
        Step("CT of the chest to characterise",
             "A radiograph cannot establish size, margins or density "
             "adequately; CT is the next step for any indeterminate opacity.",
             "ACR AC"),
    ),
    ("X-ray", "consolidation"): (
        Step("Correlate clinically and treat on clinical grounds",
             "Consolidation is a pattern, not a diagnosis — infection, "
             "infarction, haemorrhage and malignancy can all produce it."),
        Step("Follow-up radiograph to confirm resolution",
             "Non-resolving consolidation raises the question of an underlying "
             "obstructing lesion.", "ACR AC"),
        Step("CT if it fails to resolve",
             "To exclude an endobronchial or parenchymal cause.", "ACR AC"),
    ),
    ("CT", "consolidation"): (
        Step("Correlate clinically; consider follow-up to resolution",
             "The imaging pattern rarely distinguishes infective from "
             "non-infective causes on its own.", "ACR AC"),
    ),
    ("*", "effusion"): (
        Step("Ultrasound assessment, and diagnostic sampling if new or unexplained",
             "Ultrasound characterises the fluid and guides safe aspiration; "
             "the fluid analysis is what gives the diagnosis.", "ACR AC"),
    ),
    ("*", "lymphadenopathy"): (
        Step("Assess size, shape and distribution across the full study",
             "Short-axis size and loss of the fatty hilum matter more than "
             "presence alone, and neither is assessable from one slice."),
        Step("PET-CT where malignancy is a concern, and tissue sampling",
             "Staging and diagnosis both ultimately need more than morphology.",
             "ACR AC"),
    ),

    # --- Breast ----------------------------------------------------------
    ("Mammography", "mass"): (
        Step("Diagnostic mammography with spot compression and additional views",
             "Spot compression separates a true mass from superimposed normal "
             "tissue and better defines the margin, which is the descriptor "
             "that drives everything else.", "BI-RADS / ACR AC"),
        Step("Targeted ultrasound of the area",
             "Distinguishes cystic from solid and is the standard complement to "
             "a mammographic mass.", "BI-RADS / ACR AC"),
        Step("Image-guided core biopsy if the assessment is suspicious",
             "Tissue diagnosis is what resolves a suspicious mass; the BI-RADS "
             "category assigned on the full diagnostic work-up determines "
             "whether this is indicated.", "BI-RADS"),
    ),
    ("Mammography", "calcification"): (
        Step("Magnification views in two projections",
             "Morphology and distribution — the features that separate benign "
             "from suspicious calcification — can only be judged on "
             "magnification views, not on a compressed screenshot.",
             "BI-RADS / ACR AC"),
        Step("Stereotactic biopsy if the morphology is suspicious",
             "Suspicious calcifications are frequently the only sign of DCIS, "
             "and sampling is how that is established.", "BI-RADS"),
    ),
    ("Mammography", "architectural_distortion"): (
        Step("Tomosynthesis and additional projections",
             "Distortion is often subtle and can be simulated by superimposition; "
             "tomosynthesis separates the two.", "BI-RADS / ACR AC"),
        Step("Targeted ultrasound, then biopsy in most cases",
             "Architectural distortion carries a meaningful malignancy rate even "
             "when no mass is visible, so it is commonly sampled.", "BI-RADS"),
    ),
    ("Mammography", "asymmetry"): (
        Step("Additional views to confirm it is real",
             "Most apparent asymmetries are superimposition and disappear on "
             "further projections.", "BI-RADS / ACR AC"),
        Step("Comparison with prior studies",
             "A developing asymmetry — new or enlarging compared with priors — "
             "is the concerning form, and priors are the only way to tell.",
             "BI-RADS"),
    ),

    # --- Abdomen / other -------------------------------------------------
    ("Ultrasound", "cyst"): (
        Step("Characterise against the relevant framework for the organ",
             "Simple cysts usually need nothing; complex ones are graded — "
             "Bosniak for renal, O-RADS for ovarian — and grading drives "
             "follow-up.", "Bosniak / O-RADS"),
        Step("Contrast-enhanced CT or MRI if features are complex",
             "Septations, wall thickening and enhancement are what separate "
             "benign from concerning, and enhancement needs contrast.",
             "ACR AC"),
    ),
    ("*", "cyst"): (
        Step("Characterise against the relevant organ-specific framework",
             "Bosniak (renal), O-RADS (ovarian) and their equivalents exist "
             "precisely because cyst complexity, not presence, drives "
             "management.", "ACR AC"),
    ),
    ("*", "mass"): (
        Step("Dedicated cross-sectional imaging of the organ of interest",
             "A mass found incidentally usually needs a protocolled study — "
             "correct contrast phase, correct sequences — before it can be "
             "characterised.", "ACR AC"),
        Step("Tissue diagnosis where imaging remains indeterminate",
             "Imaging narrows; histology decides.", "ACR AC"),
    ),
    ("X-ray", "fracture"): (
        Step("Orthogonal views — a minimum of two projections",
             "A single view cannot exclude a fracture, and undisplaced "
             "fractures are frequently invisible on the initial film.",
             "ACR AC"),
        Step("CT for complex, intra-articular or occult injuries",
             "CT defines fragment position and articular involvement, which "
             "drives management.", "ACR AC"),
        Step("Clinical orthopaedic assessment",
             "Treatment depends on stability, neurovascular status and "
             "function, none of which are on the image."),
    ),
    ("*", "obstruction"): (
        Step("Urgent clinical assessment and dedicated imaging of the level",
             "Establishing the level and cause of obstruction determines "
             "whether this is a surgical problem.", "ACR AC"),
    ),
    ("*", "hydrocephalus"): (
        Step("Urgent clinical assessment and comparison with priors",
             "Whether this is acute, chronic or compensated changes management "
             "completely, and priors are the fastest way to tell.", "ACR AC"),
    ),
}

# Emitted by the code on every card that shows workup, whatever the model said.
STANDING_NOTE = {
    "English": "These are the steps such a finding typically prompts, as "
               "questions to raise with a treating clinician — not "
               "instructions, and not a care plan.",
    "Russian": "Это то, что обычно следует за такой находкой — как вопросы для "
               "обсуждения с лечащим врачом, а не назначение и не план лечения.",
}


def lookup(modality: str, category: str) -> tuple:
    """Curated steps for this finding, most specific match first."""
    if not category:
        return ()
    cat = category.strip().lower()
    exact = CURATED.get((modality or "", cat))
    if exact:
        return exact
    return CURATED.get(("*", cat), ())


def resolve(modality: str, category: str, model_steps=None, limit: int = 4) -> list:
    """Curated steps first, then any non-duplicate model-generated ones.

    The split matters: curated steps are anchored to a named framework and were
    written once, carefully. Model steps are plausible but unverified, and are
    marked so on the card rather than blended in.
    """
    out = list(lookup(modality, category))
    seen = {s.step.strip().lower()[:40] for s in out}

    for ms in (model_steps or []):
        text = (getattr(ms, "step", "") or "").strip()
        key = text.lower()[:40]
        if not text or key in seen:
            continue
        seen.add(key)
        out.append(Step(step=text,
                        rationale=(getattr(ms, "rationale", "") or "").strip(),
                        guideline=(getattr(ms, "guideline", "") or "").strip(),
                        source="model"))
    return out[:limit]


_CONFIDENCE_RANK = {"low": 0, "medium": 1, "high": 2}


def clears_bar(confidence: str, minimum: str) -> bool:
    return _CONFIDENCE_RANK.get(confidence, 0) >= _CONFIDENCE_RANK.get(minimum, 1)


def standing_note(language: str) -> str:
    return STANDING_NOTE.get(language, STANDING_NOTE["English"])

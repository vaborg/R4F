"""Telegram layer: photo in, rendered cards out. Model work lives in
analyzer.py; scheduling and consensus in committee.py."""
import asyncio
import html
import io
import logging
import re
import sys
import traceback

from telegram import Update
from telegram.constants import ChatAction, ParseMode
from telegram.ext import (Application, CommandHandler, ContextTypes,
                          MessageHandler, filters)

import analyzer
import committee as cmt
import config
import dicom as dcm
import profiles
import segment as sg
import workup as wk

logging.basicConfig(
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s", level=config.LOG_LEVEL)
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

TELEGRAM_LIMIT = 4000  # hard limit is 4096; leave headroom
SUPPORTED_MIME = {"image/jpeg", "image/png", "image/gif", "image/webp"}

LABELS = {
    "Russian": {
        "profile": "протокол",
        "workup": "Что обычно делают дальше",
        "segmenting": "🩻 Размечаю анатомию…",
        "dicom_reading": "📄 Читаю DICOM…",
        "dicom_series": "📚 Серия: {n} срезов, показываю {k}",
        "dicom_montage": "Срезы из серии ({n} всего)",
        "dicom_off": "Файлы DICOM отключены (DICOM_ENABLED=false).",
        "dicom_nolib": "Не могу открыть DICOM: не установлен pydicom.\n<code>pip install pydicom</code>",
        "dicom_window": "Окно: {name}",
        "seg_failed": "не удалось разметить анатомию, продолжаю без неё",
        "seg_no_image": "Нечего размечать. Ответьте командой /segment на снимок или пришлите новый.",
        "seg_nolib": "Сегментация недоступна: не установлен torch.\n<code>pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu</code>\n<code>pip install torchxrayvision</code>",
        "seg_wrong_domain": "⚠️ Модель сегментации обучена ТОЛЬКО на рентгенограммах грудной клетки. Похоже, это <b>{what}</b> — она найдёт «лёгкие» и «сердце» там, где их нет.\n\nЕсли всё равно нужно: <code>/segment force</code>",
        "seg_forced": "⚠️ <b>ВНЕ ОБЛАСТИ ПРИМЕНЕНИЯ.</b> Модель знает только рентген грудной клетки. Подписи ниже — артефакты, а не анатомия. Модели для описания они не передаются.",
        "seg_mode": "Автосегментация: <b>{mode}</b>",
        "workup_gated": "находок без предложений (недостаточно согласия)",
        "model_suggested": "предложено моделью, без опоры на руководство",
        "attributes": "Параметры",
        "no_reassurance": "Грубой патологии в этом кадре не вижу. Это НЕ значит, что снимок нормальный — этот тип исследования требует полного набора проекций, сравнения с предыдущими и клинического контекста.",
        "triage_failed": "не удалось определить тип снимка, использую общий протокол",
        "analyzing": "🔎 Смотрю изображение… ({backend})",
        "queued": "🔎 Комитет: {n} прогон(ов), {members}. Это займёт время…",
        "findings": "Находки",
        "no_findings": "Явной патологии на этом изображении не вижу.",
        "impression": "Заключение",
        "caveats": "Что это изображение показать не может",
        "consensus": "СВОДКА КОМИТЕТА",
        "agreement": "согласие",
        "voters": "за",
        "members_ok": "участников ответили",
        "dropped": "находок отброшено (мало согласия)",
        "disclaimer": "Не диагноз. Автоматический разбор одного кадра без клинического контекста.",
        "too_big": "Файл слишком большой (> {mb:.1f} МБ). Отправьте как фото или уменьшите размер.",
        "bad_type": "Такой формат не поддерживается. Нужен JPEG, PNG, GIF или WebP.",
        "failed": "⚠️ {backend}: не удалось разобрать изображение.\n<code>{err}</code>",
        "all_failed": "⚠️ Ни один участник комитета не ответил.",
        "high": "высокая", "medium": "средняя", "low": "низкая",
    },
    "English": {
        "profile": "protocol",
        "workup": "What this usually leads to",
        "segmenting": "🩻 Mapping anatomy…",
        "dicom_reading": "📄 Reading DICOM…",
        "dicom_series": "📚 Series: {n} slices, sampling {k}",
        "dicom_montage": "Slices sampled from the series ({n} total)",
        "dicom_off": "DICOM files are disabled (DICOM_ENABLED=false).",
        "dicom_nolib": "Can't open DICOM: pydicom isn't installed.\n<code>pip install pydicom</code>",
        "dicom_window": "Window: {name}",
        "seg_failed": "anatomy segmentation failed, continuing without it",
        "seg_no_image": "Nothing to segment. Reply /segment to an image, or send a new one.",
        "seg_nolib": "Segmentation unavailable: torch isn't installed.\n<code>pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu</code>\n<code>pip install torchxrayvision</code>",
        "seg_wrong_domain": "⚠️ The segmentation model is trained ONLY on chest radiographs. This looks like <b>{what}</b> — it will find “lungs” and a “heart” that aren't there.\n\nRun it anyway: <code>/segment force</code>",
        "seg_forced": "⚠️ <b>OUT OF DOMAIN.</b> This model only knows chest radiographs. The labels below are artefacts, not anatomy. They are NOT sent to the language model.",
        "seg_mode": "Auto-segmentation: <b>{mode}</b>",
        "workup_gated": "finding(s) with no next steps shown (agreement too low)",
        "model_suggested": "model-suggested, not anchored to a guideline",
        "attributes": "Parameters",
        "no_reassurance": "No gross abnormality visible in this frame. This does NOT mean the study is normal — this examination type requires the full set of views, comparison with priors, and clinical context.",
        "triage_failed": "couldn't classify the image, using the generic protocol",
        "analyzing": "🔎 Looking at the image… ({backend})",
        "queued": "🔎 Committee: {n} run(s), {members}. This will take a while…",
        "findings": "Findings",
        "no_findings": "No clear pathology visible on this image.",
        "impression": "Impression",
        "caveats": "What this image cannot tell you",
        "consensus": "COMMITTEE CONSENSUS",
        "agreement": "agreement",
        "voters": "by",
        "members_ok": "members responded",
        "dropped": "finding(s) dropped for low agreement",
        "disclaimer": "Not a diagnosis. Automated read of a single frame with no clinical context.",
        "too_big": "File too large (> {mb:.1f} MB). Send it as a photo or downscale it.",
        "bad_type": "Unsupported format. Needs to be JPEG, PNG, GIF or WebP.",
        "failed": "⚠️ {backend}: couldn't analyze the image.\n<code>{err}</code>",
        "all_failed": "⚠️ No committee member returned a usable answer.",
        "high": "high", "medium": "medium", "low": "low",
    },
}


def L():
    return LABELS.get(config.IMAGE_LANGUAGE, LABELS["English"])


def _e(value) -> str:
    return html.escape(str(value or "").strip())


def _clip(text: str) -> str:
    if len(text) > TELEGRAM_LIMIT:
        return text[:TELEGRAM_LIMIT - 1] + "…"
    return text


# --- Rendering ----------------------------------------------------------

def format_member_card(result: cmt.RunResult, profile=None) -> str:
    """One member's own read."""
    lab = L()
    profile = profile or profiles.GENERIC
    run = result.run
    tag = _e(run.member.model)
    if run.total > 1:
        tag += f" #{run.index + 1}"
    footer = f"<i>— {tag} · {result.seconds:.0f}s</i>"
    if profile is not profiles.GENERIC:
        footer += f"\n<i>{lab['profile']}: {_e(profile.label)}</i>"

    if not result.ok:
        text = lab["failed"].format(backend=tag,
                                    err=html.escape(result.error or ""))
        hint = analyzer.error_hint(result.error or "")
        if hint:
            text += f"\n<i>{_e(hint)}</i>"
        return text

    read = result.read
    if not read.is_medical_image:
        return f"🚫 {_e(read.reject_reason)}\n\n{footer}"

    parts = []
    head = f"🖼 <b>{_e(read.modality) or '?'}</b> · {_e(read.anatomy) or '?'}"
    if read.modality_confidence:
        head += f" <i>({lab.get(read.modality_confidence, read.modality_confidence)})</i>"
    parts.append(head)

    sub = [_e(x) for x in (read.plane, read.sequence_or_phase) if x]
    if sub:
        parts.append(f"<i>{' · '.join(sub)}</i>")
    if read.modality_evidence:
        parts.append(f"<i>{_e(read.modality_evidence)}</i>")

    parts.extend(_format_attributes(read.attributes))

    parts.append("")
    if read.findings:
        parts.append(f"<b>{lab['findings']}:</b>")
        for f in read.findings:
            line = f"• <b>{_e(f.name)}</b> <i>[{lab.get(f.confidence, f.confidence)}]</i>"
            if f.appearance:
                line += f"\n  {_e(f.appearance)}"
            parts.append(line)
    else:
        # Screening protocols must never render as an all-clear: a negative from
        # one compressed view is the least trustworthy thing the bot can say.
        parts.append(f"<b>{lab['findings']}:</b> "
                     + (lab["no_reassurance"] if profile.no_reassurance
                        else lab["no_findings"]))

    if read.impression:
        parts.append("")
        parts.append(f"<b>{lab['impression']}:</b> {_e(read.impression)}")

    entries, gated = _gather_workup(read.findings, read.modality, consensus=False)
    parts.extend(_format_workup(entries))
    if gated:
        parts.append(f"<i>+{gated} {lab['workup_gated']}</i>")

    parts.extend(_format_caveats(read.caveats, profile))

    parts.append("")
    parts.append(footer)
    return _clip("\n".join(parts))


def _format_attributes(attributes) -> list:
    if not attributes:
        return []
    lab = L()
    out = ["", f"<b>{lab['attributes']}:</b>"]
    out.extend(f"• {_e(a.label)}: <b>{_e(a.value)}</b>" for a in attributes)
    return out


def _format_workup(entries) -> list:
    """entries: list of (finding_name, [Step, ...]) already gated by caller."""
    if not entries:
        return []
    lab = L()
    out = ["", f"<b>{lab['workup']}:</b>"]
    for name, steps in entries:
        out.append(f"<u>{_e(name)}</u>")
        for s in steps:
            line = f"  → {_e(s.step)}"
            if s.guideline:
                line += f" <i>[{_e(s.guideline)}]</i>"
            elif s.source == "model":
                line += f" <i>[{lab['model_suggested']}]</i>"
            out.append(line)
            if s.rationale:
                out.append(f"     <i>{_e(s.rationale)}</i>")
    out.append(f"<i>{_e(wk.standing_note(config.IMAGE_LANGUAGE))}</i>")
    return out


def _gather_workup(findings, modality, consensus: bool):
    """Apply the confidence gate, then resolve curated + model steps.

    Returns (entries, gated_count). The gate is the whole point: workup is
    downstream of the least reliable part of the pipeline, and a hallucinated
    finding must not generate a confident next-step recommendation.
    """
    if not config.WORKUP_ENABLED:
        return [], 0

    entries, gated = [], 0
    for f in findings:
        if consensus:
            passes = f.agreement >= config.WORKUP_MIN_AGREEMENT
            category = f.category
            proposed = f.model_workup
        else:
            passes = wk.clears_bar(f.confidence, config.WORKUP_MIN_CONFIDENCE)
            category = f.category or ""
            proposed = f.suggested_workup

        if not passes:
            gated += 1
            continue
        steps = wk.resolve(modality, category, proposed, config.WORKUP_MAX_STEPS)
        if steps:
            entries.append((f.name, steps))
    return entries, gated


def _format_caveats(model_caveats, profile) -> list:
    """Profile caveats are emitted by the CODE, not the model. A limitation that
    depends on the model remembering to mention it is not a limitation the user
    can rely on being told about."""
    lab = L()
    items = list(profile.mandatory_caveats)
    seen = {c.strip().lower()[:50] for c in items}
    for c in (model_caveats or []):
        if c and c.strip().lower()[:50] not in seen:
            items.append(c)
    if not items:
        return []
    out = ["", f"<b>{lab['caveats']}:</b>"]
    out.extend(f"• {_e(c)}" for c in items[:8])
    return out


def _bar(fraction: float) -> str:
    """Five blocks. A number alone doesn't convey 'two of five models' at a
    glance, and this is the number that should drive how much you trust a line."""
    filled = max(0, min(5, round(fraction * 5)))
    return "▰" * filled + "▱" * (5 - filled)


def format_consensus_card(con: cmt.Consensus, members: list, profile=None) -> str:
    lab = L()
    profile = profile or profiles.GENERIC

    if con.members_ok == 0:
        lines = []
        for m, e in con.failures:
            lines.append(f"• {_e(m)}: {_e(e)}")
            hint = analyzer.error_hint(e or "")
            if hint:
                lines.append(f"  <i>{_e(hint)}</i>")
        return f"{lab['all_failed']}\n" + "\n".join(lines)

    if not con.is_medical_image:
        return f"🚫 {_e(con.reject_reason)}\n\n<i>— {lab['consensus']}</i>"

    parts = [f"<b>🏛 {lab['consensus']}</b>"]

    head = f"🖼 <b>{_e(con.modality) or '?'}</b> · {_e(con.anatomy) or '?'}"
    parts.append(head)
    parts.append(f"<code>{_bar(con.modality_agreement)}</code> "
                 f"{con.modality_agreement:.0%} {lab['agreement']}")

    parts.extend(_format_attributes(con.attributes))

    parts.append("")
    if con.findings:
        parts.append(f"<b>{lab['findings']}:</b>")
        for f in con.findings:
            parts.append(
                f"• <b>{_e(f.name)}</b> <code>{_bar(f.agreement)}</code> "
                f"{f.agreement:.0%} <i>[{lab.get(f.confidence, f.confidence)}]</i>")
            if f.appearance:
                parts.append(f"  {_e(f.appearance)}")
            if len(members) > 1:
                parts.append(f"  <i>{lab['voters']}: {_e(', '.join(f.voters))}</i>")
    else:
        parts.append(f"<b>{lab['findings']}:</b> "
                     + (lab["no_reassurance"] if profile.no_reassurance
                        else lab["no_findings"]))

    if con.dropped_findings:
        parts.append(f"<i>+{con.dropped_findings} {lab['dropped']}</i>")

    if con.impression:
        parts.append("")
        parts.append(f"<b>{lab['impression']}:</b> {_e(con.impression)}")

    entries, gated = _gather_workup(con.findings, con.modality, consensus=True)
    parts.extend(_format_workup(entries))
    if gated:
        parts.append(f"<i>+{gated} {lab['workup_gated']}</i>")

    parts.extend(_format_caveats(con.caveats, profile))

    parts.append("")
    if profile is not profiles.GENERIC:
        parts.append(f"<i>{lab['profile']}: {_e(profile.label)}</i>")
    parts.append(f"<i>{con.members_ok} {lab['members_ok']}"
                 + (f", {con.members_failed} failed" if con.members_failed else "")
                 + f" · {con.seconds:.0f}s</i>")
    parts.append(f"<i>{lab['disclaimer']}</i>")
    return _clip("\n".join(parts))


async def _send(message, text: str, edit: bool):
    """Malformed HTML makes Telegram reject the whole message. Fall back to
    plain text so a rendering quirk never eats a result."""
    try:
        if edit:
            await message.edit_text(text, parse_mode=ParseMode.HTML)
        else:
            await message.reply_text(text, parse_mode=ParseMode.HTML)
    except Exception:
        logger.warning("HTML send failed, falling back to plain text", exc_info=True)
        plain = re.sub(r"<[^>]+>", "", text)
        if edit:
            await message.edit_text(plain)
        else:
            await message.reply_text(plain)


# --- Handlers -----------------------------------------------------------

def _is_owner(update: Update) -> bool:
    return str(update.effective_chat.id) == str(config.CHAT_ID)


def _backend(context) -> str:
    return context.bot_data.get("backend", config.IMAGE_BACKEND)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        return
    await update.message.reply_text(
        "Send me a medical image (CT, MRI, PET, ultrasound, X-ray) and I'll tell you "
        "the modality, the anatomy, and anything that looks off.\n\n"
        f"Current backend: <b>{_backend(context)}</b>\n"
        "/backend — switch model (medgemma / haiku / both / committee)\n"
        "/committee — who votes, and with what weight\n"
        "/profile — reading protocol (mammography, brain CT, chest X-ray, ...)\n"
        "/segment — anatomy overlay on a chest X-ray (reply to an image)\n"
        "/help — the honest limitations\n\n"
        "<i>Tip: send as a file, not a photo, to skip Telegram's JPEG compression.</i>",
        parse_mode=ParseMode.HTML)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        return
    await update.message.reply_text(
        "<b>What this is good at</b>\n"
        "Modality and anatomy. A single image basically determines them.\n\n"
        "<b>What it is not good at</b>\n"
        "Findings. Treat that section as “things to look at yourself”, never as a "
        "read. Every model here will miss things and will occasionally invent "
        "things.\n\n"
        "<b>Backends</b>\n"
        f"• <b>medgemma</b> ({config.MEDGEMMA_MODEL}) — local, free, private, "
        "medically tuned. Minutes per image on CPU. English-first.\n"
        f"• <b>haiku</b> ({config.HAIKU_MODEL}) — Claude API. Seconds, ~$0.01/image, "
        "follows instructions better, holds Russian. Image leaves the machine.\n"
        "• <b>both</b> — medgemma + haiku, two cards plus a consensus.\n"
        "• <b>committee</b> — every model in COMMITTEE_MODELS, weighted vote. "
        "Slowest, but agreement across models is a real confidence signal in a "
        "way one model's self-reported “high” is not.\n\n"
        "<b>Next steps</b>\n"
        "Findings that clear the confidence bar also show what such a finding "
        "typically prompts, anchored to the ACR Appropriateness Criteria or the "
        "relevant organ framework. These are questions for a clinician, not a "
        "care plan — and they inherit all the unreliability of the finding that "
        "triggered them, which is why they are gated.\n\n"
        "<b>Reading the consensus</b>\n"
        "The percentage is the share of voting weight that saw that finding. A "
        "finding only one light member reported is exactly the kind of thing that "
        "is usually noise.\n\n"
        "<b>Blind spots that apply to all of them</b>\n"
        "One slice, unknown window, no contrast timing, no priors, no history. "
        "PET is weakest — real reads need SUV values that aren't in the pixels.",
        parse_mode=ParseMode.HTML)


async def committee_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        return
    members = analyzer.members_for("committee")
    if not members:
        await update.message.reply_text(
            "The committee is empty. Set COMMITTEE_MODELS in .env, e.g.\n"
            "<code>COMMITTEE_MODELS=medgemma1.5:4b=3,gemma3:4b=1</code>",
            parse_mode=ParseMode.HTML)
        return

    total = sum(m.weight for m in members)
    lines = ["<b>Committee</b>"]
    for m in members:
        kind = "local" if m.is_local else "API"
        lines.append(f"• <code>{_e(m.model)}</code> — weight {m.weight:g} "
                     f"({m.weight / total:.0%}), {kind}")
    lines.append("")
    lines.append(f"Repeats per member: <b>{config.COMMITTEE_REPEATS}</b>")
    n_local = sum(1 for m in members if m.is_local)
    lines.append(f"CPU inferences per image: <b>{n_local * config.COMMITTEE_REPEATS}</b>")
    if config.COMMITTEE_MIN_AGREEMENT > 0:
        lines.append(f"Findings below {config.COMMITTEE_MIN_AGREEMENT:.0%} agreement "
                     "are dropped.")
    lines.append("")
    lines.append("<i>Edit COMMITTEE_MODELS in .env and restart to change this.</i>")
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)


async def backend_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        return
    args = context.args
    if not args:
        await update.message.reply_text(
            f"Backend: <b>{_backend(context)}</b>\n\n"
            "<code>/backend medgemma</code> — local, free, slow\n"
            "<code>/backend haiku</code> — API, fast, ~$0.01/image\n"
            "<code>/backend both</code> — medgemma + haiku, with consensus\n"
            "<code>/backend committee</code> — full weighted vote",
            parse_mode=ParseMode.HTML)
        return

    choice = args[0].strip().lower()
    if choice not in config.BACKENDS:
        await update.message.reply_text(
            f"Unknown backend {choice!r}. Options: {', '.join(config.BACKENDS)}")
        return
    context.bot_data["backend"] = choice
    await update.message.reply_text(f"Backend set to <b>{choice}</b>.",
                                    parse_mode=ParseMode.HTML)


def _looks_like_zip(document) -> bool:
    mime = (getattr(document, "mime_type", "") or "").lower()
    name = (getattr(document, "file_name", "") or "").lower()
    return "zip" in mime or name.endswith(".zip")


def _unzip_dicoms(data: bytes, limit: int) -> list:
    """Pull DICOM files out of an archive. Ignores anything that isn't one, so
    a PACS export with its DICOMDIR and readme still works."""
    import zipfile
    out = []
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        for info in zf.infolist():
            if info.is_dir() or info.file_size < 132:
                continue
            if len(out) >= limit:
                break
            try:
                blob = zf.read(info)
            except Exception:
                continue
            if dcm.is_dicom(blob):
                out.append(blob)
    return out


def _looks_like_dicom(document) -> bool:
    """Telegram usually reports .dcm as application/octet-stream or dicom, so
    trust the filename too. The bytes are verified after download anyway."""
    mime = (getattr(document, "mime_type", "") or "").lower()
    name = (getattr(document, "file_name", "") or "").lower()
    return ("dicom" in mime or name.endswith((".dcm", ".dicom"))
            or mime == "application/octet-stream")


async def _extract_image(update: Update, context) -> tuple[bytes, str]:
    """Returns (bytes, media_type). media_type is "dicom" for a DICOM upload.
    Raises ValueError with a user-facing message."""
    lab, msg = L(), update.message

    if msg.document and _looks_like_zip(msg.document) \
            and config.DICOM_SERIES_ENABLED:
        if (msg.document.file_size or 0) > config.MAX_DICOM_BYTES:
            raise ValueError(lab["too_big"].format(mb=config.MAX_DICOM_BYTES / 1e6))
        if not config.DICOM_ENABLED:
            raise ValueError(lab["dicom_off"])
        if not dcm.available():
            raise ValueError(lab["dicom_nolib"])
        tg_file = await context.bot.get_file(msg.document.file_id)
        data = bytes(await tg_file.download_as_bytearray())
        try:
            blobs = _unzip_dicoms(data, config.DICOM_SERIES_MAX_FILES)
        except Exception as exc:
            raise ValueError(f"Couldn't read that archive: {exc}") from exc
        if not blobs:
            raise ValueError(lab["bad_type"])
        return blobs, "dicom-series"

    if msg.document and _looks_like_dicom(msg.document):
        if (msg.document.file_size or 0) > config.MAX_DICOM_BYTES:
            raise ValueError(lab["too_big"].format(mb=config.MAX_DICOM_BYTES / 1e6))
        tg_file = await context.bot.get_file(msg.document.file_id)
        data = bytes(await tg_file.download_as_bytearray())
        if dcm.is_dicom(data):
            if not config.DICOM_ENABLED:
                raise ValueError(lab["dicom_off"])
            if not dcm.available():
                raise ValueError(lab["dicom_nolib"])
            return data, "dicom"
        # octet-stream that isn't DICOM: fall through to the normal checks.
        mime = (msg.document.mime_type or "").lower()
        if mime not in SUPPORTED_MIME:
            raise ValueError(lab["bad_type"])
        if len(data) > config.MAX_IMAGE_BYTES:
            raise ValueError(lab["too_big"].format(mb=config.MAX_IMAGE_BYTES / 1e6))
        return data, mime

    if msg.photo:
        # Telegram re-encodes photos to JPEG and offers several sizes; [-1] is
        # the largest. The compression is lossy, which matters for subtle
        # findings — sending as a file instead preserves the original.
        file_id, media_type = msg.photo[-1].file_id, "image/jpeg"
    elif msg.document:
        mime = (msg.document.mime_type or "").lower()
        if mime not in SUPPORTED_MIME:
            raise ValueError(lab["bad_type"])
        if (msg.document.file_size or 0) > config.MAX_IMAGE_BYTES:
            raise ValueError(lab["too_big"].format(mb=config.MAX_IMAGE_BYTES / 1e6))
        file_id, media_type = msg.document.file_id, mime
    else:
        raise ValueError(lab["bad_type"])

    tg_file = await context.bot.get_file(file_id)
    data = bytes(await tg_file.download_as_bytearray())
    if len(data) > config.MAX_IMAGE_BYTES:
        raise ValueError(lab["too_big"].format(mb=config.MAX_IMAGE_BYTES / 1e6))
    return data, media_type


async def resolve_profile(members, img, context, study=None):
    """Returns (profile, how). Order: explicit override, DICOM header, cheap
    triage pass, generic."""
    mode = context.bot_data.get("profile", config.PROFILE_MODE)

    if mode == "off":
        return profiles.GENERIC, "off"
    if mode != "auto":
        return profiles.get(mode), "forced"

    # A DICOM header states the modality outright, so the triage model call is
    # not just avoidable but strictly worse than reading it. Free and exact.
    if study is not None:
        modality, region = dcm.profile_hint(study)
        if modality:
            profile = profiles.select(modality, region)
            logger.info("profile from DICOM header: %s / %s -> %s",
                        modality, region, profile.name)
            return profile, "dicom"

    if not config.PROFILE_TRIAGE:
        return profiles.GENERIC, "off"

    member = analyzer.pick_triage_member(members)
    if member is None:
        return profiles.GENERIC, "off"
    try:
        t = await analyzer.triage(member, img)
        profile = profiles.select(t.modality, t.region)
        logger.info("triage: %s / %s -> profile %s", t.modality, t.region,
                    profile.name)
        return profile, "auto"
    except Exception:
        # Never let classification failure block the actual read.
        logger.warning("triage failed; falling back to the generic profile",
                       exc_info=True)
        return profiles.GENERIC, "failed"


async def profile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        return
    current = context.bot_data.get("profile", config.PROFILE_MODE)
    args = context.args

    if not args:
        listing = "\n".join(
            f"• <code>{p.name}</code> — {_e(p.label)}" for p in profiles.ALL)
        await update.message.reply_text(
            f"Reading protocol: <b>{_e(current)}</b>\n\n"
            "<code>/profile auto</code> — classify each image, then use the "
            "matching protocol\n"
            "<code>/profile off</code> — always the generic prompt\n"
            "<code>/profile &lt;name&gt;</code> — force one, and skip the "
            "classification pass\n\n"
            f"{listing}\n\n"
            "<i>Forcing a protocol is cheaper: auto mode spends one extra "
            "classification call per image.</i>",
            parse_mode=ParseMode.HTML)
        return

    choice = args[0].strip().lower()
    if choice not in ("auto", "off") and choice not in profiles.BY_NAME:
        await update.message.reply_text(
            f"Unknown protocol {choice!r}. Options: auto, off, "
            + ", ".join(profiles.names()))
        return
    context.bot_data["profile"] = choice
    await update.message.reply_text(f"Reading protocol set to <b>{choice}</b>.",
                                    parse_mode=ParseMode.HTML)


async def _do_segment(update, image_bytes, out_of_domain: bool = False):
    """Run the segmenter and post the overlay. Returns the Result, or None.

    Never raises: a segmentation failure must not cost you the read.
    """
    lab = L()
    note = await update.message.reply_text(lab["segmenting"])
    try:
        result = await asyncio.to_thread(
            sg.segment, image_bytes, config.SEGMENT_THRESHOLD,
            config.SEGMENT_ALPHA, config.SEGMENT_MIN_AREA, config.IMAGE_LANGUAGE)
    except Exception:
        logger.exception("segmentation failed")
        await note.edit_text(lab["seg_failed"])
        return None
    finally:
        if config.SEGMENT_UNLOAD_AFTER:
            # ~200MB of weights that Ollama would rather have.
            sg.unload()

    if not result.structures:
        await note.edit_text(lab["seg_failed"])
        return None

    legend = sg.legend_text(result, config.IMAGE_LANGUAGE)
    if out_of_domain:
        # Loud, and above the legend: these labels are confabulation, and the
        # whole point of the banner is that they must not be read as anatomy.
        legend = lab["seg_forced"] + "\n\n" + legend
    if config.SEGMENT_SEND_OVERLAY:
        try:
            await update.message.reply_photo(
                photo=result.overlay_png, caption=_clip(legend),
                parse_mode=ParseMode.HTML)
            await note.delete()
        except Exception:
            logger.warning("couldn't send the overlay", exc_info=True)
            await _send(note, legend, edit=True)
    else:
        await _send(note, legend, edit=True)

    return result


async def run_segmentation(update, context, profile, image_bytes):
    """Automatic path: returns grounding text for the language model, or "".

    Gated to chest radiographs — PSPNet is a chest X-ray model, and there is no
    equivalent 2D anatomy model for a CT or MRI screenshot.
    """
    if context.bot_data.get("segment_auto", "auto") == "off":
        return ""
    if not config.SEGMENT_ENABLED or profile.name != "chest_xray":
        return ""
    if not sg.available():
        logger.info("segmentation skipped: torch/torchxrayvision not installed")
        return ""

    result = await _do_segment(update, image_bytes)
    if result is None:
        return ""
    return sg.annotation(result) if config.SEGMENT_GROUND_PROMPT else ""


async def _handle_dicom(update, context, data, series: bool = False):
    """Parse, render the windows, post them. Returns (image_bytes, study).

    The rendered primary window becomes the image everything downstream sees,
    so the rest of the pipeline needs no knowledge of DICOM at all.
    """
    lab = L()
    note = await update.message.reply_text(lab["dicom_reading"])
    if series:
        study = await asyncio.to_thread(
            dcm.load_series, data, config.DICOM_MAX_WINDOWS,
            config.DICOM_SERIES_SLICES)
    else:
        study = await asyncio.to_thread(dcm.load, data, config.DICOM_MAX_WINDOWS)

    await _send(note, dcm.summary_text(study, config.IMAGE_LANGUAGE), edit=True)

    if study.is_series:
        await update.message.reply_text(
            lab["dicom_series"].format(n=study.slice_count, k=len(study.sampled)))
        if study.montage:
            try:
                await update.message.reply_photo(
                    photo=study.montage,
                    caption=lab["dicom_montage"].format(n=study.slice_count))
            except Exception:
                logger.warning("couldn't send the montage", exc_info=True)

    renders = study.renders if config.DICOM_SEND_ALL_WINDOWS else study.renders[:1]
    for r in renders:
        caption = lab["dicom_window"].format(name=_e(r.window.name))
        if r.window.note:
            caption += f" — <i>{_e(r.window.note)}</i>"
        try:
            await update.message.reply_photo(photo=r.png, caption=_clip(caption),
                                             parse_mode=ParseMode.HTML)
        except Exception:
            logger.warning("couldn't send window %s", r.window.name, exc_info=True)
    if study.is_series and study.sampled:
        # For a series the analyzed set is exactly the sampled slices, in
        # order. The windows posted above are of the middle slice, which is the
        # right thing to LOOK at; this is the right thing to ANALYZE.
        return study.sampled[0][1], study
    return study.primary.png if study.primary else None, study


async def _download(context, file_id) -> bytes:
    tg_file = await context.bot.get_file(file_id)
    return bytes(await tg_file.download_as_bytearray())


async def _image_from_reply(update, context):
    """Bytes of the image the user replied to, or None. Works on the bot's own
    photos too, so you can /segment a rendered DICOM window."""
    replied = getattr(update.message, "reply_to_message", None)
    if replied is None:
        return None
    if getattr(replied, "photo", None):
        return await _download(context, replied.photo[-1].file_id)
    doc = getattr(replied, "document", None)
    if doc is not None and (doc.mime_type or "").lower() in SUPPORTED_MIME:
        return await _download(context, doc.file_id)
    return None


def _remember_image(context, chat_id, image_bytes, profile_name):
    """One slot per chat, so a bare /segment has something to act on. Only the
    most recent image is kept."""
    context.bot_data.setdefault("last_image", {})[str(chat_id)] = {
        "bytes": image_bytes, "profile": profile_name}


async def segment_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/segment [force|auto|off]

    Reply to an image, or send one first and use it bare.
    """
    if not _is_owner(update):
        return

    lab = L()
    args = [a.strip().lower() for a in (context.args or [])]

    if args and args[0] in ("auto", "off", "on"):
        mode = "auto" if args[0] == "on" else args[0]
        context.bot_data["segment_auto"] = mode
        await update.message.reply_text(lab["seg_mode"].format(mode=mode),
                                        parse_mode=ParseMode.HTML)
        return

    if not config.SEGMENT_ENABLED:
        await update.message.reply_text("SEGMENT_ENABLED=false")
        return
    if not sg.available():
        await _send(update.message, lab["seg_nolib"], edit=False)
        return

    force = bool(args) and args[0] in ("force", "anyway", "yes")

    cached = context.bot_data.get("last_image", {}).get(str(update.effective_chat.id))
    image_bytes = await _image_from_reply(update, context)
    known_profile = None
    if image_bytes is None and cached:
        image_bytes, known_profile = cached["bytes"], cached["profile"]

    if image_bytes is None:
        await update.message.reply_text(lab["seg_no_image"])
        return

    if not force:
        # Domain check. PSPNet on a brain CT will confidently label "Left Lung"
        # — exactly the confabulation this project exists to avoid — so refuse
        # by default and make the override explicit.
        profile_name = known_profile
        if profile_name is None:
            members = analyzer.members_for(_backend(context))
            img = await _prepare(image_bytes, "image/png")
            profile, _ = await resolve_profile(members, img, context)
            profile_name = profile.name
        if profile_name != "chest_xray":
            await _send(update.message,
                        lab["seg_wrong_domain"].format(
                            what=_e(profiles.get(profile_name).label)),
                        edit=False)
            return

    # Forced runs are shown but NEVER fed to the language model: out-of-domain
    # masks as grounding would poison the read with invented anatomy.
    await _do_segment(update, image_bytes,
                      out_of_domain=force and known_profile != "chest_xray")


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        return

    lab = L()
    try:
        image_bytes, media_type = await _extract_image(update, context)
    except ValueError as exc:
        await _send(update.message, str(exc), edit=False)
        return

    study = None
    if media_type in ("dicom", "dicom-series"):
        try:
            image_bytes, study = await _handle_dicom(
                update, context, image_bytes, series=(media_type == "dicom-series"))
        except ValueError as exc:
            await update.message.reply_text(str(exc))
            return
        except Exception as exc:
            logger.exception("DICOM handling failed")
            await update.message.reply_text(f"⚠️ DICOM: {str(exc)[:300]}")
            return
        if not image_bytes:
            await update.message.reply_text(lab["bad_type"])
            return
        media_type = "image/png"

    backend = _backend(context)
    members = analyzer.members_for(backend)
    repeats = config.COMMITTEE_REPEATS if backend == "committee" else 1
    note = (update.message.caption or "").strip()

    if backend == "committee" and len(members) > 1:
        n_local = sum(1 for m in members if m.is_local) * repeats
        status_text = lab["queued"].format(
            n=len(members) * repeats,
            members=", ".join(m.model for m in members))
        if n_local:
            status_text += f" ({n_local} local)"
    else:
        status_text = lab["analyzing"].format(backend=backend)

    # Prepared once and reused by every member: one downscale, one base64.
    img = await _prepare(image_bytes, media_type)

    if study is not None and study.is_series and len(study.sampled) > 1:
        # sampled[0] is already `img`; attach the rest so the model sees several
        # levels in order rather than guessing what lies above and below.
        img.extras = [await _prepare(png, "image/png")
                      for _, png in study.sampled[1:]]

    profile, how = await resolve_profile(members, img, context, study)
    if how == "failed":
        await update.message.reply_text(lab["triage_failed"])

    _remember_image(context, update.effective_chat.id, image_bytes, profile.name)

    grounding_parts = []
    if study is not None:
        header = dcm.annotation(study)
        if header:
            grounding_parts.append(header)

    seg = await run_segmentation(update, context, profile, image_bytes)
    if seg:
        grounding_parts.append(seg)
    grounding = "\n\n".join(grounding_parts)

    status = await update.message.reply_text(_clip(status_text))
    await context.bot.send_chat_action(update.effective_chat.id, ChatAction.TYPING)

    show_members = (len(members) * repeats == 1) or config.COMMITTEE_SHOW_MEMBERS
    single = (len(members) * repeats == 1)

    results, first = [], True
    async for result in cmt.run_committee(members, img, note, repeats, profile,
                                          grounding):
        results.append(result)
        if show_members:
            card = format_member_card(result, profile)
            await _send(status if first else update.message, card, edit=first)
            first = False

    if single:
        # One member: its card IS the answer, no consensus to add.
        if not show_members:
            await _send(status, format_member_card(results[0], profile), edit=True)
        return

    consensus = cmt.aggregate(results)
    card = format_consensus_card(consensus, members, profile)
    await _send(status if first else update.message, card, edit=first)


async def _prepare(image_bytes: bytes, media_type: str):
    # Pillow resize is CPU work; keep it off the event loop.
    return await asyncio.to_thread(analyzer.prepare_image, image_bytes, media_type)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    """Without this, an exception in a handler is swallowed: the process keeps
    running and you never learn anything failed."""
    logger.error("Unhandled exception:\n%s", "".join(
        traceback.format_exception(type(context.error), context.error,
                                   context.error.__traceback__)))
    if isinstance(update, Update) and update.effective_chat and _is_owner(update):
        try:
            await context.bot.send_message(
                update.effective_chat.id,
                f"⚠️ Internal error: <code>{html.escape(str(context.error)[:300])}</code>",
                parse_mode=ParseMode.HTML)
        except Exception:
            logger.exception("Couldn't report the error to Telegram either")


async def on_startup(app: Application):
    me = await app.bot.get_me()
    logger.info("Connected to Telegram as @%s", me.username)
    logger.info("Backend: %s | language: %s", config.IMAGE_BACKEND, config.IMAGE_LANGUAGE)
    if config.IMAGE_BACKEND == "committee":
        for m in analyzer.members_for("committee"):
            logger.info("  committee member: %s (weight %g)", m.model, m.weight)


def main():
    problems = config.validate()
    if problems:
        print("Configuration problems:\n" + "\n".join(f"  - {p}" for p in problems),
              file=sys.stderr)
        sys.exit(1)

    for w in config.warnings():
        print(f"  ! {w}", file=sys.stderr)
        logger.warning(w)

    # Fail at startup, not on your first photo an hour from now. In a committee
    # one text-only member would silently poison every vote, so check them all.
    models = config.active_local_models(config.IMAGE_BACKEND)
    for p in analyzer.check_models(models):
        print(f"  - {p}", file=sys.stderr)
        logger.error(p)

    if config.STARTUP_SMOKE_TEST and models:
        print(f"  … smoke-testing {len(models)} local model(s); this loads each "
              "one and is slow on CPU", file=sys.stderr)
        for p in analyzer.smoke_test(models):
            print(f"  - {p}", file=sys.stderr)
            logger.error(p)

    app = Application.builder().token(config.BOT_TOKEN).post_init(on_startup).build()
    app.bot_data["backend"] = config.IMAGE_BACKEND
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("backend", backend_cmd))
    app.add_handler(CommandHandler("committee", committee_cmd))
    app.add_handler(CommandHandler("profile", profile_cmd))
    app.add_handler(CommandHandler("segment", segment_cmd))
    app.add_handler(MessageHandler(
        filters.PHOTO | filters.Document.IMAGE | filters.Document.ALL, handle_photo))
    app.add_error_handler(error_handler)
    app.run_polling()


if __name__ == "__main__":
    main()

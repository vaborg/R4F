"""Model access behind one contract.

Any number of vision models — arbitrary Ollama models, plus Haiku — return the
same validated ImageRead, so bot.py renders them identically and committee.py
can compare them honestly. Same image, same prompt, same schema; only the model
differs. That's what makes a disagreement mean something.

How the two kinds differ under the hood, deliberately:

  * Ollama members get structured-output mode, which constrains the JSON at the
    sampler level (grammar-constrained decoding) rather than asking nicely. At
    4B that's the difference between usable and coin-flip.
  * Haiku is asked for JSON in the prompt and validated after. It doesn't need
    the grammar; it needs the schema stated clearly, which it is.

Both paths validate through the same pydantic model, so a member that drifts
gets caught rather than rendering half-empty.
"""
import asyncio
import base64
import io
import json
import logging
import re
from dataclasses import dataclass, field
from typing import Literal, Optional

from pydantic import BaseModel, Field, ValidationError

import config
import profiles
import workup

logger = logging.getLogger(__name__)

# Concurrent Ollama calls on a CPU-only box don't run in parallel, they just
# make each other slow and fight for RAM. One local inference at a time,
# process-wide. Deliberately NOT applied to the Haiku path: it's a network call
# holding no local resources, and serializing it would only slow things down.
_ollama_lock = asyncio.Lock()

_ollama_client = None
_anthropic_client = None


def _ollama():
    """Lazy: importing this module must not require Ollama to be up, or a
    haiku-only user can't start the bot."""
    global _ollama_client
    if _ollama_client is None:
        from ollama import Client
        _ollama_client = Client(host=config.OLLAMA_HOST, timeout=config.OLLAMA_TIMEOUT)
    return _ollama_client


def _anthropic():
    """Lazy: Anthropic() raises when ANTHROPIC_API_KEY is unset, so a
    local-only user would otherwise be unable to start the bot at all."""
    global _anthropic_client
    if _anthropic_client is None:
        from anthropic import Anthropic
        _anthropic_client = Anthropic()
    return _anthropic_client


# --- Members ------------------------------------------------------------

@dataclass(frozen=True)
class Member:
    """One voice in the committee. kind is 'ollama' or 'haiku'."""
    kind: str
    model: str
    weight: float = 1.0

    @property
    def is_local(self) -> bool:
        return self.kind == "ollama"

    def __str__(self) -> str:
        return self.model


def members_for(backend: str) -> list[Member]:
    """Expand a backend name into the list of members that will vote."""
    if backend == "medgemma":
        return [Member("ollama", config.MEDGEMMA_MODEL, 1.0)]
    if backend == "haiku":
        return [Member("haiku", config.HAIKU_MODEL, 1.0)]
    if backend == "both":
        return [Member("ollama", config.MEDGEMMA_MODEL, 1.0),
                Member("haiku", config.HAIKU_MODEL, 1.0)]
    if backend == "committee":
        out = [Member("ollama", m, w) for m, w in config.COMMITTEE_MODELS]
        if config.COMMITTEE_INCLUDE_HAIKU:
            out.append(Member("haiku", config.HAIKU_MODEL, config.HAIKU_WEIGHT))
        return out
    raise ValueError(f"unknown backend: {backend!r}")


# --- The contract -------------------------------------------------------

# Mammography is technically X-ray but is clinically its own thing with its own
# lexicon, so it gets its own value rather than being forced into "X-ray".
MODALITIES = ("CT", "MRI", "PET", "PET/CT", "Ultrasound", "X-ray", "Mammography",
              "Other", "Unclear")


class Attribute(BaseModel):
    """Domain-specific key/value the active profile asked for — breast density,
    CT window, MRI sequence. A fixed schema slot rather than per-profile fields,
    so grammar-constrained decoding keeps working as profiles are added."""
    label: str = Field(description="e.g. Density, Window, Sequence, View")
    value: str = Field(description="the value, in the reply language")


class WorkupStep(BaseModel):
    step: str = Field(description="What such a finding typically prompts next")
    rationale: str = Field(description="One line: why that step")
    guideline: Optional[str] = Field(
        default=None,
        description="Governing framework, e.g. ACR AC, Fleischner, BI-RADS")


class Finding(BaseModel):
    name: str = Field(description="The label, e.g. oedema, mass, effusion")
    appearance: str = Field(description="What is literally visible on the image")
    confidence: Literal["high", "medium", "low"]
    # Controlled English vocabulary so the workup lookup works regardless of
    # the reply language.
    category: Optional[Literal[workup.CATEGORIES]] = None  # type: ignore[valid-type]
    suggested_workup: list[WorkupStep] = []


class ImageRead(BaseModel):
    is_medical_image: bool
    reject_reason: Optional[str] = None
    modality: Optional[Literal[MODALITIES]] = None  # type: ignore[valid-type]
    modality_confidence: Optional[Literal["high", "medium", "low"]] = None
    modality_evidence: Optional[str] = None
    anatomy: Optional[str] = None
    plane: Optional[str] = None
    sequence_or_phase: Optional[str] = None
    attributes: list[Attribute] = []
    findings: list[Finding] = []
    impression: Optional[str] = None
    caveats: list[str] = []


SYSTEM_PROMPT = """You are a radiology triage assistant for one expert user's \
personal, non-clinical tool. You get a single 2D image — a screenshot. That \
means: no DICOM header, no window/level control, no adjacent slices, no series \
or sequence labels, no clinical history, and probable JPEG compression.

Return ONLY a JSON object matching this schema. No preamble, no markdown \
fences, no trailing commentary.

{
  "is_medical_image": true|false,
  "reject_reason": string|null,
  "modality": "CT"|"MRI"|"PET"|"PET/CT"|"Ultrasound"|"X-ray"|"Other"|"Unclear",
  "modality_confidence": "high"|"medium"|"low",
  "modality_evidence": string,
  "anatomy": string,
  "plane": string|null,
  "sequence_or_phase": string|null,
  "attributes": [{"label": string, "value": string}],
  "findings": [
    {"name": string, "appearance": string, "confidence": "high"|"medium"|"low",
     "category": one of the category values listed in rule 6 (or null),
     "suggested_workup": [{"step": string, "rationale": string,
                           "guideline": string|null}]}
  ],
  "impression": string,
  "caveats": [string]
}

Rules:

1. If it is not a medical or radiological image, set is_medical_image to false, \
put one plain sentence in reject_reason, and leave every other field null or \
empty. Do not analyze a photo of a cat as if it were a scan.

2. modality and anatomy are the reliable half of this task — a single image \
usually determines them. Commit to an answer. Put the visual evidence you \
actually used in modality_evidence (e.g. greyscale attenuation and bone \
density, soft-tissue contrast pattern, sector geometry and speckle, hot-spot \
colour overlay). Use "Unclear" only when you truly cannot tell.

3. plane: axial / coronal / sagittal / oblique, or null. sequence_or_phase: the \
MRI sequence (T1, T2, FLAIR, DWI, SWI...) or CT contrast phase if inferable from \
appearance, else null. Inferring a sequence from appearance is legitimate — say \
so in caveats when it's inference rather than a visible label.

4. findings is the UNRELIABLE half, and you must treat it that way. Only list \
what you can actually see in these pixels. AN EMPTY LIST IS A VALID AND OFTEN \
CORRECT ANSWER — a normal study is normal, and inventing pathology to seem \
useful is the single worst thing you can do here. Keep "name" (the label, e.g. \
oedema, mass) separate from "appearance" (what is literally visible: \
signal/density/echogenicity, margins, location, mass effect, midline shift, \
surrounding change). Set confidence honestly; "low" is expected and fine.

5. Use short, conventional radiological terms for "name" — one or two words, \
the standard term for the finding. Put all the detail in "appearance", not in \
the name.

6. For each finding, set "category" to the single best fit from: mass, nodule, \
cyst, oedema, haemorrhage, infarct, consolidation, effusion, calcification, \
asymmetry, architectural_distortion, fracture, lymphadenopathy, atrophy, \
hydrocephalus, obstruction, inflammation, degenerative_change, \
device_or_foreign_body, other. Use the English value exactly as written, \
whatever language the rest of your answer is in. Use null if nothing fits.

7. {workup_rule}

8. Never state a definitive diagnosis. Hedge everything in findings and \
impression. If several things could explain the appearance, say so rather than \
picking one.

9. caveats: name the SPECIFIC things this particular image cannot settle — not \
boilerplate. A single slice hides everything above and below it; an unknown \
window can erase or fabricate contrast; no contrast timing; no priors to \
compare against; no clinical history; compression artefact can mimic or hide \
subtle findings.

10. attributes: short domain-specific key/value pairs. {attributes_hint} Leave \
the list empty rather than inventing a value you cannot see.

11. Write every human-readable string value in {language}. Keep the JSON keys \
and the enum values (CT, MRI, high, medium, low, ...) in English exactly as \
shown.

=== HOW TO READ THIS PARTICULAR IMAGE ===

{profile_guidance}"""


WORKUP_RULE_ON = """For each finding, "suggested_workup" is what such a \
finding TYPICALLY prompts next, appropriate to the modality of this image. Give \
at most TWO steps, each with one short line of rationale, and name the governing \
framework in "guideline" where you know it (ACR Appropriateness Criteria; or the \
organ system: Fleischner, BI-RADS, LI-RADS, PI-RADS, TI-RADS, Bosniak, O-RADS). \
Frame every step as what a work-up usually involves and what to raise with a \
treating clinician — NEVER as an instruction to a patient, and never as a care \
plan. Do not invent numeric thresholds (nodule size cut-offs, BI-RADS \
categories): describe the step qualitatively and defer to the named framework. \
Leave this list empty when you are not confident the finding is real."""

WORKUP_RULE_OFF = """Leave "suggested_workup" as an empty list for every \
finding. Next steps are supplied from a curated guideline table using the \
category you set in rule 6, so generating them here would waste your output \
budget on something that is discarded. Spend that budget on "appearance" \
instead."""


def system_prompt(profile=None) -> str:
    """The base contract plus the active profile's domain guidance. The profile
    changes WHAT the model is asked to look for, never the output schema — so
    every profile still validates identically and members stay comparable."""
    if profile is None:
        profile = profiles.GENERIC
    return (SYSTEM_PROMPT
            .replace("{workup_rule}",
                     WORKUP_RULE_ON if config.WORKUP_ASK_MODEL else WORKUP_RULE_OFF)
            .replace("{language}", config.IMAGE_LANGUAGE)
            .replace("{attributes_hint}", profile.attributes_hint
                     or profiles.GENERIC.attributes_hint)
            .replace("{profile_guidance}", profile.guidance))


def user_prompt(note: str = "", grounding: str = "") -> str:
    prompt = "Analyze this image. Return only the JSON object."
    if grounding:
        # Grounding goes BEFORE the user's note: it is measurement, and should
        # frame the read rather than answer a question inside it.
        prompt += ("\n\n=== MEASURED SEGMENTATION (not your own estimate) ===\n"
                   + grounding)
    if note:
        prompt += ("\n\nThe user sent this along with it — take it into account, "
                   f"but still return the full JSON object:\n{note}")
    return prompt


_FENCE_RE = re.compile(r"```(?:json)?", re.IGNORECASE)


def _balanced_end(fragment: str) -> int:
    """Index of the brace closing the object that starts at position 0, or -1
    if the text runs out first (i.e. the model was cut off)."""
    depth, in_str, esc = 0, False, False
    for i, ch in enumerate(fragment):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch in "{[":
            depth += 1
        elif ch in "}]":
            depth -= 1
            if depth == 0:
                return i
            if depth < 0:
                return -1
    return -1


def _closers(text: str):
    """The closing brackets `text` still owes, or None if it ends mid-string or
    is already unbalanced the wrong way."""
    stack, in_str, esc = [], False, False
    for ch in text:
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch in "{[":
            stack.append("}" if ch == "{" else "]")
        elif ch in "}]":
            if not stack:
                return None
            stack.pop()
    if in_str or not stack:
        return None
    return "".join(reversed(stack))


_TRAILING_KEY = re.compile(r'\s*"[^"]*"\s*:\s*$')


def _repair(fragment: str, max_attempts: int = 400):
    """Best-effort close of truncated JSON.

    Retry at successive structural boundaries, latest first, closing whatever is
    still open. Retrying rather than computing one cut point matters: a cut
    inside a key leaves a dangling key that a single pass can't undo, but
    stepping back one boundary lands on solid ground. A read that reached
    modality, anatomy and two of three findings beats an exception.
    """
    cuts = [i for i, ch in enumerate(fragment) if ch in ',}]"']
    for pos in reversed(cuts[-max_attempts:]):
        # A comma is cut before; anything else is cut after.
        prefix = fragment[:pos] if fragment[pos] == "," else fragment[:pos + 1]
        for _ in range(2):
            prefix = _TRAILING_KEY.sub("", prefix.rstrip()).rstrip().rstrip(",")
        closing = _closers(prefix)
        if closing is None:
            continue
        try:
            return json.loads(prefix + closing)
        except json.JSONDecodeError:
            continue
    return None


def _loads(text: str) -> dict:
    """Models wrap JSON in fences or prose despite instructions, and a model cut
    off by a token budget emits JSON that is valid right up to where it stopped.

    Note rfind('}') is NOT usable here: on truncated output the last brace
    belongs to a nested object, so slicing to it yields structurally broken JSON
    and a misleading "expecting ',' delimiter" instead of an honest "this was
    truncated". It also breaks on trailing prose containing a brace.
    """
    cleaned = _FENCE_RE.sub("", text).strip()
    start = cleaned.find("{")
    if start == -1:
        raise ValueError(f"no JSON object in model output: {text[:200]!r}")

    fragment = cleaned[start:]
    end = _balanced_end(fragment)
    if end != -1:
        try:
            return json.loads(fragment[:end + 1])
        except json.JSONDecodeError as exc:
            raise ValueError(f"malformed JSON in model output: {exc}") from exc

    data = _repair(fragment)
    if isinstance(data, dict):
        logger.warning(
            "model output was truncated (%d chars); recovered a partial read. "
            "Raise OLLAMA_NUM_PREDICT if this recurs.", len(fragment))
        # Say so on the card: a silently partial read is worse than a visibly
        # partial one.
        if not isinstance(data.get("caveats"), list):
            data["caveats"] = []
        data["caveats"].append(
            "The model's answer was cut off by the output limit, so this read "
            "is incomplete.")
        return data

    raise ValueError(
        f"model output was truncated after {len(fragment)} characters and could "
        "not be recovered. Raise OLLAMA_NUM_PREDICT (or set "
        "WORKUP_ASK_MODEL=false, which roughly halves the response size).")


def parse(text: str) -> ImageRead:
    """A member that drifts off-schema should fail loudly here, not render as a
    plausible half-empty card."""
    try:
        return ImageRead.model_validate(_loads(text))
    except ValidationError as exc:
        raise ValueError(f"model output didn't match the schema: {exc}") from exc


# --- Image preprocessing ------------------------------------------------

@dataclass
class PreparedImage:
    """Prepared once, reused by every member. Downscaling a 4000px screenshot
    once instead of letting N models each resize it is free time on CPU, and
    the base64 encode is done once for all API calls."""
    data: bytes
    media_type: str
    b64: str
    resized_from: Optional[tuple[int, int]] = None
    # Additional slices from a DICOM series, in anatomical order. The primary
    # image above stays first; these are sent alongside it so the model sees
    # actual 3D context instead of guessing what is above and below.
    extras: list = field(default_factory=list)   # [PreparedImage]

    @property
    def all_images(self) -> list:
        return [self] + list(self.extras)


def prepare_image(image_bytes: bytes, media_type: str) -> PreparedImage:
    data, resized_from = image_bytes, None

    if config.IMAGE_MAX_DIM > 0:
        try:
            from PIL import Image
            img = Image.open(io.BytesIO(image_bytes))
            w, h = img.size
            if max(w, h) > config.IMAGE_MAX_DIM:
                scale = config.IMAGE_MAX_DIM / max(w, h)
                # LANCZOS: downscaling a scan with a cheap filter can introduce
                # aliasing that looks like texture the model then "finds".
                img = img.convert("RGB").resize(
                    (max(1, int(w * scale)), max(1, int(h * scale))),
                    Image.LANCZOS)
                buf = io.BytesIO()
                img.save(buf, format="JPEG", quality=92)
                data, media_type, resized_from = buf.getvalue(), "image/jpeg", (w, h)
        except ImportError:
            # Pillow is optional. Without it we just send the original.
            logger.debug("Pillow not installed; sending image at original size")
        except Exception:
            logger.warning("Image resize failed; sending original", exc_info=True)

    return PreparedImage(data=data, media_type=media_type,
                         b64=base64.standard_b64encode(data).decode("ascii"),
                         resized_from=resized_from)


# --- Running one member -------------------------------------------------

def _ollama_sync(model: str, img: PreparedImage, note: str, keep_alive: str,
                 profile=None, grounding: str = "") -> ImageRead:
    # The Ollama Python SDK takes raw bytes directly. Passing a base64 *string*
    # also works, but the SDK first checks whether a str is a file path, so
    # bytes avoids that guessing entirely.
    resp = _ollama().chat(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt(profile)},
            {"role": "user", "content": user_prompt(note, grounding),
             "images": [i.data for i in img.all_images]},
        ],
        # Grammar-constrained decoding: the schema is enforced by the sampler,
        # not merely requested in the prompt. Essential at 4B.
        format=ImageRead.model_json_schema(),
        options={
            "num_ctx": config.OLLAMA_NUM_CTX,
            "num_predict": config.OLLAMA_NUM_PREDICT,
            # Google's default for Gemma 3 is 1.0. Lowered deliberately: a
            # diagnostic read that says something different each time you send
            # the same image is worse than useless. Not zero, because
            # COMMITTEE_REPEATS>1 needs some variation to measure stability.
            "temperature": 0.3,
        },
        keep_alive=keep_alive,
    )
    return parse(resp["message"]["content"])


async def analyze_ollama(model: str, img: PreparedImage, note: str = "",
                         keep_alive: Optional[str] = None, profile=None,
                         grounding: str = "") -> ImageRead:
    if keep_alive is None:
        keep_alive = config.OLLAMA_KEEP_ALIVE
    async with _ollama_lock:
        # to_thread: the Ollama client is synchronous and this takes minutes on
        # CPU. Blocking the event loop that long would kill Telegram polling.
        return await asyncio.to_thread(_ollama_sync, model, img, note,
                                       keep_alive, profile, grounding)


def _haiku_sync(model: str, img: PreparedImage, note: str, profile=None,
                grounding: str = "") -> ImageRead:
    resp = _anthropic().messages.create(
        model=model,
        max_tokens=config.HAIKU_MAX_TOKENS,
        system=system_prompt(profile),
        messages=[{
            "role": "user",
            # Images before text: documented to work better than the reverse.
            "content": [
                {"type": "image",
                 "source": {"type": "base64", "media_type": i.media_type,
                            "data": i.b64}}
                for i in img.all_images
            ] + [
                {"type": "text", "text": user_prompt(note, grounding)},
            ],
        }],
    )
    text = "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    return parse(text)


async def analyze_haiku(model: str, img: PreparedImage, note: str = "",
                        profile=None, grounding: str = "") -> ImageRead:
    # No lock: network call, holds no local resources, and serializing it would
    # only make the committee slower.
    return await asyncio.to_thread(_haiku_sync, model, img, note, profile,
                                   grounding)


async def analyze_member(member: Member, img: PreparedImage, note: str = "",
                         keep_alive: Optional[str] = None, profile=None,
                         grounding: str = "") -> ImageRead:
    if member.is_local:
        return await analyze_ollama(member.model, img, note, keep_alive, profile,
                                    grounding)
    return await analyze_haiku(member.model, img, note, profile, grounding)


# --- Triage: which profile does this image need? ------------------------

class TriageRead(BaseModel):
    """Deliberately tiny. Modality and region are the reliable half of the
    task, this asks for nothing else, and a short output is what makes the pass
    cheap — on CPU, generation dominates once the image is encoded."""
    modality: Literal[MODALITIES]  # type: ignore[valid-type]
    region: Literal[profiles.REGIONS]  # type: ignore[valid-type]


TRIAGE_SYSTEM = """Classify this medical image. Return ONLY a JSON object:

{"modality": one of CT, MRI, PET, PET/CT, Ultrasound, X-ray, Mammography, \
Other, Unclear,
 "region": one of head, chest, breast, abdomen, pelvis, musculoskeletal, \
spine, other, unclear}

Judge only from what is visible. A mammogram is "Mammography" + "breast", not \
"X-ray". If the image is not medical at all, use "Other" and "other". No \
explanation, no other fields."""


def _triage_ollama_sync(model: str, img: PreparedImage) -> TriageRead:
    resp = _ollama().chat(
        model=model,
        messages=[{"role": "system", "content": TRIAGE_SYSTEM},
                  {"role": "user", "content": "Classify.", "images": [img.data]}],
        format=TriageRead.model_json_schema(),
        # Short output is the whole point: this must not cost a full read.
        options={"num_ctx": config.OLLAMA_NUM_CTX, "num_predict": 64,
                 "temperature": 0.0},
        keep_alive=config.OLLAMA_KEEP_ALIVE,
    )
    return TriageRead.model_validate(_loads(resp["message"]["content"]))


def _triage_haiku_sync(model: str, img: PreparedImage) -> TriageRead:
    resp = _anthropic().messages.create(
        model=model, max_tokens=100, system=TRIAGE_SYSTEM,
        messages=[{"role": "user", "content": [
            {"type": "image", "source": {"type": "base64",
                                         "media_type": img.media_type,
                                         "data": img.b64}},
            {"type": "text", "text": "Classify."}]}])
    text = "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    return TriageRead.model_validate(_loads(text))


async def triage(member: Member, img: PreparedImage) -> TriageRead:
    if member.is_local:
        async with _ollama_lock:
            return await asyncio.to_thread(_triage_ollama_sync, member.model, img)
    return await asyncio.to_thread(_triage_haiku_sync, member.model, img)


def pick_triage_member(members: list) -> Optional[Member]:
    """Prefer an API member: seconds and a fraction of a cent, versus another
    full image encode on CPU. Falls back to the first local member, which does
    cost real time — hence PROFILE_MODE can be set to a fixed profile to skip
    triage entirely."""
    for m in members:
        if not m.is_local:
            return m
    return members[0] if members else None


# --- Startup checks -----------------------------------------------------

# Architectures that a current Ollama will pull happily, report as vision-
# capable, and then fail to LOAD. The capability check can't see these because
# the manifest is fine — only the llama.cpp runtime underneath is missing them.
#
# mllama is Llama 3.2 Vision. Ollama v0.30.0 moved model loading onto
# llama.cpp, and mllama was never in llama.cpp's architecture registry — Ollama
# had carried it in their own engine and never upstreamed it. So this one is
# NOT fixed by updating; updating is what breaks it. Rolling Ollama back would
# recover it, but at the risk of losing newer models like medgemma1.5.
KNOWN_BAD_ARCH = {
    "mllama": (
        "Llama 3.2 Vision. Ollama moved loading onto llama.cpp in v0.30.0 and "
        "mllama isn't in llama.cpp's architecture registry, so this fails at "
        "load with \"unknown model architecture: 'mllama'\". Updating does not "
        "fix it — updating is what broke it. Use a different vision model "
        "(gemma3:4b, qwen2.5vl:7b, minicpm-v). Note it is also ~7.8GB, which "
        "does not fit an 8GB box regardless."),
}

# Common Ollama failures, mapped to something actionable. Shown on the card
# next to the raw error, because the raw error alone sends you off updating
# things that won't help.
ERROR_HINTS = (
    ("unknown model architecture",
     "This model's architecture isn't supported by the llama.cpp runtime under "
     "Ollama. Updating usually will NOT fix it. Remove this model from the "
     "committee."),
    ("requires more system memory",
     "The model is too large for this machine's RAM. Use a smaller one, or set "
     "OLLAMA_MAX_LOADED_MODELS=1 and OLLAMA_KEEP_ALIVE=0."),
    ("connection refused",
     "Ollama isn't running or isn't reachable at OLLAMA_HOST."),
    ("not found, try pulling",
     "The model isn't pulled on this machine."),
)


def error_hint(message: str) -> Optional[str]:
    low = (message or "").lower()
    for needle, hint in ERROR_HINTS:
        if needle in low:
            return hint
    return None


def _architecture(info) -> Optional[str]:
    """general.architecture from `ollama show`, across SDK versions."""
    mi = getattr(info, "modelinfo", None) or getattr(info, "model_info", None)
    if mi is None and isinstance(info, dict):
        mi = info.get("modelinfo") or info.get("model_info")
    if isinstance(mi, dict):
        arch = mi.get("general.architecture")
        if arch:
            return str(arch).lower()
    details = getattr(info, "details", None)
    if details is None and isinstance(info, dict):
        details = info.get("details")
    if isinstance(details, dict) and details.get("family"):
        return str(details["family"]).lower()
    return None


def smoke_test(models: list[str]) -> list[str]:
    """Actually load each model and run one token against a tiny image.

    The capability check reads metadata; this proves the thing runs. It's the
    only way to catch a load-time failure generically, but it costs a real model
    load per member — minutes on CPU — so it's opt-in via STARTUP_SMOKE_TEST.
    """
    if not models:
        return []
    # 1x1 white PNG, smallest valid image that still exercises the vision path.
    tiny = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
    problems = []
    for model in models:
        try:
            _ollama().chat(
                model=model,
                messages=[{"role": "user", "content": "hi", "images": [tiny]}],
                options={"num_predict": 1, "num_ctx": 512},
                keep_alive="0",  # don't hold RAM after the probe
            )
            logger.info("smoke test ok: %s", model)
        except Exception as exc:
            hint = error_hint(str(exc))
            msg = f"Model {model!r} failed to run: {str(exc)[:200]}"
            if hint:
                msg += f"\n    -> {hint}"
            problems.append(msg)
    return problems


def check_models(models: list[str]) -> list[str]:
    """Catch the two failure modes that otherwise surface as a confusing reply
    to your first photo: model not pulled, and model pulled but text-only."""
    if not models:
        return []
    try:
        client = _ollama()
        installed = {m.get("model", "") for m in client.list().get("models", [])}
    except Exception as exc:
        return [f"Can't reach Ollama at {config.OLLAMA_HOST}: {exc}"]

    problems = []
    for model in models:
        if model not in installed and f"{model}:latest" not in installed:
            problems.append(f"Model {model!r} isn't pulled. Run:  ollama pull {model}")
            continue

        # The GGUF trap: Ollama can't attach a separate mmproj projector to a
        # gemma3 model, so an HF GGUF loads text-only and then cheerfully
        # describes images it never saw. Catch it now rather than trusting a
        # blind read — and in a committee, one blind member poisons the vote.
        try:
            info = client.show(model)

            # Check the architecture BEFORE the capability check: a model can
            # report vision capability and still be unloadable, which is exactly
            # the mllama case and exactly what this check exists to catch.
            arch = _architecture(info)
            if arch in KNOWN_BAD_ARCH:
                problems.append(
                    f"Model {model!r} uses the {arch!r} architecture, which will "
                    f"NOT load. {KNOWN_BAD_ARCH[arch]}")
                continue

            caps = _capabilities(info)
            if caps is not None and "vision" not in caps:
                problems.append(
                    f"Model {model!r} has NO VISION capability (capabilities: "
                    f"{sorted(caps) or 'none'}). It would describe images it "
                    "cannot see. This is what you get from the HuggingFace "
                    "GGUFs — use an Ollama library model instead.")
        except Exception as exc:
            # Don't block startup on an introspection quirk across versions.
            logger.warning("Couldn't verify vision capability for %s: %s", model, exc)
    return problems


def _capabilities(info) -> Optional[set]:
    """Ollama's show() shape has moved around across versions. Return None when
    we genuinely can't tell, so we warn only on a definite negative."""
    caps = getattr(info, "capabilities", None)
    if caps is None and isinstance(info, dict):
        caps = info.get("capabilities")
    if caps:
        return {str(c).lower() for c in caps}
    # Older Ollama: no capabilities list, but a projector section implies vision.
    proj = getattr(info, "projector_info", None)
    if proj is None and isinstance(info, dict):
        proj = info.get("projector_info")
    if proj:
        return {"completion", "vision"}
    return None

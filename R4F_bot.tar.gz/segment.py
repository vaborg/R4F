"""Anatomical segmentation for chest radiographs, with a colour overlay.

Uses TorchXRayVision's PSPNet, trained on ChestX-Det (3575 radiographs
annotated by three board-certified radiologists). It returns 14 named
structures at 512x512.

Why this model and not TotalSegmentator: TotalSegmentator knows far more
anatomy (117 CT classes) but takes NIfTI volumes or DICOM folders. A chest
radiograph is natively 2D, so nothing is lost by it arriving as a screenshot —
which makes it the one anatomy task that works at all on this input.

Two outputs, for two different consumers:

  * OVERLAY (for you) — translucent colour fill plus a solid contour per
    structure, with a legend baked into the image so the colour mapping is
    exact rather than approximated by emoji.
  * ANNOTATION (for the language model) — measured position, area and size, and
    a derived cardiothoracic ratio. This is the point of the whole exercise: a
    VLM cannot measure, and here it no longer has to guess.

torch is an optional dependency. Without it this module reports unavailable and
the bot carries on exactly as before.
"""
import io
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# Model output order. Read from the model at runtime; this is the fallback and
# the key for the palette.
STRUCTURES = (
    "Left Clavicle", "Right Clavicle", "Left Scapula", "Right Scapula",
    "Left Lung", "Right Lung", "Left Hilus Pulmonis", "Right Hilus Pulmonis",
    "Heart", "Aorta", "Facies Diaphragmatica", "Mediastinum", "Weasand", "Spine",
)

# Colours are chosen to match Telegram's coloured square/circle emoji, so the
# text legend in the chat is EXACT rather than an approximation. Seven usable
# hues (black and white are useless on a greyscale radiograph) times two shapes
# gives exactly the 14 markers needed.
# Colours are keyed to Telegram's coloured square/circle emoji so the text
# legend in the chat matches the overlay. Seven usable hues (black and white
# are useless on a greyscale radiograph) x two emoji shapes gives the 14 markers
# needed. The circle set is DARKENED, because emoji shape disambiguates in text
# but not on the image itself — without this, Heart and Left Clavicle would
# paint the identical red. Value is (rgb, emoji, shape).
def _dark(rgb, f=0.55):
    return tuple(int(c * f) for c in rgb)


_HUES = [
    ((229, 66, 56), "🟥", "🔴"),    # red
    ((243, 146, 55), "🟧", "🟠"),   # orange
    ((247, 203, 76), "🟨", "🟡"),   # yellow
    ((120, 177, 89), "🟩", "🟢"),   # green
    ((61, 133, 198), "🟦", "🔵"),   # blue
    ((150, 99, 191), "🟪", "🟣"),   # purple
    ((150, 105, 79), "🟫", "🟤"),   # brown
]

# Large / soft-tissue structures take the bright squares; smaller and bony ones
# take the darkened circles.
_SQUARE_SET = ("Heart", "Facies Diaphragmatica", "Mediastinum", "Left Lung",
               "Right Lung", "Aorta", "Weasand")
_CIRCLE_SET = ("Left Clavicle", "Right Clavicle", "Left Scapula",
               "Right Scapula", "Spine", "Left Hilus Pulmonis",
               "Right Hilus Pulmonis")

PALETTE = {}
for _i, _name in enumerate(_SQUARE_SET):
    _rgb, _sq, _ci = _HUES[_i]
    PALETTE[_name] = (_rgb, _sq, "square")
for _i, _name in enumerate(_CIRCLE_SET):
    _rgb, _sq, _ci = _HUES[_i]
    PALETTE[_name] = (_dark(_rgb), _ci, "circle")


RU_NAMES = {
    "Left Clavicle": "Левая ключица", "Right Clavicle": "Правая ключица",
    "Left Scapula": "Левая лопатка", "Right Scapula": "Правая лопатка",
    "Left Lung": "Левое лёгкое", "Right Lung": "Правое лёгкое",
    "Left Hilus Pulmonis": "Левый корень лёгкого",
    "Right Hilus Pulmonis": "Правый корень лёгкого",
    "Heart": "Сердце", "Aorta": "Аорта",
    "Facies Diaphragmatica": "Диафрагма", "Mediastinum": "Средостение",
    "Weasand": "Пищевод", "Spine": "Позвоночник",
}


def display_name(structure: str, language: str) -> str:
    if language == "Russian":
        return RU_NAMES.get(structure, structure)
    return structure


@dataclass
class Structure:
    name: str
    emoji: str
    colour: tuple
    area: float            # fraction of the image
    centroid: tuple        # (x, y) normalised 0..1
    bbox: tuple            # (x0, y0, x1, y1) normalised 0..1
    shape: str = "square"  # legend swatch shape, mirrors the emoji

    @property
    def width(self) -> float:
        return self.bbox[2] - self.bbox[0]


@dataclass
class Result:
    overlay_png: bytes
    structures: list
    missing: list
    ctr: Optional[float] = None
    notes: list = field(default_factory=list)


_model = None


def available() -> bool:
    try:
        import torch  # noqa: F401
        import torchxrayvision  # noqa: F401
        return True
    except ImportError:
        return False


def _load():
    """Lazy and cached. Loading costs RAM that competes with Ollama, so it
    happens on first use rather than at import, and only when a chest
    radiograph actually arrives."""
    global _model
    if _model is None:
        import torchxrayvision as xrv
        logger.info("loading PSPNet chest segmentation model (first use)")
        _model = xrv.baseline_models.chestx_det.PSPNet()
        _model.eval()
    return _model


def unload():
    """Free the weights. Worth calling on an 8GB box if you also run Ollama."""
    global _model
    _model = None


# --- Preprocessing ------------------------------------------------------

def _prepare(image_bytes: bytes, size: int = 512):
    """Centre-crop to square, resize, and scale to the [-1024, 1024] range the
    model expects. Done with PIL rather than the library's own transforms to
    avoid pulling in skimage and to keep the geometry identical to what the
    overlay is drawn on."""
    import numpy as np
    from PIL import Image

    img = Image.open(io.BytesIO(image_bytes)).convert("L")
    w, h = img.size
    side = min(w, h)
    left, top = (w - side) // 2, (h - side) // 2
    img = img.crop((left, top, left + side, top + side)).resize(
        (size, size), Image.BILINEAR)

    arr = np.asarray(img, dtype=np.float32)
    tensor = (2 * (arr / 255.0) - 1.0) * 1024.0
    return img, tensor[None, None, ...]


def _stats(mask, size: int):
    """Area fraction, centroid and bounding box, all normalised."""
    import numpy as np
    ys, xs = np.nonzero(mask)
    if xs.size == 0:
        return None
    total = float(size * size)
    return (xs.size / total,
            (float(xs.mean()) / size, float(ys.mean()) / size),
            (float(xs.min()) / size, float(ys.min()) / size,
             float(xs.max() + 1) / size, float(ys.max() + 1) / size))


# --- Overlay ------------------------------------------------------------

def _contour(mask_img):
    """Boundary = mask minus its erosion. MinFilter is a 3x3 erosion on an 'L'
    image, which avoids a scipy dependency."""
    from PIL import Image, ImageChops, ImageFilter
    eroded = mask_img.filter(ImageFilter.MinFilter(3))
    return ImageChops.difference(mask_img, eroded)


def _render(base_gray, hits, alpha: float, language: str, size: int = 512):
    """Translucent fill plus a solid contour, largest structure first so small
    ones stay visible on top. Legend is drawn into the image, because Telegram
    cannot render arbitrary colours in text."""
    from PIL import Image

    canvas = base_gray.convert("RGB")

    # Large structures first: mediastinum overlaps heart, aorta and spine, and
    # painting it last would bury them.
    for s, mask_img in sorted(hits, key=lambda h: -h[0].area):
        fill = Image.new("RGB", canvas.size, s.colour)
        # paste() with an 'L' mask alpha-blends per pixel, so scaling the mask
        # by alpha gives the translucent wash.
        canvas.paste(fill, (0, 0), mask_img.point(lambda v: int(v * alpha)))
        # Solid contour on top: the fill alone gets muddy where regions overlap.
        canvas.paste(fill, (0, 0), _contour(mask_img))

    return _with_legend(canvas, [h[0] for h in hits], language)


def _with_legend(canvas, structures, language: str):
    """Colour swatch + label strip under the image."""
    from PIL import Image, ImageDraw, ImageFont

    if not structures:
        return canvas

    try:
        font = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
    except Exception:
        font = ImageFont.load_default()

    w = canvas.width
    cols = 2
    rows = (len(structures) + cols - 1) // cols
    row_h, pad = 20, 10
    strip_h = rows * row_h + 2 * pad

    out = Image.new("RGB", (w, canvas.height + strip_h), (18, 18, 18))
    out.paste(canvas, (0, 0))
    draw = ImageDraw.Draw(out)

    col_w = w // cols
    for i, s in enumerate(sorted(structures, key=lambda s: -s.area)):
        col, row = i % cols, i // cols
        x = col * col_w + pad
        y = canvas.height + pad + row * row_h
        box = [x, y + 3, x + 13, y + 16]
        if s.shape == "circle":
            draw.ellipse(box, fill=s.colour, outline=(230, 230, 230))
        else:
            draw.rectangle(box, fill=s.colour, outline=(230, 230, 230))
        draw.text((x + 19, y + 2), display_name(s.name, language),
                  fill=(235, 235, 235), font=font)
    return out


# --- Entry point --------------------------------------------------------

def segment(image_bytes: bytes, threshold: float = 0.5, alpha: float = 0.35,
            min_area: float = 0.002, language: str = "English") -> Result:
    """Blocking and CPU-heavy. Call via asyncio.to_thread."""
    import numpy as np
    import torch
    from PIL import Image

    model = _load()
    base_gray, tensor = _prepare(image_bytes)

    with torch.no_grad():
        logits = model(torch.from_numpy(tensor))

    # 14 INDEPENDENT binary masks, not one mutually exclusive labelling —
    # mediastinum genuinely contains heart, aorta and spine, so an argmax here
    # would silently delete structures.
    probs = torch.sigmoid(logits)[0].cpu().numpy()
    names = list(getattr(model, "targets", STRUCTURES))

    hits, missing = [], []
    size = probs.shape[-1]
    for i, name in enumerate(names):
        mask = probs[i] > threshold
        st = _stats(mask, size)
        if st is None or st[0] < min_area:
            missing.append(name)
            continue
        colour, emoji, shape = PALETTE.get(name, ((200, 200, 200), "⬜", "square"))
        area, centroid, bbox = st
        hits.append((
            Structure(name=name, emoji=emoji, colour=colour, area=area,
                      centroid=centroid, bbox=bbox, shape=shape),
            Image.fromarray((mask * 255).astype(np.uint8), mode="L"),
        ))

    overlay = _render(base_gray, hits, alpha, language, size)
    buf = io.BytesIO()
    overlay.save(buf, format="PNG")

    structures = [h[0] for h in hits]
    ctr, notes = _cardiothoracic(structures)
    return Result(overlay_png=buf.getvalue(), structures=structures,
                  missing=missing, ctr=ctr, notes=notes)


def _cardiothoracic(structures):
    """Approximate cardiothoracic ratio: cardiac width over thoracic width.

    This is the one genuinely quantitative thing the segmenter buys — a VLM
    cannot measure. It is approximate: the true CTR uses maximal cardiac
    diameter and maximal INTERNAL thoracic diameter at the diaphragm, and it is
    only interpretable on a PA film, because an AP projection magnifies the
    heart. Both caveats are returned rather than assumed away.
    """
    by_name = {s.name: s for s in structures}
    heart = by_name.get("Heart")
    lungs = [by_name.get("Left Lung"), by_name.get("Right Lung")]
    lungs = [l for l in lungs if l]
    if not heart or not lungs:
        return None, []

    thorax = max(l.bbox[2] for l in lungs) - min(l.bbox[0] for l in lungs)
    if thorax <= 0:
        return None, []
    ratio = heart.width / thorax
    return ratio, [
        "CTR is approximate: measured from segmentation bounding boxes, not "
        "from the true maximal cardiac and internal thoracic diameters.",
        "CTR is only interpretable on a PA projection — an AP film magnifies "
        "the cardiac silhouette.",
    ]


# --- Outputs ------------------------------------------------------------

def legend_text(result: Result, language: str) -> str:
    """For the Telegram message. Emoji markers match the overlay colours
    exactly, which is why the palette was chosen around them."""
    if not result.structures:
        return ""
    ru = language == "Russian"
    head = "🩻 <b>Сегментация анатомии</b>" if ru else "🩻 <b>Anatomy segmentation</b>"
    lines = [head]
    for s in sorted(result.structures, key=lambda s: -s.area):
        lines.append(f"{s.emoji} {display_name(s.name, language)} "
                     f"<i>{s.area * 100:.1f}%</i>")
    if result.ctr is not None:
        label = "КТИ (приблизительно)" if ru else "Cardiothoracic ratio (approx.)"
        lines.append(f"\n<b>{label}: {result.ctr:.2f}</b>")
    if result.missing:
        label = "не выделено" if ru else "not located"
        names = ", ".join(display_name(n, language) for n in result.missing)
        lines.append(f"\n<i>{label}: {names}</i>")
    return "\n".join(lines)


def annotation(result: Result) -> str:
    """Grounding block for the language model. Always English and always
    quantitative — this is data for a model, not prose for a person."""
    if not result.structures:
        return ""

    lines = [
        "A dedicated chest-radiograph segmentation model (TorchXRayVision "
        "PSPNet, trained on ChestX-Det) located the following structures on "
        "THIS image. Coordinates are normalised 0-1, with x from left to right "
        "and y from top to bottom of the image as displayed.",
        "",
    ]
    for s in sorted(result.structures, key=lambda s: -s.area):
        lines.append(
            f"- {s.name}: area {s.area * 100:.1f}% of field, "
            f"centroid (x={s.centroid[0]:.2f}, y={s.centroid[1]:.2f}), "
            f"bbox x {s.bbox[0]:.2f}-{s.bbox[2]:.2f}, "
            f"y {s.bbox[1]:.2f}-{s.bbox[3]:.2f}")

    if result.ctr is not None:
        lines.append("")
        lines.append(f"Derived cardiothoracic ratio: {result.ctr:.2f} "
                     "(cardiac width / thoracic width).")

    if result.missing:
        lines.append("")
        lines.append("NOT located by the segmenter: " + ", ".join(result.missing))

    lines += [
        "",
        "How to use this:",
        "- These positions and sizes are MEASURED. Prefer them over your own "
        "impression of where something is or how large it is, and use them "
        "when describing location.",
        "- The segmenter finds ANATOMY ONLY. It does not detect pathology, so "
        "it neither confirms nor excludes any finding.",
        "- A structure listed as not located is ambiguous: it may be genuinely "
        "obscured (loss of a normal border is itself a finding — the "
        "silhouette sign), or the segmenter may simply have failed. Do not "
        "treat absence as evidence either way; say which you cannot "
        "distinguish.",
    ]
    if result.notes:
        lines.append("- " + " ".join(result.notes))
    return "\n".join(lines)

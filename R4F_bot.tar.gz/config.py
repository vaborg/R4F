"""All tunables, read from the environment. Fails loud at import on bad input."""
import os

# Load .env if python-dotenv is installed. Without this, a filled-in .env sits
# on disk doing nothing and the bot exits complaining the vars are unset.
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")

# medgemma  -> the single local model, free, private, minutes on CPU
# haiku     -> Claude API, seconds, ~$0.01/image, best instruction-following
# both      -> medgemma + haiku, two cards plus a consensus card
# committee -> every model in COMMITTEE_MODELS (+ haiku if enabled), with
#              weighted consensus. The accurate-but-slow option.
BACKENDS = ("medgemma", "haiku", "both", "committee")
IMAGE_BACKEND = os.environ.get("IMAGE_BACKEND", "haiku").strip().lower()

# --- Local models (Ollama) ----------------------------------------------

OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")

# MUST be Ollama *library* models. The HuggingFace GGUFs load TEXT-ONLY —
# Ollama doesn't support separate mmproj projector files for gemma3 — and then
# happily describe an image they never saw. See README "The GGUF trap".
MEDGEMMA_MODEL = os.environ.get("MEDGEMMA_MODEL", "medgemma1.5:4b")

# One image plus a short JSON reply. Nowhere near the 128K these models
# advertise, and on an 8GB box a smaller window is real RAM saved.
OLLAMA_NUM_CTX = int(os.environ.get("OLLAMA_NUM_CTX", "4096"))

# Hard cap on generated tokens. Insurance against a model that rambles, which
# costs minutes on CPU.
#
# Grammar-constrained decoding guarantees the SHAPE of what is emitted, but not
# that the model finishes within budget: hit this cap mid-object and you get
# JSON that is valid right up to where it stopped. analyzer._loads recovers a
# partial read from that, but the real fix is enough headroom. A full response
# with several findings, attributes and caveats runs well past 1200 — and
# non-English output costs more tokens per character, so Russian needs more
# room than English for the same content.
OLLAMA_NUM_PREDICT = int(os.environ.get("OLLAMA_NUM_PREDICT", "3000"))

# Unload promptly. If anything else on this machine uses Ollama (a qwen3:8b
# digest, say), 3.3GB sitting resident is the difference between working and
# swapping. Note: with a multi-model committee the scheduler overrides this to
# evict each model right after its last run — see committee.plan().
OLLAMA_KEEP_ALIVE = os.environ.get("OLLAMA_KEEP_ALIVE", "30s")

# CPU-only vision inference is slow. Be generous or you'll time out mid-read.
OLLAMA_TIMEOUT = int(os.environ.get("OLLAMA_TIMEOUT", "900"))

# Actually load and run each local model at startup, not just read its
# metadata. Catches load-time failures the capability check can't see (a model
# can report vision support and still refuse to load). Costs one real model
# load per member — minutes on CPU — so it's off by default.
STARTUP_SMOKE_TEST = os.environ.get(
    "STARTUP_SMOKE_TEST", "false").lower() in ("1", "true", "yes")

# --- Committee ----------------------------------------------------------

# Comma-separated Ollama models, each with an optional =weight (default 1).
# Weight is voting power in the consensus, NOT the number of runs.
#
#   COMMITTEE_MODELS=medgemma1.5:4b=3,gemma3:4b=1,minicpm-v=1
#
# Weight the medically-tuned model above the general ones, or a bare majority
# of general models will outvote it on medical findings. See README.
COMMITTEE_MODELS_RAW = os.environ.get("COMMITTEE_MODELS", "medgemma1.5:4b=2")

COMMITTEE_INCLUDE_HAIKU = os.environ.get(
    "COMMITTEE_INCLUDE_HAIKU", "true").lower() in ("1", "true", "yes")
HAIKU_WEIGHT = float(os.environ.get("HAIKU_WEIGHT", "2"))

# Runs per member. >1 is self-consistency: the same model on the same image,
# so a finding that appears in 1 of 3 runs is noise you can now see. Costs
# linearly in time, but repeats of one model are cheap-ish because the
# scheduler keeps it loaded across them.
COMMITTEE_REPEATS = int(os.environ.get("COMMITTEE_REPEATS", "1"))

# Findings below this share of total voting weight are dropped from the
# consensus card. 0 keeps everything (each item still shows its agreement),
# 0.5 means "more than half the committee saw it".
COMMITTEE_MIN_AGREEMENT = float(os.environ.get("COMMITTEE_MIN_AGREEMENT", "0.0"))

# Post each member's own card as it lands, before the consensus. Off gives you
# only the consensus, much less noisy on a 4-member committee.
COMMITTEE_SHOW_MEMBERS = os.environ.get(
    "COMMITTEE_SHOW_MEMBERS", "true").lower() in ("1", "true", "yes")

# Two finding names count as the same finding above this string similarity.
# Crude but language-agnostic; see README "Matching findings".
COMMITTEE_MATCH_THRESHOLD = float(os.environ.get("COMMITTEE_MATCH_THRESHOLD", "0.82"))


def parse_members(raw: str) -> list[tuple[str, float]]:
    """'medgemma1.5:4b=3, gemma3:4b' -> [('medgemma1.5:4b', 3.0), ('gemma3:4b', 1.0)]

    Model tags contain colons, so weight is separated with '=' instead.
    Duplicate models are merged rather than silently voting twice.
    """
    members: list[tuple[str, float]] = []
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        model, _, weight = chunk.partition("=")
        model = model.strip()
        if not model:
            continue
        try:
            w = float(weight) if weight.strip() else 1.0
        except ValueError:
            raise ValueError(
                f"bad weight in COMMITTEE_MODELS entry {chunk!r} — "
                "use model=number, e.g. medgemma1.5:4b=3")
        if w <= 0:
            raise ValueError(f"weight must be positive in {chunk!r}")
        for i, (existing, ew) in enumerate(members):
            if existing == model:
                members[i] = (existing, ew + w)
                break
        else:
            members.append((model, w))
    return members


try:
    COMMITTEE_MODELS = parse_members(COMMITTEE_MODELS_RAW)
    COMMITTEE_PARSE_ERROR = None
except ValueError as exc:
    COMMITTEE_MODELS, COMMITTEE_PARSE_ERROR = [], str(exc)

# --- Prompt profiles ----------------------------------------------------

# Which reading protocol to use.
#   auto      -> a cheap triage pass classifies the image, then the matching
#                profile is used (mammography, brain CT, chest X-ray, ...)
#   off       -> always the generic prompt, never a triage pass
#   <name>    -> always that profile, no triage pass. Cheapest and most
#                predictable if you know what you're sending, e.g. mammography
PROFILE_MODE = os.environ.get("PROFILE_MODE", "auto").strip().lower()

# In auto mode the triage pass prefers an API member (seconds, ~$0.001). With a
# local-only committee it costs another image encode on CPU — set PROFILE_MODE
# to a fixed profile, or off, if that's not worth it to you.
PROFILE_TRIAGE = os.environ.get(
    "PROFILE_TRIAGE", "true").lower() in ("1", "true", "yes")

# --- DICOM --------------------------------------------------------------

# Accept .dcm uploads. Needs pydicom; without it .dcm files are refused with a
# clear message and everything else works as before.
#
# This is the feature that retires most of the bot's caveats: modality,
# projection, sequence, contrast and window stop being guesses and become read
# values. Only allowlisted TECHNICAL tags are ever extracted — patient name,
# ID, DOB, accession and institution are never read, let alone sent anywhere.
DICOM_ENABLED = os.environ.get(
    "DICOM_ENABLED", "true").lower() in ("1", "true", "yes")

# How many windows of the same slice to render. The first is the one analyzed;
# the rest are shown to you. A brain window and a bone window of one slice show
# different things, which is the whole point.
DICOM_MAX_WINDOWS = int(os.environ.get("DICOM_MAX_WINDOWS", "3"))

# Send every rendered window to the chat, not just the analyzed one.
DICOM_SEND_ALL_WINDOWS = os.environ.get(
    "DICOM_SEND_ALL_WINDOWS", "true").lower() in ("1", "true", "yes")

# Uploads can be larger than an image: DICOM carries a header and is usually
# uncompressed. The rendered PNG is what gets sent to a model, so this only
# bounds the upload itself.
MAX_DICOM_BYTES = int(os.environ.get("MAX_DICOM_BYTES", "80000000"))

# A .zip of DICOM files is read as a SERIES: slices are sorted anatomically,
# several are sampled across the stack, and all of them go to the model
# together. This is the partial answer to "everything above and below this
# slice is invisible" — not volumetric, but no longer a lone slice.
DICOM_SERIES_ENABLED = os.environ.get(
    "DICOM_SERIES_ENABLED", "true").lower() in ("1", "true", "yes")

# Slices sampled across the stack and sent to the model. Each one costs tokens
# on the API path and real CPU time locally, so this stays small.
DICOM_SERIES_SLICES = int(os.environ.get("DICOM_SERIES_SLICES", "5"))

# Guard against a zip bomb / a whole study being uploaded by accident.
DICOM_SERIES_MAX_FILES = int(os.environ.get("DICOM_SERIES_MAX_FILES", "600"))

# --- Anatomical segmentation --------------------------------------------

# Overlay named anatomy on chest radiographs using TorchXRayVision's PSPNet,
# and feed the measured positions back to the language model as grounding.
# Requires torch (CPU wheel is fine); without it the feature simply never
# activates. Only fires when the reading protocol resolves to chest_xray —
# there is no equivalent 2D model for CT/MRI screenshots.
SEGMENT_ENABLED = os.environ.get(
    "SEGMENT_ENABLED", "true").lower() in ("1", "true", "yes")
SEGMENT_ALPHA = float(os.environ.get("SEGMENT_ALPHA", "0.35"))
SEGMENT_THRESHOLD = float(os.environ.get("SEGMENT_THRESHOLD", "0.5"))
SEGMENT_MIN_AREA = float(os.environ.get("SEGMENT_MIN_AREA", "0.002"))
SEGMENT_SEND_OVERLAY = os.environ.get(
    "SEGMENT_SEND_OVERLAY", "true").lower() in ("1", "true", "yes")
# Inject measured positions into the prompt. This is the real payoff: a VLM
# cannot measure, and with this it no longer has to guess.
SEGMENT_GROUND_PROMPT = os.environ.get(
    "SEGMENT_GROUND_PROMPT", "true").lower() in ("1", "true", "yes")
# Free the weights after each use. Worth it on 8GB where Ollama needs the RAM.
SEGMENT_UNLOAD_AFTER = os.environ.get(
    "SEGMENT_UNLOAD_AFTER", "true").lower() in ("1", "true", "yes")

# --- Workup suggestions -------------------------------------------------

# "What such a finding typically prompts next". This sits downstream of the
# LEAST reliable part of the pipeline, so it is gated — see the two bars below.
WORKUP_ENABLED = os.environ.get(
    "WORKUP_ENABLED", "true").lower() in ("1", "true", "yes")

# Committee mode: a finding needs at least this share of voting weight before
# any next steps are shown for it. A finding one light member reported and
# nobody else saw should not be generating biopsy suggestions.
WORKUP_MIN_AGREEMENT = float(os.environ.get("WORKUP_MIN_AGREEMENT", "0.5"))

# Single-model mode: minimum SELF-REPORTED confidence. Weaker than the
# agreement bar, because self-reported confidence isn't calibrated — which is
# an argument for using committee mode when you care about this feature.
WORKUP_MIN_CONFIDENCE = os.environ.get("WORKUP_MIN_CONFIDENCE", "medium").lower()

# Max steps rendered per finding, to keep cards readable.
WORKUP_MAX_STEPS = int(os.environ.get("WORKUP_MAX_STEPS", "4"))

# Ask the MODEL to generate next steps as well as using the curated table.
#
# Off by default, and that is not only a cost decision. The curated table is
# keyed on (modality, category) and the model supplies the category anyway, so
# for every covered pair the model-generated steps are redundant AND less
# trustworthy — invented rather than guideline-anchored. Turning this off also
# roughly halves the response size, which on a local 4B model is the difference
# between finishing and being cut off mid-object.
#
# Turn it on to cover finding types the table doesn't have yet; those steps are
# clearly marked as unanchored on the card. Better still, add the pair to
# CURATED in workup.py.
WORKUP_ASK_MODEL = os.environ.get(
    "WORKUP_ASK_MODEL", "false").lower() in ("1", "true", "yes")

# --- Haiku (Claude API) -------------------------------------------------

HAIKU_MODEL = os.environ.get("HAIKU_MODEL", "claude-haiku-4-5-20251001")
HAIKU_MAX_TOKENS = int(os.environ.get("HAIKU_MAX_TOKENS", "1500"))

# --- Shared -------------------------------------------------------------

# Language of the reply. Section headers come from LABELS in bot.py; unknown
# languages fall back to English headers.
# NOTE: MedGemma is English-tuned and small local models are worse. In
# committee mode this also degrades finding matching, since two models phrasing
# the same finding differently in Russian won't cluster. See README "Language".
IMAGE_LANGUAGE = os.environ.get("IMAGE_LANGUAGE", "Russian")

# Longest edge, in pixels, before the image is sent to any model. The Gemma-3
# family normalizes to 896x896 internally, so a 4000px screenshot gets resized
# anyway — doing it once here saves that work on every member. 0 disables.
IMAGE_MAX_DIM = int(os.environ.get("IMAGE_MAX_DIM", "1024"))

# The Claude API rejects images over 5MB *base64*, which is ~4/3 of the raw
# bytes — so the real raw ceiling is ~3.75MB. Telegram photos are always far
# under (it re-encodes them); an uncompressed file upload might not be.
MAX_IMAGE_BYTES = int(os.environ.get("MAX_IMAGE_BYTES", "3600000"))

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()


def active_local_models(backend: str) -> list[str]:
    """Which Ollama models this backend will actually touch. Used by the
    startup vision check so it only validates what's in play."""
    if backend in ("medgemma", "both"):
        return [MEDGEMMA_MODEL]
    if backend == "committee":
        return [m for m, _ in COMMITTEE_MODELS]
    return []


def needs_anthropic(backend: str) -> bool:
    if backend in ("haiku", "both"):
        return True
    return backend == "committee" and COMMITTEE_INCLUDE_HAIKU


def validate():
    """Called from bot.py at startup so misconfiguration dies immediately with a
    readable message, rather than on the first photo hours later."""
    problems = []
    if not BOT_TOKEN:
        problems.append("TELEGRAM_BOT_TOKEN is not set (get one from @BotFather)")
    if not CHAT_ID:
        problems.append("TELEGRAM_CHAT_ID is not set (message @userinfobot to find yours)")
    if IMAGE_BACKEND not in BACKENDS:
        problems.append(
            f"IMAGE_BACKEND={IMAGE_BACKEND!r} is not one of {', '.join(BACKENDS)}")
    if COMMITTEE_PARSE_ERROR:
        problems.append(f"COMMITTEE_MODELS: {COMMITTEE_PARSE_ERROR}")
    if needs_anthropic(IMAGE_BACKEND) and not os.environ.get("ANTHROPIC_API_KEY"):
        problems.append(
            f"IMAGE_BACKEND={IMAGE_BACKEND} needs ANTHROPIC_API_KEY, which is not set")
    if IMAGE_BACKEND == "committee" and not COMMITTEE_MODELS \
            and not COMMITTEE_INCLUDE_HAIKU:
        problems.append(
            "IMAGE_BACKEND=committee but the committee is empty: set "
            "COMMITTEE_MODELS or COMMITTEE_INCLUDE_HAIKU=true")
    if COMMITTEE_REPEATS < 1:
        problems.append(f"COMMITTEE_REPEATS={COMMITTEE_REPEATS} must be at least 1")
    if not 0.0 <= COMMITTEE_MIN_AGREEMENT <= 1.0:
        problems.append(
            f"COMMITTEE_MIN_AGREEMENT={COMMITTEE_MIN_AGREEMENT} must be 0..1")
    if not 1 <= DICOM_SERIES_SLICES <= 12:
        problems.append(
            f"DICOM_SERIES_SLICES={DICOM_SERIES_SLICES} must be 1..12 "
            "(each slice is another image sent to the model)")
    if DICOM_MAX_WINDOWS < 1:
        problems.append(f"DICOM_MAX_WINDOWS={DICOM_MAX_WINDOWS} must be at least 1")
    if not 0.0 <= SEGMENT_ALPHA <= 1.0:
        problems.append(f"SEGMENT_ALPHA={SEGMENT_ALPHA} must be 0..1")
    if not 0.0 < SEGMENT_THRESHOLD < 1.0:
        problems.append(f"SEGMENT_THRESHOLD={SEGMENT_THRESHOLD} must be in (0,1)")
    if WORKUP_MIN_CONFIDENCE not in ("low", "medium", "high"):
        problems.append(
            f"WORKUP_MIN_CONFIDENCE={WORKUP_MIN_CONFIDENCE!r} must be low, "
            "medium, or high")
    if not 0.0 <= WORKUP_MIN_AGREEMENT <= 1.0:
        problems.append(
            f"WORKUP_MIN_AGREEMENT={WORKUP_MIN_AGREEMENT} must be 0..1")
    import profiles as _profiles
    if PROFILE_MODE not in ("auto", "off") and PROFILE_MODE not in _profiles.BY_NAME:
        problems.append(
            f"PROFILE_MODE={PROFILE_MODE!r} is not 'auto', 'off', or one of: "
            + ", ".join(_profiles.names()))
    if not 0.0 < COMMITTEE_MATCH_THRESHOLD <= 1.0:
        problems.append(
            f"COMMITTEE_MATCH_THRESHOLD={COMMITTEE_MATCH_THRESHOLD} must be in (0, 1]")
    if MAX_IMAGE_BYTES * 4 / 3 >= 5_000_000:
        problems.append(
            f"MAX_IMAGE_BYTES={MAX_IMAGE_BYTES} is too high: base64 inflates it past "
            "the Claude API's 5MB per-image limit. Keep it under 3_700_000.")
    return problems


def warnings():
    """Not fatal, but you probably didn't mean it."""
    out = []
    if IMAGE_BACKEND == "committee":
        n_local = len(COMMITTEE_MODELS)
        if n_local * COMMITTEE_REPEATS >= 6:
            out.append(
                f"Committee is {n_local} local model(s) x {COMMITTEE_REPEATS} "
                f"repeat(s) = {n_local * COMMITTEE_REPEATS} CPU inferences per "
                "image. Expect many minutes per photo.")
        if COMMITTEE_MODELS and not any("medgemma" in m for m, _ in COMMITTEE_MODELS):
            out.append(
                "No medgemma model in COMMITTEE_MODELS — the committee is all "
                "general-purpose models with no medical training.")
    return out

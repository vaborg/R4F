"""Scheduling and consensus for a multi-model committee.

Two jobs:

  1. SCHEDULE the runs so an 8GB CPU box survives them. The naive version —
     fire every member concurrently — is catastrophic here: N models x 3.3GB
     each thrash swap, and swap on CPU means a read that never returns.
  2. AGGREGATE the results into one weighted consensus, so agreement across
     differently-trained models becomes the confidence signal that a single
     model's self-reported "high" isn't.

The scheduling optimizations, and why each one matters:

  * MODEL-MAJOR ORDERING. All runs for one model are consecutive, so Ollama
     loads it once instead of once per run. Reloading a 3.3GB model from disk
     between runs is the single most expensive mistake available here.
  * EVICT-AFTER-LAST, but only when it helps. With two or more distinct local
     models, the last run of each passes keep_alive=0 so its RAM is freed
     before the next model loads. With exactly one local model that would be
     counterproductive — it stays warm for your next photo instead.
  * API MEMBERS RUN CONCURRENTLY. Haiku holds no local RAM and doesn't touch
     the lock, so it overlaps the local queue instead of waiting behind it.
     On a committee where local members take minutes, its card lands first.
  * ONE IMAGE PREPARATION. Downscale and base64-encode once, reuse for every
     member.
  * FAIL-SOFT. A member that errors is recorded and skipped; the committee
     still returns a consensus from whoever succeeded.
"""
import asyncio
import logging
import time
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import AsyncIterator, Optional

import analyzer
import config
from analyzer import ImageRead, Member, PreparedImage

logger = logging.getLogger(__name__)


@dataclass
class Run:
    """One scheduled inference."""
    member: Member
    index: int             # repeat number, 0-based
    total: int             # repeats for this member
    keep_alive: Optional[str] = None   # None -> use the configured default


@dataclass
class RunResult:
    run: Run
    read: Optional[ImageRead] = None
    error: Optional[str] = None
    seconds: float = 0.0

    @property
    def ok(self) -> bool:
        return self.read is not None


def plan(members: list[Member], repeats: int = 1) -> list[Run]:
    """Order the runs so each local model loads exactly once, and free its RAM
    as soon as it's done when another local model still has to load."""
    local = [m for m in members if m.is_local]
    remote = [m for m in members if not m.is_local]

    # Only worth evicting when a *different* local model needs the RAM next.
    evict = len(local) > 1

    runs: list[Run] = []
    for i, member in enumerate(local):
        last_model = (i == len(local) - 1)
        for r in range(repeats):
            last_run = (r == repeats - 1)
            # Keep the final model warm for the next photo; evict the others
            # the moment they're finished with.
            keep_alive = "0" if (evict and last_run and not last_model) else None
            runs.append(Run(member=member, index=r, total=repeats, keep_alive=keep_alive))

    for member in remote:
        for r in range(repeats):
            runs.append(Run(member=member, index=r, total=repeats))
    return runs


async def _execute(run: Run, img: PreparedImage, note: str, profile=None,
                   grounding: str = "") -> RunResult:
    """Never raises: one bad member must not sink the committee."""
    started = time.monotonic()
    try:
        read = await analyzer.analyze_member(run.member, img, note,
                                             run.keep_alive, profile, grounding)
        return RunResult(run=run, read=read, seconds=time.monotonic() - started)
    except Exception as exc:
        logger.exception("member %s run %d failed", run.member.model, run.index)
        return RunResult(run=run, error=str(exc)[:300],
                         seconds=time.monotonic() - started)


async def run_committee(members: list[Member], img: PreparedImage, note: str = "",
                        repeats: int = 1, profile=None,
                        grounding: str = "") -> AsyncIterator[RunResult]:
    """Yield results as they land.

    Local runs go through a single sequential worker (they'd contend for RAM
    and the lock anyway, and doing it explicitly keeps the model-major ordering
    intact). Remote runs are fired concurrently. Results are yielded in
    completion order, so the fast API member's card can be shown while the
    local models are still grinding.
    """
    runs = plan(members, repeats)
    local_runs = [r for r in runs if r.member.is_local]
    remote_runs = [r for r in runs if not r.member.is_local]

    queue: asyncio.Queue = asyncio.Queue()

    async def local_worker():
        # Strictly sequential, in plan order, so each model loads once.
        for run in local_runs:
            await queue.put(await _execute(run, img, note, profile, grounding))

    async def remote_worker(run: Run):
        await queue.put(await _execute(run, img, note, profile, grounding))

    tasks = []
    if local_runs:
        tasks.append(asyncio.create_task(local_worker()))
    for run in remote_runs:
        tasks.append(asyncio.create_task(remote_worker(run)))

    try:
        for _ in range(len(runs)):
            yield await queue.get()
    finally:
        # If the caller stops consuming (or the handler dies), don't leave
        # inference tasks running in the background forever.
        for t in tasks:
            if not t.done():
                t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


# --- Consensus ----------------------------------------------------------

@dataclass
class Vote:
    """A weighted opinion, with who cast it."""
    value: str
    weight: float
    voters: set = field(default_factory=set)


@dataclass
class ConsensusFinding:
    name: str
    appearance: str
    agreement: float          # share of total voting weight that saw it
    voters: list
    confidence: str           # derived from agreement, NOT self-reported
    category: str = ""        # controlled vocab, keys the workup lookup
    model_workup: tuple = ()  # what the members proposed, pre-merge


@dataclass
class Consensus:
    is_medical_image: bool
    reject_reason: Optional[str]
    attributes: list
    modality: Optional[str]
    modality_agreement: float
    anatomy: Optional[str]
    anatomy_agreement: float
    findings: list
    dropped_findings: int
    impression: Optional[str]
    caveats: list
    members_ok: int
    members_failed: int
    failures: list
    total_weight: float
    seconds: float


def _norm(text: str) -> str:
    """Normalize a finding name for matching. Deliberately light: lowercase,
    strip punctuation, and fold the en-GB/en-US spellings that would otherwise
    split a vote between two models writing the same word."""
    t = (text or "").strip().lower()
    for a, b in (("oedema", "edema"), ("tumour", "tumor"), ("haemorrhage", "hemorrhage"),
                 ("haematoma", "hematoma"), ("ischaemia", "ischemia"),
                 ("oesophag", "esophag")):
        t = t.replace(a, b)
    kept = "".join(ch if (ch.isalnum() or ch.isspace()) else " " for ch in t)
    return " ".join(kept.split())


def _similar(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def _confidence_from(agreement: float) -> str:
    if agreement >= 0.67:
        return "high"
    if agreement >= 0.34:
        return "medium"
    return "low"


def _weighted_vote(pairs) -> tuple[Optional[str], float, dict]:
    """pairs: iterable of (value, weight, voter). Returns the winner, its share
    of the total weight, and the full tally."""
    tally: dict = {}
    total = 0.0
    for value, weight, voter in pairs:
        if value is None:
            continue
        key = str(value).strip()
        if not key:
            continue
        entry = tally.setdefault(key.lower(), Vote(value=key, weight=0.0, voters=set()))
        entry.weight += weight
        entry.voters.add(voter)
        total += weight
    if not tally or total <= 0:
        return None, 0.0, tally
    winner = max(tally.values(), key=lambda v: v.weight)
    return winner.value, winner.weight / total, tally


def aggregate(results: list, threshold: Optional[float] = None,
              min_agreement: Optional[float] = None) -> Consensus:
    """Fold N member reads into one weighted consensus.

    Voting weight per *run* is the member's weight divided by its repeat count,
    so a model with weight 3 run 3 times contributes 3 in total, not 9 — the
    repeats measure that model's stability, they don't multiply its say.
    """
    if threshold is None:
        threshold = config.COMMITTEE_MATCH_THRESHOLD
    if min_agreement is None:
        min_agreement = config.COMMITTEE_MIN_AGREEMENT

    ok = [r for r in results if r.ok]
    failed = [r for r in results if not r.ok]
    seconds = max((r.seconds for r in results), default=0.0)

    if not ok:
        return Consensus(
            is_medical_image=True, reject_reason=None, attributes=[], modality=None,
            modality_agreement=0.0, anatomy=None, anatomy_agreement=0.0,
            findings=[], dropped_findings=0, impression=None, caveats=[],
            members_ok=0, members_failed=len(failed),
            failures=[(r.run.member.model, r.error) for r in failed],
            total_weight=0.0, seconds=seconds)

    def w(r):
        return r.run.member.weight / max(1, r.run.total)

    total_weight = sum(w(r) for r in ok)

    # Is it even a medical image? Majority rules, and a rejection wins ties
    # because reading a cat photo as a scan is the worse error.
    medical_weight = sum(w(r) for r in ok if r.read.is_medical_image)
    is_medical = medical_weight > total_weight / 2
    if not is_medical:
        reasons = [r.read.reject_reason for r in ok
                   if not r.read.is_medical_image and r.read.reject_reason]
        return Consensus(
            is_medical_image=False, reject_reason=reasons[0] if reasons else None,
            attributes=[], modality=None, modality_agreement=0.0, anatomy=None,
            anatomy_agreement=0.0, findings=[], dropped_findings=0,
            impression=None, caveats=[], members_ok=len(ok),
            members_failed=len(failed),
            failures=[(r.run.member.model, r.error) for r in failed],
            total_weight=total_weight, seconds=seconds)

    med = [r for r in ok if r.read.is_medical_image]

    modality, mod_agree, _ = _weighted_vote(
        (r.read.modality, w(r), r.run.member.model) for r in med)
    anatomy, ana_agree, _ = _weighted_vote(
        (r.read.anatomy, w(r), r.run.member.model) for r in med)

    # Findings: cluster by fuzzy name match, then score by the share of total
    # voting weight behind each cluster.
    clusters: list[dict] = []
    for r in med:
        for f in r.read.findings:
            key = _norm(f.name)
            if not key:
                continue
            for c in clusters:
                if _similar(key, c["key"]) >= threshold:
                    c["weight"] += w(r)
                    c["voters"].add(r.run.member.model)
                    c["variants"].append((w(r), f))
                    break
            else:
                clusters.append({"key": key, "weight": w(r),
                                 "voters": {r.run.member.model},
                                 "variants": [(w(r), f)]})

    findings, dropped = [], 0
    for c in sorted(clusters, key=lambda c: -c["weight"]):
        agreement = c["weight"] / total_weight if total_weight else 0.0
        if agreement < min_agreement:
            dropped += 1
            continue
        # Present the phrasing from the heaviest voter that reported it.
        best = max(c["variants"], key=lambda v: v[0])[1]
        # Category: majority across the members who reported this finding, so
        # one member's odd classification doesn't pick the workup table entry.
        category, _, _ = _weighted_vote(
            (f.category, w, i) for i, (w, f) in enumerate(c["variants"]))
        model_steps = []
        for _, f in sorted(c["variants"], key=lambda v: -v[0]):
            model_steps.extend(f.suggested_workup or [])
        findings.append(ConsensusFinding(
            name=best.name, appearance=best.appearance, agreement=agreement,
            voters=sorted(c["voters"]), confidence=_confidence_from(agreement),
            category=category or "", model_workup=tuple(model_steps)))

    # Impression and caveats aren't votable, so take them from the single
    # heaviest successful member rather than blending prose from several.
    lead = max(med, key=lambda r: r.run.member.weight)
    caveats, seen = [], set()
    for r in med:
        for c in r.read.caveats:
            k = _norm(c)[:60]
            if k and k not in seen:
                seen.add(k)
                caveats.append(c)

    # Attributes are profile-specific values, not votable claims — take the
    # heaviest member's set, deduplicated by label.
    attributes, seen_labels = [], set()
    for r in sorted(med, key=lambda r: -r.run.member.weight):
        for a in r.read.attributes:
            key = _norm(a.label)
            if key and key not in seen_labels:
                seen_labels.add(key)
                attributes.append(a)

    return Consensus(
        is_medical_image=True, reject_reason=None, attributes=attributes,
        modality=modality, modality_agreement=mod_agree,
        anatomy=anatomy, anatomy_agreement=ana_agree,
        findings=findings, dropped_findings=dropped,
        impression=lead.read.impression, caveats=caveats[:6],
        members_ok=len(ok), members_failed=len(failed),
        failures=[(r.run.member.model, r.error) for r in failed],
        total_weight=total_weight, seconds=seconds)

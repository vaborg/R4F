"""DICOM ingestion with clinical window presets.

This is the module that retires most of the caveats the rest of the bot has
been apologising for. From a screenshot, modality, projection, sequence,
contrast and window are all *inferred*. From a DICOM file they are *read*:

    inferred from pixels          read from the header
    --------------------          --------------------
    "probably a CT"               Modality = CT
    "cannot tell PA from AP"      ViewPosition = PA   -> CTR becomes usable
    "sequence looks like FLAIR"   SeriesDescription = FLAIR
    "unknown contrast phase"      ContrastBolusAgent present/absent
    "unknown window"              you choose the window, and can send several

The last one matters most. A brain window and a bone window of the SAME slice
show different things, and a screenshot bakes in whichever the sender happened
to use. Here the raw stored values survive, so the window is ours to pick.

PHI WARNING, and why the allowlist below exists: a DICOM file carries patient
name, ID, date of birth, accession number and institution. None of that is
needed to read an image, and shipping it to a cloud API would be a real privacy
failure. So metadata extraction is a strict ALLOWLIST of technical tags — never
a dump of everything present. Burned-in pixel annotations (common on
ultrasound) are a separate problem this cannot solve; there's a warning for it.

pydicom is optional. Without it, .dcm uploads are politely refused and
everything else works as before.
"""
import io
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# Technical tags only. Anything identifying a person or a place is deliberately
# absent, and this list is the ONLY thing that ever leaves the machine.
SAFE_TAGS = (
    ("Modality", "Modality"),
    ("BodyPartExamined", "Body part"),
    ("ViewPosition", "View position"),
    ("ImageLaterality", "Laterality"),
    ("PatientOrientation", "Orientation"),
    ("SeriesDescription", "Series"),
    ("ProtocolName", "Protocol"),
    ("ScanningSequence", "Scanning sequence"),
    ("SequenceVariant", "Sequence variant"),
    ("MRAcquisitionType", "MR acquisition"),
    ("ContrastBolusAgent", "Contrast agent"),
    ("SliceThickness", "Slice thickness (mm)"),
    ("PixelSpacing", "Pixel spacing (mm)"),
    ("KVP", "kVp"),
    ("RepetitionTime", "TR (ms)"),
    ("EchoTime", "TE (ms)"),
    ("InversionTime", "TI (ms)"),
    ("MagneticFieldStrength", "Field strength (T)"),
    ("ImageType", "Image type"),
    ("PhotometricInterpretation", "Photometric interpretation"),
)

# Tags that must never be read, listed explicitly so the intent is obvious to
# anyone editing SAFE_TAGS later.
NEVER_READ = (
    "PatientName", "PatientID", "PatientBirthDate", "PatientAddress",
    "PatientTelephoneNumbers", "OtherPatientIDs", "AccessionNumber",
    "InstitutionName", "InstitutionAddress", "ReferringPhysicianName",
    "PerformingPhysicianName", "OperatorsName", "StudyID", "StudyDate",
    "StudyTime", "SeriesDate", "AcquisitionDate", "ContentDate",
)


@dataclass(frozen=True)
class Window:
    """A window/level pair. center and width are in the image's stored units —
    Hounsfield Units once the modality LUT has been applied for CT."""
    name: str
    center: float
    width: float
    note: str = ""


# Standard CT windows. These are the conventional teaching values; individual
# departments vary a little.
CT_WINDOWS = {
    "brain": Window("Brain", 40, 80, "grey-white differentiation"),
    "subdural": Window("Subdural", 75, 215, "thin extra-axial collections"),
    "stroke": Window("Stroke", 35, 40, "early ischaemic change"),
    "bone": Window("Bone", 500, 2000, "cortex, fractures"),
    "lung": Window("Lung", -600, 1500, "parenchyma, nodules"),
    "mediastinum": Window("Mediastinum", 50, 400, "soft tissue, nodes, vessels"),
    "abdomen": Window("Abdomen", 50, 400, "solid organs"),
    "liver": Window("Liver", 60, 150, "narrow, for hepatic lesions"),
    "angio": Window("Angio", 300, 600, "opacified vessels"),
    "temporal_bone": Window("Temporal bone", 700, 4000, "fine bony detail"),
}

# Which windows to render, by body part. The first is the one analyzed.
CT_BY_REGION = {
    "head": ("brain", "subdural", "bone"),
    "brain": ("brain", "subdural", "bone"),
    "chest": ("lung", "mediastinum", "bone"),
    "thorax": ("lung", "mediastinum", "bone"),
    "abdomen": ("abdomen", "liver", "bone"),
    "pelvis": ("abdomen", "bone"),
    "spine": ("bone", "abdomen"),
}
CT_DEFAULT = ("mediastinum", "bone")

# DICOM Modality -> our reading protocol, so the triage model call is skipped
# entirely. Free, and exact rather than inferred.
MODALITY_MAP = {
    "MG": ("Mammography", "breast"),
    "CT": ("CT", None),
    "MR": ("MRI", None),
    "US": ("Ultrasound", "other"),
    "PT": ("PET", None),
    "NM": ("PET", None),
    "CR": ("X-ray", None),
    "DX": ("X-ray", None),
    "RF": ("X-ray", None),
    "XA": ("X-ray", None),
}

BODY_PART_MAP = {
    "HEAD": "head", "BRAIN": "head", "SKULL": "head",
    "CHEST": "chest", "THORAX": "chest", "LUNG": "chest",
    "ABDOMEN": "abdomen", "LIVER": "abdomen", "KIDNEY": "abdomen",
    "PELVIS": "pelvis", "BREAST": "breast",
    "SPINE": "spine", "LSPINE": "spine", "CSPINE": "spine", "TSPINE": "spine",
    "EXTREMITY": "musculoskeletal", "KNEE": "musculoskeletal",
    "SHOULDER": "musculoskeletal", "HAND": "musculoskeletal",
    "FOOT": "musculoskeletal", "HIP": "musculoskeletal",
}


@dataclass
class Rendered:
    window: Window
    png: bytes


@dataclass
class Study:
    modality: str                    # DICOM Modality code, e.g. "CT"
    metadata: list                   # [(label, value)] — allowlisted only
    renders: list = field(default_factory=list)
    region: Optional[str] = None
    frames: int = 1
    warnings: list = field(default_factory=list)
    # Series fields, populated by load_series. slice_count > 1 is what tells
    # the rest of the pipeline it is no longer looking at a lone slice.
    slice_count: int = 1
    sampled: list = field(default_factory=list)   # [(index, png)] in order
    montage: Optional[bytes] = None
    positions: Optional[tuple] = None             # (first_z, last_z) in mm

    @property
    def is_series(self) -> bool:
        return self.slice_count > 1

    @property
    def primary(self) -> Optional[Rendered]:
        return self.renders[0] if self.renders else None

    def get(self, label: str) -> Optional[str]:
        for k, v in self.metadata:
            if k == label:
                return v
        return None


def available() -> bool:
    try:
        import pydicom  # noqa: F401
        import numpy  # noqa: F401
        return True
    except ImportError:
        return False


def is_dicom(data: bytes) -> bool:
    """DICM magic at offset 128. Cheap and definitive for files with the
    standard preamble, which is what a PACS export will have."""
    return len(data) > 132 and data[128:132] == b"DICM"


# --- Pixel handling -----------------------------------------------------

def _to_stored_units(ds, arr):
    """Apply the modality LUT: for CT this converts stored values to Hounsfield
    Units, which is what makes the window presets meaningful."""
    import numpy as np
    slope = float(getattr(ds, "RescaleSlope", 1) or 1)
    intercept = float(getattr(ds, "RescaleIntercept", 0) or 0)
    out = arr.astype(np.float32)
    if slope != 1 or intercept != 0:
        out = out * slope + intercept
    return out


def _first(value, default=None):
    """WindowCenter/Width may be a MultiValue; take the first."""
    if value is None:
        return default
    try:
        if isinstance(value, (list, tuple)) or hasattr(value, "__iter__") \
                and not isinstance(value, (str, bytes)):
            seq = list(value)
            return float(seq[0]) if seq else default
        return float(value)
    except (TypeError, ValueError):
        return default


def _file_window(ds, arr) -> Window:
    """The window the file itself carries, falling back to the actual data
    range. This is what a viewer would show you by default."""
    c = _first(getattr(ds, "WindowCenter", None))
    w = _first(getattr(ds, "WindowWidth", None))
    if c is not None and w and w > 0:
        return Window("As stored", c, w, "the window recorded in the file")
    lo, hi = float(arr.min()), float(arr.max())
    return Window("Full range", (lo + hi) / 2, max(hi - lo, 1),
                  "no window in the file; showing the full data range")


def _apply(arr, window: Window, invert: bool):
    """Window/level to 8-bit."""
    import numpy as np
    lower = window.center - window.width / 2.0
    upper = window.center + window.width / 2.0
    span = max(upper - lower, 1e-6)
    out = np.clip((arr - lower) / span, 0.0, 1.0) * 255.0
    if invert:  # MONOCHROME1: low values are white
        out = 255.0 - out
    return out.astype("uint8")


def _png(arr8) -> bytes:
    from PIL import Image
    buf = io.BytesIO()
    Image.fromarray(arr8, mode="L").save(buf, format="PNG")
    return buf.getvalue()


# --- Metadata -----------------------------------------------------------

def _metadata(ds) -> list:
    out = []
    for tag, label in SAFE_TAGS:
        value = getattr(ds, tag, None)
        if value in (None, ""):
            continue
        if isinstance(value, (list, tuple)) or (
                hasattr(value, "__iter__") and not isinstance(value, (str, bytes))):
            value = ", ".join(str(v) for v in value)
        text = str(value).strip()
        if text:
            out.append((label, text[:120]))
    return out


def _region(ds) -> Optional[str]:
    part = str(getattr(ds, "BodyPartExamined", "") or "").upper().replace(" ", "")
    for key, region in BODY_PART_MAP.items():
        if key in part:
            return region
    # Fall back to the series description, which often names the region even
    # when BodyPartExamined is missing (it frequently is).
    desc = " ".join(str(getattr(ds, a, "") or "")
                    for a in ("SeriesDescription", "ProtocolName", "StudyDescription")).upper()
    for key, region in BODY_PART_MAP.items():
        if key in desc.replace(" ", ""):
            return region
    return None


def _windows_for(modality: str, region: Optional[str], ds, arr) -> list:
    """CT gets clinical presets because its values are calibrated (HU). Other
    modalities have no absolute scale, so the file's own window is all there is."""
    if modality == "CT":
        names = CT_BY_REGION.get(region or "", CT_DEFAULT)
        return [CT_WINDOWS[n] for n in names if n in CT_WINDOWS]
    return [_file_window(ds, arr)]


def load(data: bytes, max_windows: int = 3) -> Study:
    """Parse and render. Raises ValueError with a user-facing message."""
    import numpy as np
    import pydicom

    try:
        ds = pydicom.dcmread(io.BytesIO(data), force=True)
    except Exception as exc:
        raise ValueError(f"Couldn't parse this as DICOM: {exc}") from exc

    try:
        raw = ds.pixel_array
    except Exception as exc:
        # Compressed transfer syntaxes need an extra codec package. Say which,
        # rather than leaving a cryptic error.
        raise ValueError(
            "This DICOM's pixel data couldn't be decoded — it's probably a "
            "compressed transfer syntax. Install a codec:  "
            f"pip install pylibjpeg pylibjpeg-libjpeg pylibjpeg-openjpeg  ({exc})"
        ) from exc

    warnings = []
    frames = 1
    samples = int(getattr(ds, "SamplesPerPixel", 1) or 1)
    # Check colour FIRST and by shape as well as by tag: SamplesPerPixel is
    # frequently absent, and defaulting it to 1 would make an RGB Doppler frame
    # look like a 3-slice volume.
    if raw.ndim == 3 and (samples == 3 or raw.shape[-1] == 3):
        raw = raw[..., 0]
        warnings.append("Colour image: converted to greyscale for analysis.")
    elif raw.ndim == 3:
        frames = raw.shape[0]
        raw = raw[frames // 2]     # middle frame is the least arbitrary choice
        warnings.append(
            f"Multi-frame file ({frames} frames): showing the middle frame only. "
            "This is still a single slice, not the volume.")

    arr = _to_stored_units(ds, raw)
    modality = str(getattr(ds, "Modality", "") or "").upper()
    region = _region(ds)
    invert = str(getattr(ds, "PhotometricInterpretation", "")).upper() == "MONOCHROME1"

    renders = [Rendered(window=w, png=_png(_apply(arr, w, invert)))
               for w in _windows_for(modality, region, ds, arr)[:max_windows]]

    if modality == "US":
        warnings.append(
            "Ultrasound images frequently carry burned-in patient details in "
            "the pixels themselves. Header data is filtered, but anything "
            "printed into the image is not.")
    if modality == "CT" and not hasattr(ds, "RescaleIntercept"):
        warnings.append(
            "No rescale intercept in the header, so values may not be true "
            "Hounsfield Units and the window presets may be off.")

    return Study(modality=modality, metadata=_metadata(ds), renders=renders,
                 region=region, frames=frames, warnings=warnings)


# --- Outputs ------------------------------------------------------------

def profile_hint(study: Study):
    """(modality, region) for profiles.select — READ, not inferred, so the
    triage model call can be skipped entirely."""
    mapped = MODALITY_MAP.get(study.modality)
    if not mapped:
        return None, None
    modality, forced_region = mapped
    return modality, (forced_region or study.region or "unclear")


def summary_text(study: Study, language: str) -> str:
    """Header facts for the chat, in HTML."""
    ru = language == "Russian"
    head = "📄 <b>DICOM</b>" if not ru else "📄 <b>DICOM</b>"
    lines = [head]
    for label, value in study.metadata:
        lines.append(f"• {label}: <b>{value}</b>")
    if study.renders:
        wins = ", ".join(r.window.name for r in study.renders)
        label = "Окна" if ru else "Windows"
        lines.append(f"\n<b>{label}:</b> {wins}")
    for w in study.warnings:
        lines.append(f"\n<i>⚠️ {w}</i>")
    return "\n".join(lines)


def annotation(study: Study) -> str:
    """Grounding for the language model. English, factual, and explicit that
    these are read values rather than guesses — otherwise a model will hedge
    about things it has just been told."""
    if not study.metadata and not study.renders:
        return ""
    lines = [
        "This image came from a DICOM file. The following are READ FROM THE "
        "FILE HEADER, not inferred from the pixels. Treat them as fact and do "
        "not hedge about them:",
        "",
    ]
    lines += [f"- {label}: {value}" for label, value in study.metadata]

    if study.primary:
        w = study.primary.window
        lines += ["", f"The image you are looking at is windowed as "
                      f"{w.name} (level {w.center:g}, width {w.width:g})"
                      + (f" — {w.note}." if w.note else ".")]
        others = [r.window.name for r in study.renders[1:]]
        if others:
            lines.append(
                "Other windows of this same slice were rendered for the user ("
                + ", ".join(others) + ") but you are NOT seeing them. Comment "
                "only on what this window shows.")

    lines += [
        "",
        "What this changes:",
        "- Modality, projection, sequence and contrast are known. Do not "
        "describe them as uncertain, and do not list 'unknown window' or "
        "'unknown modality' as a caveat.",
        "- The window is deliberate, so the usual 'the window setting is "
        "unknown' limitation does not apply here.",
    ]

    if study.is_series:
        order = ", ".join(f"#{i}" for i, _ in study.sampled)
        lines += [
            f"- This is a SERIES of {study.slice_count} slices, not a single "
            f"image. You are being shown {len(study.sampled)} of them, spread "
            f"through the stack and given to you IN ANATOMICAL ORDER, "
            f"corresponding to slice indices {order}.",
            "- Because you can see several levels, you may comment on whether "
            "something persists across slices or appears on only one — that "
            "distinction is often what separates a real lesion from a partial "
            "volume artefact. Say which slice a finding appears on.",
            "- You still cannot see the slices BETWEEN the ones shown, and "
            "there are no priors for comparison. A small lesion can still fall "
            "entirely between sampled levels.",
        ]
        if study.positions:
            lines.append(f"- The sampled range spans z = "
                         f"{study.positions[0]:.1f} to {study.positions[1]:.1f} mm.")
    else:
        lines.append(
            "- Still a SINGLE SLICE. Everything above and below it remains "
            "invisible, and no priors are available. Those caveats do still "
            "apply.")
    if study.frames > 1:
        lines.append(f"- The file held {study.frames} frames; you are seeing "
                     "the middle one only.")
    return "\n".join(lines)


# --- Series -------------------------------------------------------------

def _sort_key(ds, fallback: int):
    """Anatomical order. ImagePositionPatient[2] is the z coordinate in patient
    space and is the only trustworthy ordering; InstanceNumber is a decent
    second, and file order is a last resort."""
    ipp = getattr(ds, "ImagePositionPatient", None)
    if ipp is not None:
        try:
            return (0, float(list(ipp)[2]))
        except (TypeError, ValueError, IndexError):
            pass
    inst = getattr(ds, "InstanceNumber", None)
    if inst is not None:
        try:
            return (1, float(inst))
        except (TypeError, ValueError):
            pass
    return (2, float(fallback))


def _evenly_spaced(n: int, k: int) -> list:
    """k indices spread across n, avoiding the very first and last slices —
    the ends of a stack are usually mostly air or table."""
    if n <= k:
        return list(range(n))
    if k == 1:
        return [n // 2]
    step = n / (k + 1)
    return [min(n - 1, int(round(step * (i + 1)))) for i in range(k)]


def _montage(items, cols: int = 4, cell: int = 160) -> bytes:
    """Contact sheet of the sampled slices, labelled with their index."""
    from PIL import Image, ImageDraw, ImageFont
    if not items:
        return b""
    try:
        font = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
    except Exception:
        font = ImageFont.load_default()

    cols = max(1, min(cols, len(items)))
    rows = (len(items) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell, rows * cell), (18, 18, 18))
    draw = ImageDraw.Draw(sheet)
    for i, (index, png) in enumerate(items):
        tile = Image.open(io.BytesIO(png)).convert("L").resize((cell, cell))
        x, y = (i % cols) * cell, (i // cols) * cell
        sheet.paste(tile, (x, y))
        draw.text((x + 5, y + 4), f"#{index}", fill=(255, 220, 90), font=font)
    buf = io.BytesIO()
    sheet.save(buf, format="PNG")
    return buf.getvalue()


def load_series(blobs: list, max_windows: int = 3, sample: int = 5) -> Study:
    """Read a stack of DICOM files as one series.

    Returns a Study whose primary render is a representative middle slice, plus
    `sampled` slices spread through the volume and a montage of them. This does
    not make the bot volumetric — it gives the language model several slices
    instead of one, which is a real but partial answer to "everything above and
    below this slice is invisible".
    """
    import numpy as np
    import pydicom

    parsed = []
    for i, blob in enumerate(blobs):
        if not is_dicom(blob):
            continue
        try:
            ds = pydicom.dcmread(io.BytesIO(blob), force=True)
            parsed.append((_sort_key(ds, i), ds))
        except Exception:
            logger.debug("skipping unreadable file %d in series", i)

    if not parsed:
        raise ValueError("No readable DICOM files found in that archive.")
    if len(parsed) == 1:
        return load(blobs[0] if is_dicom(blobs[0]) else b"", max_windows)

    parsed.sort(key=lambda p: p[0])
    datasets = [ds for _, ds in parsed]
    n = len(datasets)

    # Metadata and windowing come from the middle slice: the ends of a stack
    # are frequently scout images or mostly air.
    mid = datasets[n // 2]
    modality = str(getattr(mid, "Modality", "") or "").upper()
    region = _region(mid)
    invert = str(getattr(mid, "PhotometricInterpretation", "")).upper() == "MONOCHROME1"

    def pixels(ds):
        arr = ds.pixel_array
        if arr.ndim == 3:
            arr = arr[..., 0] if arr.shape[-1] == 3 else arr[arr.shape[0] // 2]
        return _to_stored_units(ds, arr)

    try:
        mid_arr = pixels(mid)
    except Exception as exc:
        raise ValueError(
            "Pixel data couldn't be decoded — probably a compressed transfer "
            "syntax. Install a codec:  pip install pylibjpeg pylibjpeg-libjpeg "
            f"pylibjpeg-openjpeg  ({exc})") from exc

    windows = _windows_for(modality, region, mid, mid_arr)[:max_windows]
    renders = [Rendered(window=w, png=_png(_apply(mid_arr, w, invert)))
               for w in windows]

    primary_window = windows[0]
    sampled = []
    for idx in _evenly_spaced(n, sample):
        try:
            sampled.append(
                (idx, _png(_apply(pixels(datasets[idx]), primary_window, invert))))
        except Exception:
            logger.debug("skipping slice %d during sampling", idx)

    warnings = []
    zs = [k[1] for k, _ in parsed if k[0] == 0]
    positions = (min(zs), max(zs)) if len(zs) == n else None
    if positions is None:
        warnings.append(
            "Slice positions were incomplete, so ordering fell back to instance "
            "number or file order and may not be strictly anatomical.")
    if modality == "US":
        warnings.append(
            "Ultrasound images frequently carry burned-in patient details in "
            "the pixels themselves. Header data is filtered, but anything "
            "printed into the image is not.")

    return Study(modality=modality, metadata=_metadata(mid), renders=renders,
                 region=region, frames=1, warnings=warnings,
                 slice_count=n, sampled=sampled,
                 montage=_montage(sampled), positions=positions)

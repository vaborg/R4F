"""Modality-conditioned prompt profiles.

A generalist asked "describe this scan" reads worse than one asked the
questions a radiologist would actually ask of *that* modality. Each profile
swaps in the systematic search pattern for its domain, tells the model what
domain-specific attributes to extract, and — importantly — declares hard limits
that the code enforces regardless of whether the model complies.

Two things here are deliberately NOT left to the model:

  * mandatory_caveats are appended by bot.py to every card using the profile.
    A safety statement that depends on the model remembering to emit it is not
    a safety statement.
  * no_reassurance suppresses the "nothing found" phrasing. In screening
    contexts a negative from a single compressed screenshot is the least
    trustworthy output the bot produces, and must never read as an all-clear.

Adding a profile is a dict entry — no other code changes.
"""
from dataclasses import dataclass, field

# Coarse body region, returned by the triage pass as a controlled English enum.
# Anatomy free-text can't be matched on (it may come back in Russian), so
# routing keys off this instead.
REGIONS = ("head", "chest", "breast", "abdomen", "pelvis",
           "musculoskeletal", "spine", "other", "unclear")


@dataclass(frozen=True)
class Profile:
    name: str
    label: str
    guidance: str
    # (modality, region) pairs that select this profile. "*" matches anything.
    matches: tuple = ()
    # Restated by the code on every card, whatever the model returns.
    mandatory_caveats: tuple = ()
    # Suppress "no pathology seen" phrasing — see module docstring.
    no_reassurance: bool = False
    attributes_hint: str = ""


GENERIC = Profile(
    name="generic",
    label="general",
    guidance="""Describe what is visible using standard radiological terms. \
Work from the whole image inward: overall appearance and technique first, then \
anatomy, then anything that departs from expected appearance.""",
    attributes_hint='Put "Plane" (axial/coronal/sagittal) and "Window" or '
                    '"Sequence" in attributes if they are evident.',
)


MAMMOGRAPHY = Profile(
    name="mammography",
    label="mammography (BI-RADS lexicon)",
    matches=(("Mammography", "*"), ("X-ray", "breast"), ("*", "breast")),
    guidance="""This is a mammogram. Use the BI-RADS lexicon and its \
vocabulary throughout.

Search systematically for the four finding types, and name which type you are \
describing in each finding:

1. MASS — give shape (oval / round / irregular), margin (circumscribed / \
obscured / microlobulated / indistinct / spiculated) and density relative to \
fibroglandular tissue. Margin is the single most important descriptor; \
spiculated and indistinct margins are the concerning ones.
2. CALCIFICATIONS — morphology and distribution. See the hard limits below \
before writing anything here.
3. ASYMMETRY — asymmetry, global asymmetry, focal asymmetry, or developing \
asymmetry. You cannot call anything "developing" without priors.
4. ARCHITECTURAL DISTORTION — spiculation or parenchymal retraction with no \
definite mass.

HARD LIMITS specific to mammography, which you must respect and state:

- You are looking at a compressed, downscaled screenshot. Microcalcifications \
are a few pixels across and are DESTROYED by JPEG compression and downscaling. \
You cannot assess calcifications on this input. Say so explicitly. Do NOT \
report their absence as a finding — absence of evidence here is an artifact of \
the input, not an observation.
- Do NOT assign a BI-RADS assessment category (0-6). That is a clinical act \
requiring the full examination, priors, and clinical context.
- A single view is not a mammographic examination. Screening is four views \
(bilateral CC and MLO) read together and against prior studies.
- NEVER state or imply that the mammogram is normal, negative, or reassuring. \
Screening exists to catch what looks subtle. "I see nothing" from one \
compressed view is not evidence of absence, and presenting it as reassurance \
would be the most harmful thing you could do here.""",
    attributes_hint='In attributes give "View" (CC or MLO, plus laterality if a '
                    'marker is visible) and "Density" (BI-RADS a: almost '
                    'entirely fatty / b: scattered fibroglandular / c: '
                    'heterogeneously dense / d: extremely dense). Density is the '
                    'one thing a compressed screenshot still supports reasonably '
                    'well, since it is a global texture property.',
    mandatory_caveats=(
        "Calcifications cannot be assessed on a compressed screenshot — "
        "microcalcifications are destroyed by JPEG compression and downscaling.",
        "A single view is not a screening examination (that is four views, read "
        "together and against priors).",
        "No BI-RADS assessment category is given: that requires the full exam and "
        "clinical context.",
    ),
    no_reassurance=True,
)


BRAIN_CT = Profile(
    name="brain_ct",
    label="brain CT",
    matches=(("CT", "head"),),
    guidance="""This is a CT of the head. Work through the standard review \
order and say what you find at each step:

- Grey-white differentiation: preserved or lost, and in which territory.
- Hyperdensity: acute blood? State the compartment (intra-axial, extradural, \
subdural, subarachnoid, intraventricular) and the SHAPE — lentiform versus \
crescentic distinguishes extradural from subdural.
- Hypodensity: established infarct, vasogenic oedema, or chronic small-vessel \
change.
- Mass effect: sulcal effacement, ventricular compression, midline shift (state \
which direction), basal cistern effacement.
- Ventricles: size, symmetry, hydrocephalus.
- Extra-axial spaces, and skull/scalp if included.

HARD LIMITS: the window setting decides what is visible — an unknown window can \
hide an acute bleed or manufacture one. A single axial slice excludes nothing \
above or below it. Early ischaemic change is subtle and frequently invisible on \
CT in the first hours, so a normal-looking brain CT does not exclude stroke.""",
    attributes_hint='In attributes give "Window" (brain / bone / subdural, or '
                    'unclear) and "Contrast" (with / without, or unclear).',
)


BRAIN_MRI = Profile(
    name="brain_mri",
    label="brain MRI",
    matches=(("MRI", "head"),),
    guidance="""This is an MRI of the brain.

First infer the sequence from appearance, and say that it is an inference: CSF \
bright suggests the T2 family; CSF dark suggests T1; FLAIR is T2-weighted with \
CSF suppressed; DWI is low-resolution with high lesion contrast; SWI shows \
blooming from blood products.

Then describe: signal abnormality and on which sequence it is abnormal; \
restricted diffusion if this is DWI (and note ADC is needed to confirm); \
enhancement if this appears post-contrast; mass effect; white matter lesion \
burden and distribution (periventricular / juxtacortical / infratentorial / \
deep); extra-axial collections.

HARD LIMITS: sequence inference from appearance is a guess, and signal \
intensity means nothing without knowing the sequence. A single sequence on a \
single slice cannot characterise a lesion — that needs the full multi-sequence \
study, and often pre- and post-contrast.""",
    attributes_hint='In attributes give "Sequence (inferred)" and "Plane".',
)


CHEST_XRAY = Profile(
    name="chest_xray",
    label="chest radiograph",
    matches=(("X-ray", "chest"),),
    guidance="""This is a chest radiograph. Use a systematic search and report \
in this order:

- Technical adequacy: PA or AP, rotation, degree of inspiration, penetration. \
This comes first because it changes interpretation — an AP film magnifies the \
cardiac silhouette, so do NOT call cardiomegaly on an AP film.
- Airway: trachea central or deviated, carina.
- Breathing: lung fields zone by zone, comparing left with right; pleural \
surfaces; costophrenic angles; apices.
- Circulation: heart size and contour, mediastinal width, hila.
- Diaphragm: contours, and free gas beneath it.
- Everything else: bones, soft tissues, and any lines, tubes or devices — state \
where their tips sit.

Deliberately review the commonly missed areas: apices, behind the heart, below \
the diaphragm, and the retrocardiac space.""",
    attributes_hint='In attributes give "Projection" (PA / AP / lateral) and '
                    '"Technique" (rotation, inspiration, penetration).',
)


CHEST_CT = Profile(
    name="chest_ct",
    label="chest CT",
    matches=(("CT", "chest"),),
    guidance="""This is a CT of the chest. State the window first, because the \
same slice shows entirely different things in each and you can only comment on \
what this window reveals.

Lung window: nodules (location, solid or ground-glass, margins), consolidation, \
ground-glass opacity, emphysema, bronchial wall thickening, interstitial \
pattern including reticulation and honeycombing.
Mediastinal window: lymph nodes by station if identifiable, pleural or \
pericardial fluid, great vessels, masses.

HARD LIMITS: nodule size drives management under the Fleischner criteria and \
you cannot measure reliably from a screenshot. A single slice cannot count \
nodules or establish their distribution.""",
    attributes_hint='In attributes give "Window" (lung / mediastinal / bone) and '
                    '"Contrast" if inferable.',
)


ABDOMEN_CT = Profile(
    name="abdomen_ct",
    label="abdominal CT",
    matches=(("CT", "abdomen"), ("CT", "pelvis")),
    guidance="""This is a CT of the abdomen or pelvis. Work through the organs \
systematically rather than jumping to whatever is most conspicuous: liver, \
gallbladder and biliary tree, spleen, pancreas, adrenals, kidneys and \
collecting systems, bowel (calibre, wall thickness, gas pattern), major \
vessels, then free fluid, free gas, mesentery and peritoneum, and finally the \
visible bones.

HARD LIMITS: contrast phase determines lesion appearance — a lesion invisible \
in one phase can be obvious in another, so an unknown phase limits everything \
you can say about solid organs. A single axial slice cannot follow a loop of \
bowel or trace a vessel.""",
    attributes_hint='In attributes give "Phase" (non-contrast / arterial / '
                    'portal venous / delayed, or unclear).',
)


ULTRASOUND = Profile(
    name="ultrasound",
    label="ultrasound",
    matches=(("Ultrasound", "*"),),
    guidance="""This is an ultrasound image. Describe, in this order: \
echogenicity relative to surrounding tissue (anechoic / hypoechoic / isoechoic \
/ hyperechoic), internal architecture, margins, and posterior acoustic features \
— posterior enhancement versus shadowing is what distinguishes cystic from \
solid and calcified. Note vascularity if colour Doppler is active.

HARD LIMITS: ultrasound is operator-dependent, and a still frame loses the \
real-time sweep that the diagnosis usually rests on. Gain and depth settings \
change apparent echogenicity, so echogenicity from an unknown machine setup is \
a soft observation. Do not rely on reading caliper measurements off the \
image.""",
    attributes_hint='In attributes give "Mode" (B-mode / colour Doppler / '
                    'power Doppler / M-mode) if evident.',
)


MSK_XRAY = Profile(
    name="msk_xray",
    label="skeletal radiograph",
    matches=(("X-ray", "musculoskeletal"), ("X-ray", "spine")),
    guidance="""This is a skeletal radiograph. Systematic review:

- Alignment: overall, and at each joint.
- Bone: follow every cortical margin around its full circumference looking for \
a break in continuity, a step, or a buckle. Then trabecular pattern and \
density.
- Cartilage and joints: joint space width, congruity, effusion.
- Soft tissues: swelling, fat pad elevation, gas, foreign bodies.

HARD LIMITS: a single view cannot exclude a fracture — two orthogonal views is \
the minimum standard, and undisplaced fractures are frequently invisible on the \
initial film. A normal-appearing radiograph does not exclude injury.""",
    attributes_hint='In attributes give "Projection" (AP / lateral / oblique) '
                    'and "Body part".',
    no_reassurance=True,
)


PET = Profile(
    name="pet",
    label="PET / PET-CT",
    matches=(("PET", "*"), ("PET/CT", "*")),
    guidance="""This is a PET or fused PET/CT image. Describe the distribution \
of tracer uptake: which structures are avid, whether uptake is focal or \
diffuse, and whether it corresponds to a structural abnormality on the CT \
component if one is visible. Note physiological uptake (brain, myocardium, \
liver, renal collecting system, bowel, brown fat) so it is not mistaken for \
pathology.

HARD LIMITS: real PET interpretation rests on SUV quantification, the tracer \
used, uptake time, and blood glucose — none of which are in the pixels. Without \
SUV values you cannot grade avidity, and the colour scale is arbitrary and \
window-dependent. This is the modality where a screenshot tells you least.""",
    attributes_hint='In attributes give "Tracer" only if it is labelled on the '
                    'image, and "Fusion" (PET only / fused PET-CT).',
)


ALL = (GENERIC, MAMMOGRAPHY, BRAIN_CT, BRAIN_MRI, CHEST_XRAY, CHEST_CT,
       ABDOMEN_CT, ULTRASOUND, MSK_XRAY, PET)

BY_NAME = {p.name: p for p in ALL}


def get(name: str) -> Profile:
    return BY_NAME.get((name or "").strip().lower(), GENERIC)


def names() -> list:
    return [p.name for p in ALL]


def select(modality, region) -> Profile:
    """Pick a profile from the triage pass's (modality, region).

    Exact modality+region beats a wildcard, so ("CT", "head") reaches BRAIN_CT
    rather than being caught by a broader rule.
    """
    mod = (modality or "").strip()
    reg = (region or "").strip().lower()

    best, best_score = GENERIC, 0
    for profile in ALL:
        for want_mod, want_reg in profile.matches:
            mod_ok = want_mod == "*" or want_mod.lower() == mod.lower()
            reg_ok = want_reg == "*" or want_reg.lower() == reg
            if not (mod_ok and reg_ok):
                continue
            score = (2 if want_mod != "*" else 0) + (2 if want_reg != "*" else 0)
            if score > best_score:
                best, best_score = profile, score
    return best

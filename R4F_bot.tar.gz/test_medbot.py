"""Offline tests. Shims pydantic/ollama/anthropic/telegram (none installed here,
network is off), then exercises the REAL analyzer / committee / bot code.

What this genuinely proves: call shapes for both member kinds, committee
scheduling (model-major ordering, eviction, concurrency), weighted consensus
voting, self-consistency accounting, config parsing, and rendering.

What it does NOT prove: real pydantic validation semantics, since the shim is
more permissive than the real thing. Re-run under real deps to close that gap.
"""
import asyncio
import base64
import json
import os
import sys
import types
from typing import get_args, get_origin, Literal, Union

os.environ.setdefault("TELEGRAM_BOT_TOKEN", "t")
os.environ.setdefault("TELEGRAM_CHAT_ID", "12345")
os.environ.setdefault("ANTHROPIC_API_KEY", "k")

# --- pydantic shim ------------------------------------------------------
pyd = types.ModuleType("pydantic")


class ValidationError(ValueError):
    pass


def Field(default=None, **kw):
    return default


class BaseModel:
    def __init__(self, **kw):
        ann = self._ann()
        for name in ann:
            if name in kw:
                setattr(self, name, kw[name])
            elif hasattr(type(self), name):
                v = getattr(type(self), name)
                setattr(self, name, list(v) if isinstance(v, list) else v)
            else:
                raise ValidationError(f"missing required field {name!r}")

    @classmethod
    def _ann(cls):
        out = {}
        for c in reversed(cls.__mro__):
            out.update(getattr(c, "__annotations__", {}))
        return out

    @classmethod
    def model_validate(cls, data):
        if not isinstance(data, dict):
            raise ValidationError("not an object")
        ann, kw = cls._ann(), {}
        for k, v in data.items():
            if k not in ann:
                continue
            t, args = ann[k], get_args(ann[k])
            if get_origin(t) is list and args and isinstance(args[0], type) \
                    and issubclass(args[0], BaseModel):
                v = [args[0].model_validate(i) for i in (v or [])]
            elif get_origin(t) is Union and v is not None:
                for a in args:
                    if get_origin(a) is Literal and v not in get_args(a):
                        raise ValidationError(f"{k}={v!r} not in {get_args(a)}")
            elif get_origin(t) is Literal and v not in get_args(t):
                raise ValidationError(f"{k}={v!r} not in {get_args(t)}")
            kw[k] = v
        return cls(**kw)

    @classmethod
    def model_json_schema(cls):
        return {"type": "object", "properties": {k: {} for k in cls._ann()},
                "title": cls.__name__}


pyd.BaseModel, pyd.Field, pyd.ValidationError = BaseModel, Field, ValidationError
sys.modules["pydantic"] = pyd

# --- ollama shim --------------------------------------------------------
ollama_calls, ollama_meta = [], {"models": [], "show": None, "reply": {}, "delay": {}}
load_events = []          # (model, "load"|"run") to prove model-major ordering
_loaded = {"model": None}


class FakeOllama:
    def __init__(self, **kw):
        ollama_meta["init"] = kw

    def chat(self, **kw):
        model = kw["model"]
        # Simulate Ollama's load/evict behaviour so the scheduler can be tested.
        if _loaded["model"] != model:
            load_events.append((model, "load"))
            _loaded["model"] = model
        load_events.append((model, "run"))
        ollama_calls.append(kw)
        if str(kw.get("keep_alive")) == "0":
            load_events.append((model, "evict"))
            _loaded["model"] = None
        import time
        time.sleep(ollama_meta["delay"].get(model, 0))
        if model in ollama_meta.get("raises", {}):
            raise ollama_meta["raises"][model]
        return {"message": {"content": ollama_meta["reply"].get(
            model, ollama_meta["reply"].get("*", "{}"))}}

    def list(self):
        return {"models": [{"model": m} for m in ollama_meta["models"]]}

    def show(self, model):
        s = ollama_meta["show"]
        return s(model) if callable(s) else s


fake_ollama = types.ModuleType("ollama")
fake_ollama.Client = FakeOllama
sys.modules["ollama"] = fake_ollama

# --- anthropic shim -----------------------------------------------------
api_calls, api_reply = [], {"text": "", "raises": None, "delay": 0}


class _Msgs:
    @staticmethod
    def create(**kw):
        api_calls.append(kw)
        import time
        time.sleep(api_reply["delay"])
        if api_reply.get("raises"):
            raise api_reply["raises"]
        return types.SimpleNamespace(
            content=[types.SimpleNamespace(type="text", text=api_reply["text"])])


fake_anthropic = types.ModuleType("anthropic")
fake_anthropic.Anthropic = lambda *a, **k: types.SimpleNamespace(messages=_Msgs)
sys.modules["anthropic"] = fake_anthropic

# --- pydicom shim -------------------------------------------------------
class FakeDataset:
    def __init__(self, **kw):
        self._d = kw

    def __getattr__(self, name):
        try:
            return self._d[name]
        except KeyError:
            raise AttributeError(name)

    def __contains__(self, k):
        return k in self._d


dicom_meta = {"ds": None, "raises": None}
fake_pydicom = types.ModuleType("pydicom")


def _dcmread(fp, force=False):
    if dicom_meta["raises"]:
        raise dicom_meta["raises"]
    return dicom_meta["ds"]


fake_pydicom.dcmread = _dcmread
sys.modules["pydicom"] = fake_pydicom

# --- telegram shim ------------------------------------------------------
fake_tg = types.ModuleType("telegram")


class Update:
    pass


fake_tg.Update = Update
sys.modules["telegram"] = fake_tg

consts = types.ModuleType("telegram.constants")
consts.ChatAction = types.SimpleNamespace(TYPING="typing")
consts.ParseMode = types.SimpleNamespace(HTML="HTML")
sys.modules["telegram.constants"] = consts

ext = types.ModuleType("telegram.ext")
for n in ("Application", "CommandHandler", "MessageHandler", "filters"):
    setattr(ext, n, types.SimpleNamespace())
ext.ContextTypes = types.SimpleNamespace(DEFAULT_TYPE=object)
sys.modules["telegram.ext"] = ext

import analyzer  # noqa: E402
import bot  # noqa: E402
import committee as cmt  # noqa: E402
import config  # noqa: E402
import dicom as dc  # noqa: E402
import profiles  # noqa: E402
import segment as sg  # noqa: E402
import workup as wk  # noqa: E402

# Tests written before profiles existed run with triage off, so the classifier
# pass doesn't consume their canned replies. The profile tests below enable it
# explicitly per-case.
config.PROFILE_MODE = "off"

PASS = []


def check(label, cond):
    assert cond, f"FAILED: {label}"
    PASS.append(label)
    print(f"  ok  {label}")


TRIAGE = {"reply": None}


def read_json(**over):
    base = {
        "is_medical_image": True, "reject_reason": None, "modality": "CT",
        "modality_confidence": "high", "modality_evidence": "Костная плотность.",
        "anatomy": "Головной мозг", "plane": "аксиальная", "sequence_or_phase": None,
        "findings": [{"name": "Отёк", "appearance": "Гиподенсная зона слева.",
                      "confidence": "medium"}],
        "impression": "Возможно образование с отёком.",
        "caveats": ["Один срез."],
        "attributes": [],
    }
    base.update(over)
    return json.dumps(base, ensure_ascii=False)


def _jpeg(w, h):
    from PIL import Image
    import io
    buf = io.BytesIO()
    Image.new("RGB", (w, h), (30, 30, 30)).save(buf, format="JPEG", quality=90)
    return buf.getvalue()


IMG = _jpeg(200, 150)          # small: passes through untouched
BIG_IMG = _jpeg(2400, 1800)    # large: must be downscaled once
PREP = analyzer.PreparedImage(data=IMG, media_type="image/jpeg",
                              b64=base64.b64encode(IMG).decode())


def M(model, weight=1.0, kind="ollama"):
    return analyzer.Member(kind, model, weight)


# --- telegram doubles ---------------------------------------------------

class FakeFile:
    async def download_as_bytearray(self):
        return bytearray(IMG)


class FakeBot:
    def __init__(self):
        self.actions = []

    async def get_file(self, fid):
        return FakeFile()

    async def send_chat_action(self, cid, action):
        self.actions.append(action)


class FakeMsg:
    def __init__(self, photo=None, document=None, caption=None, reply_to=None):
        self.photo, self.document, self.caption = photo or [], document, caption
        self.reply_to_message = reply_to
        self.replies, self.edits = [], []
        self.photos, self.deleted = [], 0

    async def reply_text(self, text, **kw):
        self.replies.append(text)
        return FakeMsg._Status(self)

    async def reply_photo(self, photo, caption=None, **kw):
        self.photos.append((photo, caption))
        return FakeMsg._Status(self)

    class _Status:
        def __init__(self, parent):
            self.parent = parent

        async def edit_text(self, t, **kw):
            self.parent.edits.append(t)

        async def delete(self):
            self.parent.deleted += 1


def upd(msg, chat_id="12345"):
    return types.SimpleNamespace(message=msg,
                                 effective_chat=types.SimpleNamespace(id=chat_id))


def ctx(backend="haiku"):
    return types.SimpleNamespace(bot=FakeBot(), bot_data={"backend": backend}, args=[])


PHOTO = [types.SimpleNamespace(file_id="s"), types.SimpleNamespace(file_id="big")]

print("\n[1] Config: committee parsing")
p = config.parse_members
check("model=weight parsed", p("medgemma1.5:4b=3") == [("medgemma1.5:4b", 3.0)])
check("colons in tags survive (weight uses '=')",
      p("qwen2.5vl:7b=2")[0][0] == "qwen2.5vl:7b")
check("missing weight defaults to 1", p("gemma3:4b") == [("gemma3:4b", 1.0)])
check("multiple members, order preserved",
      [m for m, _ in p("a:1=3, b:2, c:3=0.5")] == ["a:1", "b:2", "c:3"])
check("whitespace tolerated", p("  a=2 ,  b  ") == [("a", 2.0), ("b", 1.0)])
check("empty string -> empty committee", p("") == [] and p("  ,, ") == [])
check("duplicate models merged, not double-voting", p("a=1,a=2") == [("a", 3.0)])
for bad in ("a=x", "a=0", "a=-1"):
    try:
        p(bad)
        raise AssertionError(f"{bad} should have raised")
    except ValueError:
        pass
check("bad weights rejected with a clear error", True)

print("\n[2] Member expansion per backend")
config.COMMITTEE_MODELS = [("medgemma1.5:4b", 3.0), ("gemma3:4b", 1.0)]
config.COMMITTEE_INCLUDE_HAIKU = True
config.HAIKU_WEIGHT = 2.0
check("medgemma -> 1 local member",
      [(m.kind, m.model) for m in analyzer.members_for("medgemma")]
      == [("ollama", config.MEDGEMMA_MODEL)])
check("haiku -> 1 API member", analyzer.members_for("haiku")[0].kind == "haiku")
check("both -> medgemma + haiku", len(analyzer.members_for("both")) == 2)
com = analyzer.members_for("committee")
check("committee -> configured models + haiku",
      [m.model for m in com] == ["medgemma1.5:4b", "gemma3:4b", config.HAIKU_MODEL])
check("weights carried through", [m.weight for m in com] == [3.0, 1.0, 2.0])
config.COMMITTEE_INCLUDE_HAIKU = False
check("haiku excludable from the committee",
      len(analyzer.members_for("committee")) == 2)
config.COMMITTEE_INCLUDE_HAIKU = True
check("active_local_models lists only Ollama members",
      config.active_local_models("committee") == ["medgemma1.5:4b", "gemma3:4b"])
check("needs_anthropic true only when haiku votes",
      config.needs_anthropic("committee") and not config.needs_anthropic("medgemma"))

print("\n[3] Scheduling: model-major ordering + eviction")
members = [M("medgemma1.5:4b", 3), M("gemma3:4b", 1), M("haiku-x", 2, "haiku")]
runs = cmt.plan(members, repeats=3)
local_seq = [r.member.model for r in runs if r.member.is_local]
check("all runs of a model are consecutive (loads once)",
      local_seq == ["medgemma1.5:4b"] * 3 + ["gemma3:4b"] * 3)
check("API members scheduled after local in the plan",
      [r.member.model for r in runs][-3:] == ["haiku-x"] * 3)
ka = [(r.member.model, r.index, r.keep_alive) for r in runs if r.member.is_local]
check("evict only on the LAST run of a model",
      [k for _, _, k in ka] == [None, None, "0", None, None, None])
check("last local model stays warm for the next photo", ka[-1][2] is None)
single = cmt.plan([M("medgemma1.5:4b"), M("h", 1, "haiku")], repeats=2)
check("single local model is never evicted (nothing needs the RAM)",
      all(r.keep_alive is None for r in single))

print("\n[4] Scheduling actually loads each model once")
ollama_meta["reply"] = {"*": read_json()}
ollama_meta["models"] = ["a:4b", "b:4b"]
load_events.clear()
_loaded["model"] = None


async def sched():
    out = []
    async for r in cmt.run_committee([M("a:4b"), M("b:4b")], PREP, "", repeats=3):
        out.append(r)
    return out


res = asyncio.run(sched())
loads = [m for m, ev in load_events if ev == "load"]
check("6 runs across 2 models cause exactly 2 loads", loads == ["a:4b", "b:4b"])
check("all 6 runs completed", len(res) == 6 and all(r.ok for r in res))
check("evict fired between the two models",
      ("a:4b", "evict") in load_events)

print("\n[5] Concurrency: API overlaps local, local stays serialized")
ollama_meta["delay"] = {"slow:4b": 0.15}
api_reply["text"], api_reply["delay"] = read_json(), 0.0
order = []


async def overlap():
    async for r in cmt.run_committee([M("slow:4b"), M("h", 1, "haiku")], PREP):
        order.append(r.run.member.model)


asyncio.run(overlap())
check("fast API member's result arrives before the slow local one",
      order == ["h", "slow:4b"])
ollama_meta["delay"] = {}

live = {"now": 0, "max": 0}
_orig_sync = analyzer._ollama_sync


def traced(*args, **kwargs):
    live["now"] += 1
    live["max"] = max(live["max"], live["now"])
    import time
    time.sleep(0.03)
    live["now"] -= 1
    return _orig_sync(*args, **kwargs)


analyzer._ollama_sync = traced
asyncio.run(sched())
analyzer._ollama_sync = _orig_sync
check("local inferences never overlap on CPU", live["max"] == 1)

print("\n[6] Consensus: weighted voting")


def result_for(model, weight, payload, repeats=1, index=0):
    run = cmt.Run(member=M(model, weight), index=index, total=repeats)
    return cmt.RunResult(run=run, read=analyzer.parse(payload), seconds=1.0)


# 3 models: two say MRI (weight 1+1), one says CT (weight 3) -> CT wins on weight
res = [result_for("m1", 3, read_json(modality="CT")),
       result_for("m2", 1, read_json(modality="MRI")),
       result_for("m3", 1, read_json(modality="MRI"))]
con = cmt.aggregate(res)
check("weight beats headcount on modality", con.modality == "CT")
check("agreement reported as share of total weight",
      abs(con.modality_agreement - 3 / 5) < 1e-9)

res = [result_for("m1", 1, read_json(modality="CT")),
       result_for("m2", 1, read_json(modality="CT")),
       result_for("m3", 1, read_json(modality="MRI"))]
con = cmt.aggregate(res)
check("equal weights -> plain majority", con.modality == "CT"
      and abs(con.modality_agreement - 2 / 3) < 1e-9)

print("\n[7] Consensus: findings clustering + derived confidence")
F = lambda *names: [{"name": n, "appearance": f"вид {n}", "confidence": "low"}
                    for n in names]
res = [result_for("m1", 1, read_json(findings=F("Отёк", "Опухоль"))),
       result_for("m2", 1, read_json(findings=F("Отёк"))),
       result_for("m3", 1, read_json(findings=F("Отёк")))]
con = cmt.aggregate(res)
names = [f.name for f in con.findings]
check("finding seen by all 3 ranks first", names[0] == "Отёк")
check("unanimous finding -> agreement 1.0",
      abs(con.findings[0].agreement - 1.0) < 1e-9)
check("lone finding -> low agreement",
      abs(con.findings[1].agreement - 1 / 3) < 1e-9)
check("confidence DERIVED from agreement, not self-reported "
      "(members all said 'low')",
      con.findings[0].confidence == "high" and con.findings[1].confidence == "low")
check("voters recorded per finding", con.findings[0].voters == ["m1", "m2", "m3"])

res = [result_for("m1", 1, read_json(findings=F("oedema"))),
       result_for("m2", 1, read_json(findings=F("Edema")))]
con = cmt.aggregate(res)
check("en-GB/en-US spellings cluster as one finding", len(con.findings) == 1)
res = [result_for("m1", 1, read_json(findings=F("midline shift"))),
       result_for("m2", 1, read_json(findings=F("Midline  shift.")))]
con = cmt.aggregate(res)
check("punctuation/case/spacing variants cluster", len(con.findings) == 1)
res = [result_for("m1", 1, read_json(findings=F("oedema"))),
       result_for("m2", 1, read_json(findings=F("pneumothorax")))]
con = cmt.aggregate(res)
check("genuinely different findings stay separate", len(con.findings) == 2)

con = cmt.aggregate(
    [result_for("m1", 1, read_json(findings=F("Отёк"))),
     result_for("m2", 1, read_json(findings=F("Опухоль"))),
     result_for("m3", 1, read_json(findings=F("Отёк")))],
    min_agreement=0.5)
check("low-agreement findings dropped when a floor is set",
      [f.name for f in con.findings] == ["Отёк"] and con.dropped_findings == 1)

print("\n[8] Self-consistency accounting")
res = [result_for("m1", 3, read_json(findings=F("Отёк")), repeats=3, index=i)
       for i in range(3)]
res += [result_for("m2", 1, read_json(findings=F("Отёк")), repeats=3, index=i)
        for i in range(3)]
con = cmt.aggregate(res)
check("repeats split a member's weight, they don't multiply its vote",
      abs(con.total_weight - 4.0) < 1e-9)
res = [result_for("m1", 3, read_json(findings=F("Отёк")), repeats=3, index=0),
       result_for("m1", 3, read_json(findings=[]), repeats=3, index=1),
       result_for("m1", 3, read_json(findings=[]), repeats=3, index=2)]
con = cmt.aggregate(res)
check("unstable finding across repeats surfaces as low agreement",
      abs(con.findings[0].agreement - 1 / 3) < 1e-9
      and con.findings[0].confidence == "low")

print("\n[9] Fail-soft")
res = [result_for("m1", 1, read_json()),
       cmt.RunResult(run=cmt.Run(member=M("m2", 1), index=0, total=1),
                     error="ollama is down", seconds=0.5)]
con = cmt.aggregate(res)
check("one member failing still yields a consensus", con.modality == "CT")
check("failures counted and named",
      con.members_ok == 1 and con.members_failed == 1
      and con.failures[0][0] == "m2")
con = cmt.aggregate([cmt.RunResult(run=cmt.Run(member=M("m", 1), index=0, total=1),
                                   error="boom")])
check("all members failing -> empty consensus, no crash", con.members_ok == 0)
check("all-failed card explains itself",
      "boom" in bot.format_consensus_card(con, [M("m")]))

print("\n[10] Non-medical majority")
res = [result_for("m1", 1, read_json(is_medical_image=False,
                                     reject_reason="Это кот.", findings=[])),
       result_for("m2", 1, read_json(is_medical_image=False,
                                     reject_reason="Это кот.", findings=[])),
       result_for("m3", 1, read_json())]
con = cmt.aggregate(res)
check("majority rejection wins", not con.is_medical_image)
check("rejection card renders, no findings section",
      "🚫" in bot.format_consensus_card(con, res) )

print("\n[11] Image preparation")
prep = analyzer.prepare_image(IMG, "image/jpeg")
check("base64 computed once and round-trips",
      base64.b64decode(prep.b64) == prep.data)
check("small image passed through untouched",
      prep.data == IMG and prep.resized_from is None)

big = analyzer.prepare_image(BIG_IMG, "image/jpeg")
from PIL import Image as _PIL
import io as _io
check("oversized image downscaled once, before any member sees it",
      big.resized_from == (2400, 1800))
check("longest edge capped at IMAGE_MAX_DIM",
      max(_PIL.open(_io.BytesIO(big.data)).size) == config.IMAGE_MAX_DIM)
check("downscale actually shrinks the payload sent N times",
      len(big.data) < len(BIG_IMG))
check("base64 recomputed from the resized bytes, not the original",
      base64.b64decode(big.b64) == big.data)

config.IMAGE_MAX_DIM = 0
check("IMAGE_MAX_DIM=0 disables resizing",
      analyzer.prepare_image(BIG_IMG, "image/jpeg").resized_from is None)
config.IMAGE_MAX_DIM = 1024

check("corrupt image degrades gracefully instead of failing the read",
      analyzer.prepare_image(b"not-an-image", "image/jpeg").data == b"not-an-image")

print("\n[12] End-to-end through the handler")
ollama_meta["reply"] = {"medgemma1.5:4b": read_json(modality="CT"),
                        "gemma3:4b": read_json(modality="MRI")}
api_reply["text"] = read_json(modality="CT")
config.COMMITTEE_MODELS = [("medgemma1.5:4b", 3.0), ("gemma3:4b", 1.0)]
config.COMMITTEE_REPEATS = 1
config.COMMITTEE_SHOW_MEMBERS = True
m, c = FakeMsg(photo=PHOTO), ctx("committee")
asyncio.run(bot.handle_photo(upd(m), c))
allcards = m.edits + m.replies
check("3 member cards + 1 consensus card posted", len(allcards) >= 4)
consensus_card = allcards[-1]
check("consensus card is last", "CONSENSUS" in consensus_card
      or "КОМИТЕТА" in consensus_card)
check("weighted winner shown (CT: 3+2 vs MRI: 1)", "<b>CT</b>" in consensus_card)
check("agreement bar rendered", "▰" in consensus_card)
check("voters listed under a finding", "medgemma1.5:4b" in consensus_card)
print("\n--- consensus card ---")
print(consensus_card)
print("----------------------")

config.COMMITTEE_SHOW_MEMBERS = False
m, c = FakeMsg(photo=PHOTO), ctx("committee")
asyncio.run(bot.handle_photo(upd(m), c))
check("SHOW_MEMBERS=false posts only the consensus",
      len(m.edits) == 1 and len(m.replies) == 1)
config.COMMITTEE_SHOW_MEMBERS = True

m, c = FakeMsg(photo=PHOTO), ctx("haiku")
asyncio.run(bot.handle_photo(upd(m), c))
check("single-member backend posts one card, no consensus",
      len(m.edits) == 1 and "CONSENSUS" not in m.edits[0]
      and "КОМИТЕТА" not in m.edits[0])

print("\n[13] Ollama call shape (unchanged contract)")
oc = [c for c in ollama_calls if c["model"] == "medgemma1.5:4b"][-1]
check("raw bytes in images=[] (no path-guessing)",
      oc["messages"][1]["images"] == [IMG])
check("JSON schema passed as format=", isinstance(oc["format"], dict))
check("num_ctx and num_predict set from config",
      oc["options"]["num_ctx"] == config.OLLAMA_NUM_CTX
      and oc["options"]["num_predict"] == config.OLLAMA_NUM_PREDICT)
check("temperature 0.3 (stable but not frozen, so repeats mean something)",
      oc["options"]["temperature"] == 0.3)
ac = api_calls[-1]["messages"][0]["content"]
check("image block before text block for the API member",
      ac[0]["type"] == "image" and ac[1]["type"] == "text")

print("\n[14] Startup checks across every committee model")
ollama_meta["models"] = ["medgemma1.5:4b"]
ollama_meta["show"] = {"capabilities": ["completion", "vision"]}
probs = analyzer.check_models(["medgemma1.5:4b", "gemma3:4b"])
check("un-pulled committee member flagged",
      any("gemma3:4b" in p and "ollama pull" in p for p in probs))
ollama_meta["models"] = ["medgemma1.5:4b", "gemma3:4b"]
ollama_meta["show"] = {"capabilities": ["completion"]}
check("text-only member caught (the GGUF trap poisons a vote)",
      any("NO VISION" in p for p in analyzer.check_models(["gemma3:4b"])))
ollama_meta["show"] = {"projector_info": {"arch": "clip"}}
check("older Ollama (projector_info) accepted",
      analyzer.check_models(["gemma3:4b"]) == [])
ollama_meta["show"] = {}
check("unknown show() shape -> no false alarm",
      analyzer.check_models(["gemma3:4b"]) == [])

print("\n[15] Config validation")
config.IMAGE_BACKEND = "committee"
check("clean committee config passes", config.validate() == [])
config.COMMITTEE_MODELS, config.COMMITTEE_INCLUDE_HAIKU = [], False
check("empty committee caught",
      any("committee is empty" in p for p in config.validate()))
config.COMMITTEE_MODELS = [("medgemma1.5:4b", 3.0)]
config.COMMITTEE_INCLUDE_HAIKU = True
config.COMMITTEE_REPEATS = 0
check("repeats < 1 caught", any("REPEATS" in p for p in config.validate()))
config.COMMITTEE_REPEATS = 1
config.COMMITTEE_MIN_AGREEMENT = 1.5
check("min agreement out of range caught",
      any("MIN_AGREEMENT" in p for p in config.validate()))
config.COMMITTEE_MIN_AGREEMENT = 0.0
config.COMMITTEE_MODELS_RAW = "a=x"
config.COMMITTEE_PARSE_ERROR = "bad weight"
check("committee parse error surfaces at startup",
      any("COMMITTEE_MODELS" in p for p in config.validate()))
config.COMMITTEE_PARSE_ERROR = None
config.MAX_IMAGE_BYTES = 4_500_000
check("base64 5MB ceiling still enforced",
      any("5MB" in p for p in config.validate()))
config.MAX_IMAGE_BYTES = 3_600_000
config.COMMITTEE_MODELS = [("gemma3:4b", 1.0)]
check("all-general committee warns about no medical model",
      any("no medical training" in w for w in config.warnings()))
config.COMMITTEE_MODELS = [("medgemma1.5:4b", 3.0), ("a", 1), ("b", 1)]
config.COMMITTEE_REPEATS = 2
check("expensive committee warns about runtime",
      any("CPU inferences" in w for w in config.warnings()))
config.COMMITTEE_REPEATS = 1
config.IMAGE_BACKEND = "haiku"

print("\n[16] Rendering safety")
res = [result_for("m1", 1, read_json(anatomy="<script>x</script>",
                                     impression="a & b < c"))]
card = bot.format_consensus_card(cmt.aggregate(res + [result_for("m2", 1, read_json())]),
                                 [M("m1"), M("m2")])
check("HTML escaped, not injected", "&lt;script&gt;" in card and "<script>" not in card)
res = [result_for("m1", 1, read_json(impression="x" * 9000)),
       result_for("m2", 1, read_json())]
check("runaway consensus truncated under Telegram's limit",
      len(bot.format_consensus_card(cmt.aggregate(res), [M("m1"), M("m2")])) <= 4000)

print("\n[17] /backend and /committee")


async def run_cmd(fn, args, backend="haiku"):
    c = ctx(backend)
    c.args = args
    m = FakeMsg()
    await fn(upd(m), c)
    return m, c


m, c = asyncio.run(run_cmd(bot.backend_cmd, ["committee"]))
check("/backend committee switches live", c.bot_data["backend"] == "committee")
m, c = asyncio.run(run_cmd(bot.backend_cmd, ["gpt5"]))
check("unknown backend rejected, state unchanged",
      c.bot_data["backend"] == "haiku" and "Unknown backend" in m.replies[0])
config.COMMITTEE_MODELS = [("medgemma1.5:4b", 3.0), ("gemma3:4b", 1.0)]
m, _ = asyncio.run(run_cmd(bot.committee_cmd, []))
out = m.replies[0]
check("/committee lists members with weights and shares",
      "medgemma1.5:4b" in out and "weight 3" in out and "%" in out)
check("/committee shows the CPU cost per image", "CPU inferences" in out)
config.COMMITTEE_MODELS, config.COMMITTEE_INCLUDE_HAIKU = [], False
m, _ = asyncio.run(run_cmd(bot.committee_cmd, []))
check("/committee explains how to fill an empty committee",
      "COMMITTEE_MODELS" in m.replies[0])
config.COMMITTEE_MODELS = [("medgemma1.5:4b", 3.0)]
config.COMMITTEE_INCLUDE_HAIKU = True

print("\n[18] Ownership + language")
before = len(api_calls)
m = FakeMsg(photo=PHOTO)
asyncio.run(bot.handle_photo(upd(m, chat_id="99999"), ctx("haiku")))
check("stranger's photo ignored, no spend", len(api_calls) == before and not m.replies)
config.IMAGE_LANGUAGE = "Klingon"
check("unknown language -> English labels", bot.L() is bot.LABELS["English"])
config.IMAGE_LANGUAGE = "Russian"

print("\n[19] Profile selection")
sel = profiles.select
check("Mammography -> mammography profile",
      sel("Mammography", "breast").name == "mammography")
check("X-ray + breast also routes to mammography",
      sel("X-ray", "breast").name == "mammography")
check("CT + head -> brain_ct", sel("CT", "head").name == "brain_ct")
check("MRI + head -> brain_mri", sel("MRI", "head").name == "brain_mri")
check("X-ray + chest -> chest_xray", sel("X-ray", "chest").name == "chest_xray")
check("CT + chest -> chest_ct", sel("CT", "chest").name == "chest_ct")
check("CT + abdomen -> abdomen_ct", sel("CT", "abdomen").name == "abdomen_ct")
check("Ultrasound anywhere -> ultrasound",
      sel("Ultrasound", "abdomen").name == "ultrasound")
check("PET -> pet profile", sel("PET/CT", "chest").name == "pet")
check("X-ray + musculoskeletal -> msk_xray",
      sel("X-ray", "musculoskeletal").name == "msk_xray")
check("specific modality+region beats a wildcard rule",
      sel("CT", "head").name == "brain_ct")
check("unknown combination falls back to generic",
      sel("Other", "other").name == "generic")
check("empty/None inputs don't crash", sel(None, None).name == "generic")

print("\n[20] Profile content and safety guarantees")
mam = profiles.get("mammography")
check("mammography carries BI-RADS vocabulary",
      "BI-RADS" in mam.guidance and "spiculated" in mam.guidance)
check("mammography names all four finding types",
      all(t in mam.guidance for t in
          ("MASS", "CALCIFICATIONS", "ASYMMETRY", "ARCHITECTURAL DISTORTION")))
check("mammography forbids assigning a BI-RADS category",
      "Do NOT assign a BI-RADS assessment category" in mam.guidance)
check("mammography states the microcalcification limit",
      "Microcalcifications" in mam.guidance and "DESTROYED" in mam.guidance)
check("mammography asks for density in attributes",
      "Density" in mam.attributes_hint)
check("mammography is flagged no_reassurance", mam.no_reassurance)
check("mammography has code-enforced caveats", len(mam.mandatory_caveats) >= 3)
check("msk x-ray also no_reassurance (one view can't exclude a fracture)",
      profiles.get("msk_xray").no_reassurance)
check("brain_ct covers the standard review items",
      all(k in profiles.get("brain_ct").guidance for k in
          ("Grey-white", "midline shift", "Hyperdensity")))
check("chest_xray warns about AP magnification",
      "AP film" in profiles.get("chest_xray").guidance)
check("generic profile has no mandatory caveats or suppression",
      not profiles.GENERIC.mandatory_caveats
      and not profiles.GENERIC.no_reassurance)

print("\n[21] Profile reaches the model prompt")
base = analyzer.system_prompt()
mam_prompt = analyzer.system_prompt(mam)
# "BI-RADS" alone is no longer distinctive: the workup rule names it as one of
# several frameworks. Match on text unique to the mammography profile.
check("generic prompt has no mammography guidance",
      "spiculated" not in base and "ARCHITECTURAL DISTORTION" not in base)
check("mammography prompt carries its guidance",
      "spiculated" in mam_prompt and "BI-RADS lexicon" in mam_prompt)
check("schema contract identical across profiles (members stay comparable)",
      "is_medical_image" in base and "is_medical_image" in mam_prompt
      and '"findings"' in mam_prompt)
check("attributes hint substituted, no leftover placeholder",
      "{attributes_hint}" not in mam_prompt and "{profile_guidance}" not in mam_prompt
      and "Density" in mam_prompt)
check("language still applied under a profile", "Russian" in mam_prompt)
check("Mammography is now a valid modality value",
      "Mammography" in analyzer.MODALITIES)

print("\n[22] Attributes flow through")
payload = read_json(attributes=[{"label": "Density", "value": "c"},
                                {"label": "View", "value": "MLO left"}])
r = analyzer.parse(payload)
check("attributes parsed into the schema",
      [a.label for a in r.attributes] == ["Density", "View"])
card = bot.format_member_card(
    cmt.RunResult(run=cmt.Run(member=M("m"), index=0, total=1), read=r, seconds=1),
    mam)
check("attributes rendered on the card", "Density" in card and "<b>c</b>" in card)
check("profile named on the card", "mammography" in card)

con = cmt.aggregate([
    result_for("m1", 3, payload),
    result_for("m2", 1, read_json(attributes=[{"label": "Density", "value": "d"}]))])
check("consensus takes attributes from the heaviest member",
      [(a.label, a.value) for a in con.attributes] == [("Density", "c"), ("View", "MLO left")])

print("\n[23] Safety rendering: no all-clear for screening protocols")
empty = analyzer.parse(read_json(findings=[]))
res_empty = cmt.RunResult(run=cmt.Run(member=M("m"), index=0, total=1),
                          read=empty, seconds=1)
generic_card = bot.format_member_card(res_empty, profiles.GENERIC)
mam_card = bot.format_member_card(res_empty, mam)
check("generic profile may say 'no pathology seen'",
      bot.LABELS["Russian"]["no_findings"] in generic_card)
check("mammography NEVER renders as an all-clear",
      bot.LABELS["Russian"]["no_findings"] not in mam_card
      and bot.LABELS["Russian"]["no_reassurance"] in mam_card)
check("mandatory caveats emitted even though the model returned only one",
      "Calcifications cannot be assessed" in mam_card
      and "single view is not a screening examination" in mam_card)
check("model's own caveat kept alongside the mandatory ones",
      "Один срез" in mam_card)
con_empty = cmt.aggregate([result_for("m1", 1, read_json(findings=[])),
                           result_for("m2", 1, read_json(findings=[]))])
check("consensus card also refuses to reassure under mammography",
      bot.LABELS["Russian"]["no_reassurance"] in
      bot.format_consensus_card(con_empty, [M("m1"), M("m2")], mam))

print("\n[24] Triage pass")
ollama_meta["reply"]["triage:4b"] = '{"modality": "Mammography", "region": "breast"}'
t = asyncio.run(analyzer.triage(M("triage:4b"), PREP))
check("triage returns modality + region", t.modality == "Mammography"
      and t.region == "breast")
tc = [c for c in ollama_calls if c["model"] == "triage:4b"][-1]
check("triage output capped short (this is what makes it cheap)",
      tc["options"]["num_predict"] == 64)
check("triage is deterministic (temperature 0)",
      tc["options"]["temperature"] == 0.0)
check("triage uses its own tiny schema, not the full read",
      "findings" not in tc["format"]["properties"])

api_reply["text"] = '{"modality": "CT", "region": "head"}'
t = asyncio.run(analyzer.triage(M("h", 1, "haiku"), PREP))
check("triage works on the API member too", t.region == "head")

mixed = [M("local:4b"), M("h", 1, "haiku")]
check("triage prefers the API member (seconds, not another CPU encode)",
      analyzer.pick_triage_member(mixed).kind == "haiku")
check("local-only committee falls back to a local member",
      analyzer.pick_triage_member([M("a:4b"), M("b:4b")]).model == "a:4b")
check("no members -> no triage member", analyzer.pick_triage_member([]) is None)

print("\n[25] Profile resolution modes")


async def resolve(mode, members=None):
    c = ctx("haiku")
    c.bot_data["profile"] = mode
    return await bot.resolve_profile(members or [M("h", 1, "haiku")], PREP, c)


api_reply["text"] = '{"modality": "Mammography", "region": "breast"}'
prof, how = asyncio.run(resolve("auto"))
check("auto mode classifies then selects", prof.name == "mammography" and how == "auto")

before = len(api_calls)
prof, how = asyncio.run(resolve("brain_ct"))
check("forced profile used verbatim", prof.name == "brain_ct" and how == "forced")
check("forced profile skips triage entirely (no extra call)",
      len(api_calls) == before)

prof, how = asyncio.run(resolve("off"))
check("off mode -> generic, no triage",
      prof is profiles.GENERIC and how == "off")

api_reply["raises"] = RuntimeError("triage exploded")
prof, how = asyncio.run(resolve("auto"))
check("triage failure degrades to generic, never blocks the read",
      prof is profiles.GENERIC and how == "failed")
api_reply["raises"] = None

config.PROFILE_TRIAGE = False
prof, how = asyncio.run(resolve("auto"))
check("PROFILE_TRIAGE=false disables the extra call", how == "off")
config.PROFILE_TRIAGE = True

print("\n[26] Profile config + command")
config.PROFILE_MODE = "mammography"
check("valid profile name passes validation",
      not any("PROFILE_MODE" in p for p in config.validate()))
config.PROFILE_MODE = "nonsense"
check("bad PROFILE_MODE caught at startup",
      any("PROFILE_MODE" in p for p in config.validate()))
config.PROFILE_MODE = "auto"

m, c = asyncio.run(run_cmd(bot.profile_cmd, []))
check("/profile lists every protocol",
      all(n in m.replies[0] for n in ("mammography", "brain_ct", "chest_xray")))
check("/profile explains the cost of auto mode", "extra" in m.replies[0])
m, c = asyncio.run(run_cmd(bot.profile_cmd, ["mammography"]))
check("/profile mammography sets it", c.bot_data["profile"] == "mammography")
m, c = asyncio.run(run_cmd(bot.profile_cmd, ["radiology"]))
check("unknown protocol rejected", "Unknown protocol" in m.replies[0])

print("\n[27] End-to-end with a mammogram")
config.COMMITTEE_MODELS = [("medgemma1.5:4b", 3.0)]
config.COMMITTEE_INCLUDE_HAIKU = True
config.COMMITTEE_SHOW_MEMBERS = False
api_reply["text"] = '{"modality": "Mammography", "region": "breast"}'
mammo_payload = read_json(
    modality="Mammography", anatomy="Молочная железа", findings=[],
    attributes=[{"label": "View", "value": "MLO, левая"},
                {"label": "Density", "value": "c — гетерогенно плотная"}],
    caveats=["Одна проекция."])
ollama_meta["reply"]["medgemma1.5:4b"] = mammo_payload
mm = FakeMsg(photo=PHOTO)
cc = ctx("committee")
cc.bot_data["profile"] = "auto"


async def run_mammo():
    # first API call is triage, subsequent ones are the read
    calls = {"n": 0}
    real = _Msgs.create

    def staged(**kw):
        calls["n"] += 1
        api_reply["text"] = ('{"modality": "Mammography", "region": "breast"}'
                             if calls["n"] == 1 else mammo_payload)
        return real(**kw)

    _Msgs.create = staticmethod(staged)
    try:
        await bot.handle_photo(upd(mm), cc)
    finally:
        _Msgs.create = staticmethod(real)


asyncio.run(run_mammo())
final = mm.edits[-1]
check("mammography protocol auto-selected end to end",
      "mammography" in final)
check("BI-RADS density surfaced as an attribute", "Density" in final)
check("no all-clear language on the consensus card",
      bot.LABELS["Russian"]["no_reassurance"] in final)
check("code-enforced caveats present on the consensus card",
      "Calcifications cannot be assessed" in final)
print("\n--- mammography consensus card ---")
print(final)
print("----------------------------------")
config.COMMITTEE_SHOW_MEMBERS = True

print("\n[28] Workup: curated lookup")
check("CT + mass -> MRI with contrast, anchored to a guideline",
      "MRI" in wk.lookup("CT", "mass")[0].step
      and wk.lookup("CT", "mass")[0].guideline == "ACR AC")
check("CT + nodule -> Fleischner",
      any("Fleischner" in s.guideline for s in wk.lookup("CT", "nodule")))
check("Mammography + calcification -> magnification views",
      "Magnification" in wk.lookup("Mammography", "calcification")[0].step)
check("Mammography + mass -> spot compression, US, then biopsy",
      len(wk.lookup("Mammography", "mass")) == 3)
check("X-ray + fracture -> orthogonal views first",
      "Orthogonal" in wk.lookup("X-ray", "fracture")[0].step)
check("modality-specific beats wildcard (CT+mass != generic mass)",
      wk.lookup("CT", "mass") != wk.lookup("PET", "mass"))
check("wildcard fallback used for unlisted modality",
      wk.lookup("PET", "mass") == wk.CURATED[("*", "mass")])
check("unknown category -> nothing invented", wk.lookup("CT", "banana") == ())
check("empty category -> nothing", wk.lookup("CT", "") == ()
      and wk.lookup("CT", None) == ())
check("no numeric thresholds baked into curated steps",
      not any(ch.isdigit() for s in wk.CURATED[("CT", "nodule")]
              for ch in s.step))

print("\n[29] Workup: curated + model merge")
class MS:
    def __init__(s, step, rationale="r", guideline=None):
        s.step, s.rationale, s.guideline = step, rationale, guideline


steps = wk.resolve("CT", "mass", [MS("Refer to neuro-oncology MDT")])
check("curated steps come first", steps[0].source == "guideline")
check("model step appended and marked as model-sourced",
      steps[-1].source == "model" and "MDT" in steps[-1].step)
check("model duplicate of a curated step is dropped",
      len(wk.resolve("CT", "mass", [MS(wk.lookup("CT", "mass")[0].step)])) == 2)
check("step count capped", len(wk.resolve("CT", "haemorrhage",
      [MS(f"extra {i}") for i in range(9)], limit=4)) == 4)
check("unknown category still surfaces model steps",
      wk.resolve("CT", "other", [MS("Correlate clinically")])[0].source == "model")

print("\n[30] Workup gating — the safety-critical part")
def finding(name, conf, cat, agreement=None):
    if agreement is None:
        f = analyzer.Finding.model_validate(
            {"name": name, "appearance": "a", "confidence": conf,
             "category": cat, "suggested_workup": []})
        return f
    return cmt.ConsensusFinding(name=name, appearance="a", agreement=agreement,
                                voters=["m1"], confidence=conf, category=cat)


config.WORKUP_ENABLED = True
config.WORKUP_MIN_AGREEMENT = 0.5
config.WORKUP_MIN_CONFIDENCE = "medium"

e, g = bot._gather_workup([finding("Mass", "high", "mass", agreement=1.0)],
                          "CT", consensus=True)
check("unanimous finding gets next steps", len(e) == 1 and g == 0)
e, g = bot._gather_workup([finding("Mass", "low", "mass", agreement=0.25)],
                          "CT", consensus=True)
check("LOW-AGREEMENT FINDING GETS NO WORKUP (hallucination guard)",
      e == [] and g == 1)
e, _ = bot._gather_workup([finding("Mass", "high", "mass")], "CT", consensus=False)
check("single model: high confidence passes", len(e) == 1)
e, g = bot._gather_workup([finding("Mass", "low", "mass")], "CT", consensus=False)
check("single model: low confidence gated", e == [] and g == 1)
config.WORKUP_ENABLED = False
e, g = bot._gather_workup([finding("Mass", "high", "mass", agreement=1.0)],
                          "CT", consensus=True)
check("WORKUP_ENABLED=false suppresses everything", e == [] and g == 0)
config.WORKUP_ENABLED = True
check("clears_bar ranks confidence correctly",
      wk.clears_bar("high", "medium") and not wk.clears_bar("low", "medium")
      and wk.clears_bar("low", "low"))

print("\n[31] Workup rendering")
payload = read_json(modality="CT", findings=[
    {"name": "Объёмное образование", "appearance": "Гиподенсная зона.",
     "confidence": "high", "category": "mass",
     "suggested_workup": [{"step": "Обсудить на консилиуме",
                           "rationale": "нужен мультидисциплинарный подход",
                           "guideline": None}]},
    {"name": "Отёк", "appearance": "Перифокально.", "confidence": "low",
     "category": "oedema", "suggested_workup": []}])
r = analyzer.parse(payload)
check("category parsed onto findings", r.findings[0].category == "mass")
check("model workup parsed", r.findings[0].suggested_workup[0].step.startswith("Обсудить"))
card = bot.format_member_card(
    cmt.RunResult(run=cmt.Run(member=M("m"), index=0, total=1), read=r, seconds=1))
check("workup section rendered", bot.LABELS["Russian"]["workup"] in card)
check("curated CT+mass step present", "MRI" in card)
check("guideline attributed on curated steps", "ACR AC" in card)
check("model-only step flagged as unanchored",
      bot.LABELS["Russian"]["model_suggested"] in card)
check("standing 'ask your clinician' note emitted by code",
      wk.standing_note("Russian")[:30] in card)
check("low-confidence finding gated out of workup and counted",
      bot.LABELS["Russian"]["workup_gated"] in card)
check("gated finding still LISTED as a finding (gate hides steps, not findings)",
      "Отёк" in card)
print("\n--- card with workup ---")
print(card)
print("------------------------")

print("\n[32] Workup through the consensus")
both = [result_for("m1", 2, payload), result_for("m2", 2, payload)]
con = cmt.aggregate(both)
check("category survives into the consensus",
      con.findings[0].category == "mass")
check("member-proposed steps carried for merge", len(con.findings[0].model_workup) > 0)
ccard = bot.format_consensus_card(con, [M("m1"), M("m2")])
check("consensus card shows workup for the agreed finding",
      bot.LABELS["Russian"]["workup"] in ccard and "MRI" in ccard)

split = [result_for("m1", 1, read_json(modality="CT", findings=[
             {"name": "Mass", "appearance": "a", "confidence": "high",
              "category": "mass", "suggested_workup": []}])),
         result_for("m2", 3, read_json(modality="CT", findings=[]))]
con = cmt.aggregate(split)
ccard = bot.format_consensus_card(con, [M("m1"), M("m2")])
check("finding only one light member saw gets NO workup on the consensus card",
      bot.LABELS["Russian"]["workup"] not in ccard)

print("\n[33] Workup config validation")
config.WORKUP_MIN_CONFIDENCE = "certain"
check("bad WORKUP_MIN_CONFIDENCE caught",
      any("WORKUP_MIN_CONFIDENCE" in p for p in config.validate()))
config.WORKUP_MIN_CONFIDENCE = "medium"
config.WORKUP_MIN_AGREEMENT = 2.0
check("out-of-range WORKUP_MIN_AGREEMENT caught",
      any("WORKUP_MIN_AGREEMENT" in p for p in config.validate()))
config.WORKUP_MIN_AGREEMENT = 0.5
check("valid workup config passes", not any("WORKUP" in p for p in config.validate()))

print("\n[34] Prompt carries the workup contract")
p = analyzer.system_prompt()
check("category vocabulary always in the prompt (it keys the curated table)",
      "architectural_distortion" in p)
check("suggested_workup field always in the schema", "suggested_workup" in p)
# The safety framing lives in the ON-mode rule; with WORKUP_ASK_MODEL off the
# model is told not to generate steps at all, so there is nothing to constrain.
_prev_ask = config.WORKUP_ASK_MODEL
config.WORKUP_ASK_MODEL = True
p_on = analyzer.system_prompt()
check("prompt forbids patient-directed instructions",
      "NEVER as an instruction" in p_on)
check("prompt forbids invented numeric thresholds",
      "Do not invent numeric thresholds" in p_on)
check("prompt names the guideline frameworks",
      "Fleischner" in p_on and "BI-RADS" in p_on)
config.WORKUP_ASK_MODEL = _prev_ask

print("\n[35] Load-time failures the capability check can't see")
ollama_meta["models"] = ["llama3.2-vision", "gemma3:4b"]
# The real trap: manifest looks perfect — vision capability present — and the
# model still dies at load. This is what actually happened with mllama.
ollama_meta["show"] = {"capabilities": ["completion", "vision"],
                       "model_info": {"general.architecture": "mllama"}}
probs = analyzer.check_models(["llama3.2-vision"])
check("mllama caught despite reporting vision capability", len(probs) == 1)
check("message names the architecture", "mllama" in probs[0])
check("message says updating will NOT fix it",
      "Updating does not fix it" in probs[0])
check("message suggests working alternatives",
      "gemma3:4b" in probs[0] or "qwen2.5vl" in probs[0])
check("message flags the 8GB problem too", "7.8GB" in probs[0])

ollama_meta["show"] = {"capabilities": ["completion", "vision"],
                       "model_info": {"general.architecture": "gemma3"}}
check("a supported architecture passes", analyzer.check_models(["gemma3:4b"]) == [])
ollama_meta["show"] = {"capabilities": ["completion", "vision"],
                       "details": {"family": "mllama"}}
check("architecture also read from details.family (older SDK shape)",
      any("mllama" in p for p in analyzer.check_models(["llama3.2-vision"])))
ollama_meta["show"] = {"capabilities": ["completion", "vision"]}
check("no architecture info -> no false alarm",
      analyzer.check_models(["gemma3:4b"]) == [])

print("\n[36] Error hints")
h = analyzer.error_hint(
    "llama-server process has terminated: exit status 1: error loading model: "
    "unknown model architecture: 'mllama'")
check("architecture error gets a hint", h is not None)
check("hint warns against the usual 'just update' reflex",
      "will NOT fix" in h)
check("OOM error hinted",
      "RAM" in analyzer.error_hint("model requires more system memory than available"))
check("ollama down hinted",
      "isn't running" in analyzer.error_hint("dial tcp: connection refused"))
check("unpulled model hinted",
      analyzer.error_hint("model 'x' not found, try pulling it first") is not None)
check("unrelated error gets no hint", analyzer.error_hint("boom") is None)

failed = cmt.RunResult(
    run=cmt.Run(member=M("llama3.2-vision"), index=0, total=1),
    error="error loading model: unknown model architecture: 'mllama'", seconds=1)
card = bot.format_member_card(failed)
check("failure card shows the raw error", "mllama" in card)
check("failure card shows the actionable hint", "Remove this model" in card)

con = cmt.aggregate([failed])
ccard = bot.format_consensus_card(con, [M("llama3.2-vision")])
check("all-failed consensus card also carries hints", "Remove this model" in ccard)

print("\n[37] Smoke test")
ollama_meta["reply"]["gemma3:4b"] = read_json()
ollama_meta["raises"] = {}
before = len(ollama_calls)
check("smoke test passes for a working model",
      analyzer.smoke_test(["gemma3:4b"]) == [])
sc = ollama_calls[-1]
check("smoke test generates only one token", sc["options"]["num_predict"] == 1)
check("smoke test releases RAM immediately", sc["keep_alive"] == "0")
check("smoke test actually sends an image (exercises the vision path)",
      len(sc["messages"][0]["images"]) == 1)
ollama_meta["raises"] = {"bad:4b": RuntimeError(
    "error loading model: unknown model architecture: 'mllama'")}
probs = analyzer.smoke_test(["bad:4b"])
check("smoke test catches a load-time failure", len(probs) == 1)
check("smoke test result includes the hint", "Remove this model" in probs[0])
ollama_meta["raises"] = {}
check("smoke test on no models is a no-op", analyzer.smoke_test([]) == [])
check("STARTUP_SMOKE_TEST defaults off (it costs a real load per model)",
      config.STARTUP_SMOKE_TEST is False)

print("\n[38] Segmentation palette")
seen_rgb, seen_emoji = {}, {}
for name, (rgb, emoji, shape) in sg.PALETTE.items():
    assert rgb not in seen_rgb, f"{name} shares a colour with {seen_rgb.get(rgb)}"
    assert emoji not in seen_emoji, f"{name} shares an emoji"
    seen_rgb[rgb], seen_emoji[emoji] = name, name
check("all 14 structures have a unique colour", len(seen_rgb) == 14)
check("all 14 have a unique emoji marker", len(seen_emoji) == 14)
check("palette covers exactly the model's output classes",
      set(sg.PALETTE) == set(sg.STRUCTURES))
check("circle set is darkened so it can't collide with the square set on the "
      "image (emoji shape only disambiguates in text)",
      sg.PALETTE["Left Clavicle"][0] != sg.PALETTE["Heart"][0]
      and sg.PALETTE["Left Clavicle"][2] == "circle")
check("no near-black colours (invisible on a radiograph)",
      all(sum(rgb) > 120 for rgb in seen_rgb))
check("Russian names exist for every structure",
      all(n in sg.RU_NAMES for n in sg.STRUCTURES))

print("\n[39] Overlay rendering (real PIL, synthetic masks)")
import numpy as _np
from PIL import Image as _I, ImageDraw as _ID

_SZ = 256
_base = _I.new("L", (_SZ, _SZ), 40)


def _mk(box, ellipse=False):
    m = _I.new("L", (_SZ, _SZ), 0)
    d = _ID.Draw(m)
    (d.ellipse if ellipse else d.rectangle)(box, fill=255)
    return m


def _hit(name, box, ellipse=False):
    m = _mk(box, ellipse)
    st = sg._stats(_np.asarray(m) > 127, _SZ)
    c, e, sh = sg.PALETTE[name]
    return (sg.Structure(name=name, emoji=e, colour=c, area=st[0],
                         centroid=st[1], bbox=st[2], shape=sh), m)


_hits = [_hit("Right Lung", [35, 60, 120, 200], True),
         _hit("Left Lung", [136, 60, 221, 200], True),
         _hit("Heart", [100, 120, 165, 195], True),
         _hit("Spine", [121, 50, 135, 215])]
_ov = sg._render(_base, _hits, 0.35, "English", _SZ)
check("overlay is taller than the image (legend strip appended)",
      _ov.height > _SZ and _ov.width == _SZ)
check("overlay is RGB, not greyscale", _ov.mode == "RGB")
_px = _np.asarray(_ov)[:_SZ]
check("overlay actually adds colour (channels now differ)",
      not (_px[:, :, 0] == _px[:, :, 2]).all())
_hx, _hy = 130, 160   # inside heart
check("heart region tinted toward its palette colour",
      _px[_hy, _hx][0] > _px[_hy, _hx][2])
_bg = _px[10, 10]
check("background left untinted", abs(int(_bg[0]) - int(_bg[2])) <= 2)
check("empty structure list still renders a valid image",
      sg._render(_base, [], 0.35, "English", _SZ).size == (_SZ, _SZ))
check("alpha=0 leaves the image essentially unchanged except contours",
      sg._render(_base, _hits, 0.0, "English", _SZ) is not None)

print("\n[40] Derived measurement (what the VLM cannot do)")
_st = [h[0] for h in _hits]
_ctr, _notes = sg._cardiothoracic(_st)
check("CTR computed from heart and lung boxes", _ctr is not None)
check("CTR is a plausible ratio", 0.1 < _ctr < 1.0)
check("CTR carries the PA-only caveat",
      any("PA projection" in n for n in _notes))
check("CTR flagged as approximate", any("approximate" in n for n in _notes))
check("no CTR without a heart",
      sg._cardiothoracic([s for s in _st if s.name != "Heart"])[0] is None)
check("no CTR without lungs",
      sg._cardiothoracic([s for s in _st if "Lung" not in s.name])[0] is None)

print("\n[41] Legend and LLM annotation")
_res = sg.Result(overlay_png=b"x", structures=_st, missing=["Aorta", "Weasand"],
                 ctr=_ctr, notes=_notes)
_leg = sg.legend_text(_res, "Russian")
check("legend uses the exact emoji markers", "🟥" in _leg and "🔵" in _leg)
check("legend localises structure names", "Сердце" in _leg)
check("legend sorted largest-first", _leg.index("лёгкое") < _leg.index("Сердце"))
check("legend reports area share", "%" in _leg)
check("legend names structures the segmenter did NOT find", "Аорта" in _leg)
check("legend shows the CTR value", f"{_ctr:.2f}" in _leg and "КТИ" in _leg)

_ann = sg.annotation(_res)
check("annotation stays English (it's data for a model)",
      "Heart" in _ann and "Сердце" not in _ann)
check("annotation gives measured coordinates", "centroid" in _ann and "bbox" in _ann)
check("annotation tells the model to PREFER measurements over its impression",
      "Prefer them over your own impression" in _ann)
check("annotation states the segmenter finds anatomy only, not pathology",
      "does not detect pathology" in _ann)
check("annotation warns that a missing structure is ambiguous "
      "(silhouette sign vs model failure)",
      "silhouette sign" in _ann and "Do not\ntreat absence as evidence" in _ann
      or "silhouette sign" in _ann)
check("empty result yields no annotation and no legend",
      sg.annotation(sg.Result(b"", [], [])) == ""
      and sg.legend_text(sg.Result(b"", [], []), "English") == "")

print("\n[42] Grounding reaches the model prompt")
p = analyzer.user_prompt("", "SEGMENTATION DATA HERE")
check("grounding injected into the user prompt", "SEGMENTATION DATA HERE" in p)
check("grounding labelled as measured, not the model's own estimate",
      "MEASURED SEGMENTATION" in p and "not your own estimate" in p)
p2 = analyzer.user_prompt("а что слева?", "SEG")
check("grounding precedes the user's caption", p2.index("SEG") < p2.index("слева"))
check("no grounding -> prompt unchanged",
      "MEASURED" not in analyzer.user_prompt("hi"))

print("\n[43] Segmentation gating in the handler")
config.SEGMENT_ENABLED = True
_real_avail, _real_seg = sg.available, sg.segment
sg.available = lambda: True
sg.segment = lambda b, t, a, m, l: sg.Result(
    overlay_png=b"PNGBYTES", structures=_st, missing=["Aorta"], ctr=_ctr,
    notes=_notes)


async def _seg_for(profile_name):
    m = FakeMsg(photo=PHOTO)
    g = await bot.run_segmentation(upd(m), ctx("haiku"),
                                   profiles.get(profile_name), IMG)
    return m, g


m, g = asyncio.run(_seg_for("chest_xray"))
check("chest_xray triggers segmentation", g != "")
check("overlay sent as a photo", len(m.photos) == 1 and m.photos[0][0] == b"PNGBYTES")
check("legend sent as the photo caption", "🟥" in m.photos[0][1])
check("status message cleaned up after the photo lands", m.deleted == 1)

m, g = asyncio.run(_seg_for("brain_ct"))
check("NOT run on brain CT (no 2D anatomy model exists for it)",
      g == "" and not m.photos)
m, g = asyncio.run(_seg_for("generic"))
check("not run on the generic profile", g == "")

config.SEGMENT_GROUND_PROMPT = False
m, g = asyncio.run(_seg_for("chest_xray"))
check("overlay can be shown without grounding the prompt",
      g == "" and len(m.photos) == 1)
config.SEGMENT_GROUND_PROMPT = True

config.SEGMENT_SEND_OVERLAY = False
m, g = asyncio.run(_seg_for("chest_xray"))
check("grounding can be used without sending the overlay",
      g != "" and not m.photos and any("🟥" in e for e in m.edits))
config.SEGMENT_SEND_OVERLAY = True

sg.available = lambda: False
m, g = asyncio.run(_seg_for("chest_xray"))
check("torch absent -> feature silently inert, no error to the user",
      g == "" and not m.photos and not m.edits)
sg.available = lambda: True

def _boom(*a):
    raise RuntimeError("model download failed")
sg.segment = _boom
m, g = asyncio.run(_seg_for("chest_xray"))
check("segmentation failure never costs the read",
      g == "" and any(bot.LABELS["Russian"]["seg_failed"] in e for e in m.edits))

sg.segment = lambda b, t, a, m_, l: sg.Result(b"", [], list(sg.STRUCTURES))
m, g = asyncio.run(_seg_for("chest_xray"))
check("nothing segmented -> no empty overlay posted", not m.photos and g == "")

config.SEGMENT_ENABLED = False
m, g = asyncio.run(_seg_for("chest_xray"))
check("SEGMENT_ENABLED=false disables it entirely", g == "")
config.SEGMENT_ENABLED = True
sg.available, sg.segment = _real_avail, _real_seg

print("\n[44] Segmentation config validation")
config.SEGMENT_ALPHA = 1.5
check("bad SEGMENT_ALPHA caught", any("SEGMENT_ALPHA" in p for p in config.validate()))
config.SEGMENT_ALPHA = 0.35
config.SEGMENT_THRESHOLD = 0.0
check("bad SEGMENT_THRESHOLD caught",
      any("SEGMENT_THRESHOLD" in p for p in config.validate()))
config.SEGMENT_THRESHOLD = 0.5
check("valid segmentation config passes",
      not any("SEGMENT" in p for p in config.validate()))

print("\n[45] DICOM detection and windowing maths")
check("DICM magic detected", dc.is_dicom(b"\x00" * 128 + b"DICM" + b"rest"))
check("non-DICOM rejected", not dc.is_dicom(b"\x00" * 200))
check("short data rejected", not dc.is_dicom(b"DICM"))

import numpy as _np
_hu = _np.zeros((4, 400), dtype=_np.float32)
_tissues = [-1000, -700, -80, 0, 25, 40, 65, 1000]  # air..bone
for _i, _v in enumerate(_tissues):
    _hu[:, _i * 50:(_i + 1) * 50] = _v


def _px(win, idx):
    return int(dc._apply(_hu, win, False)[0, idx * 50 + 25])


_brain, _bone = dc.CT_WINDOWS["brain"], dc.CT_WINDOWS["bone"]
check("brain window separates white matter from grey matter",
      _px(_brain, 5) - _px(_brain, 4) > 30)
check("brain window makes acute blood conspicuous",
      _px(_brain, 6) > _px(_brain, 4) + 100)
check("bone window collapses soft tissue (why you can miss a bleed on it)",
      abs(_px(_bone, 6) - _px(_bone, 4)) < 10)
check("bone window still separates bone from everything else",
      _px(_bone, 7) - _px(_bone, 6) > 100)
check("lung window renders air as visible, not pure black",
      _px(dc.CT_WINDOWS["lung"], 0) > 20)
check("stroke window is the narrowest (most grey-white sensitive)",
      dc.CT_WINDOWS["stroke"].width < dc.CT_WINDOWS["brain"].width)
check("values clip, never wrap",
      dc._apply(_hu, _brain, False).min() == 0
      and dc._apply(_hu, _brain, False).max() == 255)
check("MONOCHROME1 inverts", dc._apply(_hu, _brain, True)[0, 7 * 50] == 0)

_raw = _np.array([[0, 100]], dtype=_np.int16)
check("rescale slope/intercept applied (stored values -> Hounsfield Units)",
      list(dc._to_stored_units(
          FakeDataset(RescaleSlope=1, RescaleIntercept=-1024), _raw)[0])
      == [-1024.0, -924.0])
check("no rescale tags -> values pass through unchanged",
      list(dc._to_stored_units(FakeDataset(), _raw)[0]) == [0.0, 100.0])

print("\n[46] PHI must never leave the machine")
_ds = FakeDataset(
    PatientName="IVANOV^IVAN", PatientID="12345678",
    PatientBirthDate="19700101", AccessionNumber="ACC999",
    InstitutionName="City Hospital No 3", ReferringPhysicianName="DR^WHO",
    StudyDate="20260101", OperatorsName="TECH^A",
    Modality="CT", BodyPartExamined="HEAD", SliceThickness="5.0",
    KVP="120", PhotometricInterpretation="MONOCHROME2",
    SeriesDescription="AXIAL BRAIN", RescaleIntercept=-1024, RescaleSlope=1,
    pixel_array=_hu.astype(_np.int16))
_meta = dc._metadata(_ds)
_flat = " ".join(f"{k} {v}" for k, v in _meta)
for _phi in ("IVANOV", "12345678", "19700101", "ACC999", "City Hospital",
             "DR^WHO", "20260101", "TECH"):
    assert _phi not in _flat, f"PHI LEAKED: {_phi}"
check("no patient name, ID, DOB, accession, institution, physician or date "
      "in extracted metadata", True)
check("technical tags ARE extracted", "CT" in _flat and "HEAD" in _flat
      and "AXIAL BRAIN" in _flat)
check("allowlist and never-read list do not overlap",
      not set(t for t, _ in dc.SAFE_TAGS) & set(dc.NEVER_READ))

dicom_meta["ds"], dicom_meta["raises"] = _ds, None
_study = dc.load(b"x" * 200)
_ann = dc.annotation(_study)
for _phi in ("IVANOV", "12345678", "ACC999", "City Hospital"):
    assert _phi not in _ann, f"PHI LEAKED INTO LLM PROMPT: {_phi}"
check("PHI absent from the text sent to the language model", True)
_summary = dc.summary_text(_study, "English")
check("PHI absent from the chat summary too", "IVANOV" not in _summary)

print("\n[47] Window selection and header-driven routing")
check("head CT gets brain, subdural and bone windows",
      [r.window.name for r in _study.renders] == ["Brain", "Subdural", "Bone"])
check("brain window is primary (the one analyzed)",
      _study.primary.window.name == "Brain")
check("region read from BodyPartExamined", _study.region == "head")
check("renders are real PNGs", _study.primary.png[:4] == b"\x89PNG")
check("window count capped by config",
      len(dc.load(b"x" * 200, max_windows=1).renders) == 1)

dicom_meta["ds"] = FakeDataset(Modality="CT", BodyPartExamined="CHEST",
                               pixel_array=_hu.astype(_np.int16))
check("chest CT gets lung and mediastinal windows",
      [r.window.name for r in dc.load(b"x" * 200).renders][:2]
      == ["Lung", "Mediastinum"])
dicom_meta["ds"] = FakeDataset(Modality="MR", SeriesDescription="AX FLAIR BRAIN",
                               WindowCenter=500, WindowWidth=1000,
                               pixel_array=_hu.astype(_np.int16))
_mr = dc.load(b"x" * 200)
check("MR has no HU scale, so the file's own window is used",
      _mr.renders[0].window.name == "As stored")
check("region recovered from SeriesDescription when BodyPartExamined is absent",
      _mr.region == "head")
check("WindowCenter as a list takes the first value",
      dc._first([300, 40]) == 300.0)
dicom_meta["ds"] = FakeDataset(Modality="CR", pixel_array=_hu.astype(_np.int16))
check("no window tags -> full data range fallback",
      dc.load(b"x" * 200).renders[0].window.name == "Full range")

check("MG maps to the mammography protocol",
      profiles.select(*dc.profile_hint(
          dc.Study(modality="MG", metadata=[]))).name == "mammography")
check("CT + head maps to brain_ct",
      profiles.select(*dc.profile_hint(
          dc.Study(modality="CT", metadata=[], region="head"))).name == "brain_ct")
check("CR + chest maps to chest_xray",
      profiles.select(*dc.profile_hint(
          dc.Study(modality="CR", metadata=[], region="chest"))).name == "chest_xray")
check("unknown modality -> no hint, falls back to triage",
      dc.profile_hint(dc.Study(modality="ZZ", metadata=[])) == (None, None))

print("\n[48] DICOM edge cases")
_vol = _np.stack([_hu.astype(_np.int16)] * 5)
dicom_meta["ds"] = FakeDataset(Modality="CT", BodyPartExamined="HEAD",
                               SamplesPerPixel=1, pixel_array=_vol)
_multi = dc.load(b"x" * 200)
check("multi-frame file uses the middle frame", _multi.frames == 5)
check("multi-frame warns it is still one slice, not the volume",
      any("middle frame" in w for w in _multi.warnings))
dicom_meta["ds"] = FakeDataset(Modality="US", SamplesPerPixel=3,
                               pixel_array=_np.zeros((4, 400, 3), dtype=_np.int16))
check("colour image reduced to greyscale (SamplesPerPixel present)",
      any("greyscale" in w for w in dc.load(b"x" * 200).warnings))
dicom_meta["ds"] = FakeDataset(Modality="US",
                               pixel_array=_np.zeros((4, 400, 3), dtype=_np.int16))
_us = dc.load(b"x" * 200)
check("RGB detected by shape when SamplesPerPixel is absent "
      "(otherwise a Doppler frame reads as a 3-slice volume)",
      any("greyscale" in w for w in _us.warnings) and _us.frames == 1)
check("ultrasound warns about burned-in PHI in the pixels",
      any("burned-in" in w for w in _us.warnings))


class _NoPixels(FakeDataset):
    @property
    def pixel_array(self):
        raise RuntimeError("no decoder")


dicom_meta["ds"] = _NoPixels(Modality="CT")
try:
    dc.load(b"x" * 200)
    raise AssertionError("should have raised")
except ValueError as exc:
    check("compressed transfer syntax names the codec package to install",
          "pylibjpeg" in str(exc))
dicom_meta["raises"] = RuntimeError("bad file")
try:
    dc.load(b"x" * 200)
    raise AssertionError("should have raised")
except ValueError:
    check("unparseable file raises a user-facing ValueError", True)
dicom_meta["raises"] = None

print("\n[49] DICOM grounding retires the right caveats")
dicom_meta["ds"] = _ds
_study = dc.load(b"x" * 200)
_ann = dc.annotation(_study)
check("grounding states these are read, not inferred",
      "READ FROM THE FILE HEADER" in _ann)
check("grounding tells the model to stop hedging about modality/window",
      "do not hedge" in _ann.lower()
      and "unknown window" in _ann)
check("grounding names the window actually applied", "Brain" in _ann)
check("grounding says other windows exist but are NOT visible to the model",
      "NOT seeing them" in _ann)
check("grounding KEEPS the single-slice and no-priors caveats",
      "SINGLE SLICE" in _ann and "no priors" in _ann)

print("\n[50] DICOM through the handler")
config.DICOM_ENABLED = True
_dicom_bytes = b"\x00" * 128 + b"DICM" + b"payload" * 20


class DicomDoc:
    def __init__(self, name="scan.dcm", mime="application/octet-stream", size=5000):
        self.file_name, self.mime_type, self.file_size = name, mime, size
        self.file_id = "d1"


_orig_dl = FakeFile.download_as_bytearray


async def _dl_dicom(self):
    return bytearray(_dicom_bytes)


FakeFile.download_as_bytearray = _dl_dicom
dicom_meta["ds"] = _ds
api_reply["text"] = read_json(modality="CT", anatomy="Head")
m, c = FakeMsg(document=DicomDoc()), ctx("haiku")
c.bot_data["profile"] = "auto"
before_api = len(api_calls)
asyncio.run(bot.handle_photo(upd(m), c))
check("a .dcm sent as octet-stream is accepted", len(m.photos) >= 1)
check("every window posted as its own image", len(m.photos) == 3)
check("window named in each caption", "Brain" in m.photos[0][1])
check("DICOM header summary posted", any("Modality" in e for e in m.edits))
_sent = api_calls[-1]["messages"][0]["content"][1]["text"]
check("header facts reach the model as grounding",
      "READ FROM THE FILE HEADER" in _sent)
check("TRIAGE SKIPPED — modality is read, not guessed "
      "(one model call saved per image)",
      len(api_calls) - before_api == 1)
check("protocol chosen from the header",
      any("brain_ct" in x or "brain CT" in x for x in m.edits + m.replies))

check("filename-based detection works for .dcm",
      bot._looks_like_dicom(DicomDoc(name="a.dcm", mime="text/plain")))
check("mime-based detection works", bot._looks_like_dicom(
      DicomDoc(name="x", mime="application/dicom")))
check("ordinary images not treated as DICOM",
      not bot._looks_like_dicom(DicomDoc(name="a.png", mime="image/png")))

config.DICOM_ENABLED = False
m = FakeMsg(document=DicomDoc())
asyncio.run(bot.handle_photo(upd(m), ctx("haiku")))
check("DICOM_ENABLED=false refuses politely",
      any(bot.LABELS["Russian"]["dicom_off"] in r for r in m.replies))
config.DICOM_ENABLED = True

_real_avail = dc.available
dc.available = lambda: False
m = FakeMsg(document=DicomDoc())
asyncio.run(bot.handle_photo(upd(m), ctx("haiku")))
check("missing pydicom gives an install hint, not a traceback",
      any("pydicom" in r for r in m.replies))
dc.available = _real_avail
FakeFile.download_as_bytearray = _orig_dl

print("\n[51] Series ordering and sampling")
check("evenly spaced avoids the first and last slice (usually air/table)",
      dc._evenly_spaced(60, 5) == [10, 20, 30, 40, 50])
check("fewer slices than requested -> take them all",
      dc._evenly_spaced(3, 5) == [0, 1, 2])
check("single sample takes the middle", dc._evenly_spaced(60, 1) == [30])
check("z position sorts before instance number, which sorts before file order",
      dc._sort_key(FakeDataset(ImagePositionPatient=[0, 0, -12.5]), 9)[0] == 0
      and dc._sort_key(FakeDataset(InstanceNumber=4), 9)[0] == 1
      and dc._sort_key(FakeDataset(), 9) == (2, 9.0))
check("z coordinate extracted from the third element",
      dc._sort_key(FakeDataset(ImagePositionPatient=[1, 2, -12.5]), 0)[1] == -12.5)
check("malformed position falls through to instance number",
      dc._sort_key(FakeDataset(ImagePositionPatient=["a"], InstanceNumber=7), 0)
      == (1, 7.0))

print("\n[52] Loading a series")
_slices = []
for _i in range(40):
    _a = _np.full((32, 32), _i * 10 - 200, dtype=_np.int16)
    _slices.append(FakeDataset(
        Modality="CT", BodyPartExamined="HEAD",
        ImagePositionPatient=[0, 0, float(_i) * 5],
        InstanceNumber=_i, RescaleSlope=1, RescaleIntercept=0,
        PhotometricInterpretation="MONOCHROME2", pixel_array=_a))

_by_blob = {}
_blobs = []
for _i, _ds in enumerate(_slices):
    _b = b"\x00" * 128 + b"DICM" + bytes([_i]) + b"pad" * 20
    _by_blob[_b] = _ds
    _blobs.append(_b)


def _dcmread_series(fp, force=False):
    if dicom_meta["raises"]:
        raise dicom_meta["raises"]
    data = fp.getvalue() if hasattr(fp, "getvalue") else fp.read()
    return _by_blob.get(data, dicom_meta["ds"])


fake_pydicom.dcmread = _dcmread_series
_ser = dc.load_series(_blobs, max_windows=3, sample=5)
check("series recognised", _ser.is_series and _ser.slice_count == 40)
check("5 slices sampled across the stack", len(_ser.sampled) == 5)
check("sampled indices are in anatomical order",
      [i for i, _ in _ser.sampled] == sorted(i for i, _ in _ser.sampled))
check("sampled slices span the volume, not clustered",
      _ser.sampled[-1][0] - _ser.sampled[0][0] > 20)
check("montage rendered as a PNG", _ser.montage[:4] == b"\x89PNG")
check("z range recorded", _ser.positions == (0.0, 195.0))
check("windows still chosen from body part",
      [r.window.name for r in _ser.renders] == ["Brain", "Subdural", "Bone"])
check("metadata still allowlisted for a series",
      any(k == "Modality" for k, _ in _ser.metadata))

_shuffled = list(reversed(_blobs))
check("out-of-order files are sorted by position, not upload order",
      dc.load_series(_shuffled, sample=3).positions == (0.0, 195.0))

_mixed = _blobs[:5] + [b"not a dicom at all" * 20]
check("non-DICOM entries in the archive are skipped",
      dc.load_series(_mixed, sample=3).slice_count == 5)
try:
    dc.load_series([b"junk" * 50], sample=3)
    raise AssertionError("should have raised")
except ValueError as exc:
    check("archive with no DICOMs raises a clear error", "No readable" in str(exc))

_nopos = [FakeDataset(Modality="CT", BodyPartExamined="HEAD",
                      InstanceNumber=_i, pixel_array=_np.zeros((8, 8), _np.int16))
          for _i in range(6)]
_nb = []
for _i, _ds in enumerate(_nopos):
    _b = b"\x00" * 128 + b"DICM" + b"np" + bytes([_i]) + b"x" * 30
    _by_blob[_b] = _ds
    _nb.append(_b)
_r = dc.load_series(_nb, sample=3)
check("missing slice positions warns that ordering may not be anatomical",
      any("not be strictly anatomical" in w for w in _r.warnings))

print("\n[53] Series grounding")
_ann = dc.annotation(_ser)
check("grounding states it is a series, with the count", "SERIES of 40" in _ann)
check("grounding lists which slice indices are shown", "#" in _ann)
check("grounding says the slices are in anatomical order",
      "IN ANATOMICAL ORDER" in _ann)
_flatann = " ".join(_ann.split())   # source line wrapping is not semantics
check("grounding invites cross-slice reasoning (partial volume vs real lesion)",
      "persists across slices" in _flatann and "partial volume artefact" in _flatann)
check("grounding drops the single-slice caveat for a series",
      "Still a SINGLE SLICE" not in _ann)
check("but KEEPS the between-slices and no-priors caveats",
      "slices BETWEEN the ones shown" in _flatann
      and "no priors for comparison" in _flatann)
check("z span reported", "195.0 mm" in _ann)
check("single-slice study still gets the single-slice caveat",
      "Still a SINGLE SLICE" in dc.annotation(
          dc.Study(modality="CT", metadata=[("Modality", "CT")],
                   renders=[dc.Rendered(dc.CT_WINDOWS["brain"], b"")])))

print("\n[54] Multi-image reaches both backends")
_p1 = analyzer.PreparedImage(data=b"A", media_type="image/png", b64="QQ==")
_p2 = analyzer.PreparedImage(data=b"B", media_type="image/png", b64="Qg==")
_p3 = analyzer.PreparedImage(data=b"C", media_type="image/png", b64="Qw==")
_p1.extras = [_p2, _p3]
check("all_images puts the primary first", _p1.all_images == [_p1, _p2, _p3])
check("no extras -> single image", _p2.all_images == [_p2])

api_reply["text"] = read_json()
asyncio.run(analyzer.analyze_haiku("h", _p1))
_content = api_calls[-1]["messages"][0]["content"]
check("API member receives every slice as its own image block",
      [c["type"] for c in _content] == ["image", "image", "image", "text"])
check("slice order preserved into the API call",
      [c["source"]["data"] for c in _content[:3]] == ["QQ==", "Qg==", "Qw=="])
check("text still comes after all images",
      _content[-1]["type"] == "text")

ollama_meta["reply"]["multi:4b"] = read_json()
asyncio.run(analyzer.analyze_ollama("multi:4b", _p1))
check("local member receives every slice in images=[]",
      ollama_calls[-1]["messages"][1]["images"] == [b"A", b"B", b"C"])

print("\n[55] Series through the handler")
config.DICOM_SERIES_ENABLED = True
config.DICOM_SERIES_SLICES = 5
import zipfile as _zf
_buf = io.BytesIO() if False else __import__("io").BytesIO()
with _zf.ZipFile(_buf, "w") as _z:
    for _i, _b in enumerate(_blobs):
        _z.writestr(f"IM{_i:04d}.dcm", _b)
    _z.writestr("DICOMDIR.txt", "not a dicom")
_zip_bytes = _buf.getvalue()


async def _dl_zip(self):
    return bytearray(_zip_bytes)


_orig_dl2 = FakeFile.download_as_bytearray
FakeFile.download_as_bytearray = _dl_zip


class ZipDoc:
    def __init__(self):
        self.file_name, self.mime_type = "study.zip", "application/zip"
        self.file_size, self.file_id = len(_zip_bytes), "z1"


check("zip detected", bot._looks_like_zip(ZipDoc()))
check("DICOMs extracted from the archive, junk ignored",
      len(bot._unzip_dicoms(_zip_bytes, 600)) == 40)
check("extraction respects the file cap",
      len(bot._unzip_dicoms(_zip_bytes, 7)) == 7)

api_reply["text"] = read_json(modality="CT", anatomy="Head")
m, c = FakeMsg(document=ZipDoc()), ctx("haiku")
c.bot_data["profile"] = "auto"
asyncio.run(bot.handle_photo(upd(m), c))
_all = " ".join(m.edits + m.replies)
check("series announced with slice count", "40" in _all)
check("montage posted", any(p[1] and "40" in str(p[1]) for p in m.photos))
check("windows still posted alongside", len(m.photos) >= 4)
_imgs = [c for c in api_calls[-1]["messages"][0]["content"] if c["type"] == "image"]
check("all 5 sampled slices sent to the model in one request", len(_imgs) == 5)
_txt = api_calls[-1]["messages"][0]["content"][-1]["text"]
check("series grounding reached the model", "SERIES of 40" in _txt)
check("protocol still routed from the header (no triage call)",
      "brain" in _txt.lower() or "Brain" in _txt)

config.DICOM_SERIES_ENABLED = False
m = FakeMsg(document=ZipDoc())
asyncio.run(bot.handle_photo(upd(m), ctx("haiku")))
check("DICOM_SERIES_ENABLED=false ignores zips",
      not m.photos)
config.DICOM_SERIES_ENABLED = True
FakeFile.download_as_bytearray = _orig_dl2
fake_pydicom.dcmread = _dcmread

check("DICOM_SERIES_SLICES validated",
      any("DICOM_SERIES_SLICES" in p
          for p in (setattr(config, "DICOM_SERIES_SLICES", 99),
                    config.validate())[1]))
config.DICOM_SERIES_SLICES = 5

print("\n[56] Truncated model output (the token-cap failure)")
_full = json.dumps({
    "is_medical_image": True, "modality": "CT", "modality_confidence": "high",
    "modality_evidence": "Костная плотность.", "anatomy": "Головной мозг",
    "plane": "аксиальная", "attributes": [{"label": "Window", "value": "brain"}],
    "findings": [
        {"name": "Отёк", "appearance": "Гиподенсная зона.", "confidence": "medium",
         "category": "oedema", "suggested_workup": [
             {"step": "МРТ с контрастом", "rationale": "искать причину",
              "guideline": "ACR AC"}]},
        {"name": "Смещение", "appearance": "Срединные структуры.",
         "confidence": "low", "category": "other", "suggested_workup": []}],
    "impression": "Возможно образование.", "caveats": ["Один срез."],
}, ensure_ascii=False)

_rec = _fail = 0
for _cut in range(60, len(_full) + 1):
    try:
        _d = analyzer._loads(_full[:_cut])
        assert isinstance(_d, dict) and _d.get("modality") in (None, "CT")
        _rec += 1
    except ValueError:
        _fail += 1
check(f"every truncation point from 60..{len(_full)} recovers a usable dict "
      f"({_rec} points, {_fail} failures)", _fail == 0)

_d = analyzer._loads(_full[:_full.index('"rationale"') + 20])
check("cut inside a nested workup object keeps the finished parts",
      _d["modality"] == "CT" and _d["anatomy"] == "Головной мозг"
      and len(_d["findings"]) == 1)
check("a partial read is FLAGGED, not passed off as complete",
      any("cut off" in c for c in _d["caveats"]))
_d2 = analyzer._loads(_full[:_full.index('"appearance"') + 6])
check("cut inside a key name also recovers (dangling key dropped)",
      _d2["modality"] == "CT")

check("complete JSON parses untouched, with no truncation caveat added",
      "cut off" not in " ".join(analyzer._loads(_full)["caveats"]))
check("trailing prose containing '}' no longer breaks parsing "
      "(the old rfind bug)",
      analyzer._loads(_full + "\n\nNote: see } for details.")["modality"] == "CT")
check("markdown fences still handled",
      analyzer._loads("```json\n" + _full + "\n```")["modality"] == "CT")
for _bad in ("{", "{{{{", "no json here", ""):
    try:
        analyzer._loads(_bad)
        raise AssertionError(f"{_bad!r} should not parse")
    except ValueError:
        pass
check("unrecoverable input raises cleanly, never crashes", True)
_msg = None
try:
    analyzer._loads("{" * 5)          # open braces, nothing recoverable
except ValueError as _e:
    _msg = str(_e)
check("unrecoverable truncation raises rather than returning junk", _msg is not None)
check("the error names the actual fix, not just the symptom",
      "OLLAMA_NUM_PREDICT" in _msg and "WORKUP_ASK_MODEL" in _msg)
check("the error says it was truncated, not 'malformed'",
      "truncated" in _msg and "malformed" not in _msg)

check("token cap raised well above the old 1200 that caused this",
      config.OLLAMA_NUM_PREDICT >= 2400)

print("\n[57] Output size control")
config.WORKUP_ASK_MODEL = False
_off = analyzer.system_prompt()
config.WORKUP_ASK_MODEL = True
_on = analyzer.system_prompt()
check("asking for workup is opt-in, off by default "
      "(curated table is both cheaper and better anchored)",
      os.environ.get("WORKUP_ASK_MODEL") is None)
check("with it off, the model is told to leave suggested_workup empty",
      "empty list for every" in _off)
check("with it off, the prompt explains why (budget goes to appearance)",
      "output budget" in _off)
check("with it on, the full workup instruction is present",
      "Fleischner" in _on and "at most TWO steps" in _on)
check("off-mode prompt is materially shorter", len(_off) < len(_on) - 300)
check("no placeholder left unsubstituted in either mode",
      "{workup_rule}" not in _off and "{workup_rule}" not in _on)
check("safety framing survives in the on-mode rule",
      "NEVER as an instruction to a patient" in _on)
config.WORKUP_ASK_MODEL = False

print("\n[58] /segment command")
config.SEGMENT_ENABLED = True
_ra, _rs = sg.available, sg.segment
sg.available = lambda: True
_seg_calls = []


def _fake_segment(b, t, a, m_, l):
    _seg_calls.append(b)
    return sg.Result(overlay_png=b"OVERLAY", structures=_st, missing=[],
                     ctr=_ctr, notes=[])


sg.segment = _fake_segment


async def _cmd(args, msg, c=None):
    c = c or ctx("haiku")
    c.args = args
    await bot.segment_cmd(upd(msg), c)
    return msg, c


# --- mode toggles
_m, _c = asyncio.run(_cmd(["off"], FakeMsg()))
check("/segment off disables the automatic run",
      _c.bot_data["segment_auto"] == "off")
_g = asyncio.run(bot.run_segmentation(upd(FakeMsg()), _c,
                                      profiles.get("chest_xray"), IMG))
check("auto=off really stops automatic segmentation on a chest X-ray", _g == "")
_m, _c = asyncio.run(_cmd(["auto"], FakeMsg(), _c))
check("/segment auto re-enables it", _c.bot_data["segment_auto"] == "auto")
_m, _c = asyncio.run(_cmd(["on"], FakeMsg(), _c))
check("/segment on is accepted as an alias for auto",
      _c.bot_data["segment_auto"] == "auto")

# --- no image
_c = ctx("haiku")
_m, _c = asyncio.run(_cmd([], FakeMsg(), _c))
check("bare /segment with nothing to act on says so",
      any(bot.LABELS["Russian"]["seg_no_image"] in r for r in _m.replies))

# --- reply to a photo
_seg_calls.clear()
_reply_target = FakeMsg(photo=PHOTO)
_m, _c = asyncio.run(_cmd(["force"], FakeMsg(reply_to=_reply_target), ctx("haiku")))
check("replying /segment to a photo segments THAT photo",
      len(_seg_calls) == 1 and _seg_calls[0] == IMG)
check("overlay posted from the command", _m.photos and _m.photos[0][0] == b"OVERLAY")

_reply_doc = FakeMsg(document=types.SimpleNamespace(
    mime_type="image/png", file_size=100, file_id="p1"))
_seg_calls.clear()
_m, _c = asyncio.run(_cmd(["force"], FakeMsg(reply_to=_reply_doc), ctx("haiku")))
check("replying to an image document also works", len(_seg_calls) == 1)

_reply_bad = FakeMsg(document=types.SimpleNamespace(
    mime_type="application/pdf", file_size=100, file_id="p2"))
_seg_calls.clear()
_m, _c = asyncio.run(_cmd([], FakeMsg(reply_to=_reply_bad), ctx("haiku")))
check("replying to a non-image falls through to 'nothing to segment'",
      not _seg_calls
      and any(bot.LABELS["Russian"]["seg_no_image"] in r for r in _m.replies))

# --- cached last image
_c = ctx("haiku")
bot._remember_image(_c, "12345", b"CACHED", "chest_xray")
_seg_calls.clear()
_before_api = len(api_calls)
_m, _c = asyncio.run(_cmd([], FakeMsg(), _c))
check("bare /segment uses the last image sent to the chat",
      _seg_calls == [b"CACHED"])
check("cached protocol reused, so no triage call is spent re-classifying",
      len(api_calls) == _before_api)
bot._remember_image(_c, "12345", b"NEWER", "chest_xray")
check("only the most recent image is kept",
      _c.bot_data["last_image"]["12345"]["bytes"] == b"NEWER")

# --- out-of-domain guard
_c = ctx("haiku")
bot._remember_image(_c, "12345", b"BRAIN", "brain_ct")
_seg_calls.clear()
_m, _c = asyncio.run(_cmd([], FakeMsg(), _c))
check("NON-CHEST IMAGE REFUSED by default (PSPNet would invent lungs)",
      not _seg_calls)
check("refusal names what the image looks like and how to override",
      any("brain CT" in r and "/segment force" in r for r in _m.replies))

_seg_calls.clear()
_m, _c = asyncio.run(_cmd(["force"], FakeMsg(), _c))
check("/segment force overrides the domain check", len(_seg_calls) == 1)
_caption = _m.photos[-1][1]
check("forced out-of-domain result carries a loud banner",
      "OUT OF DOMAIN" in _caption or "ВНЕ ОБЛАСТИ" in _caption)
check("banner appears ABOVE the structure list, not buried under it",
      _caption.index("ВНЕ ОБЛАСТИ") < _caption.index("Сердце"))
check("banner states the labels are artefacts, not anatomy",
      "артефакты" in _caption or "artefacts" in _caption)
check("banner states they are NOT sent to the language model",
      "не передаются" in _caption or "NOT sent" in _caption)

bot._remember_image(_c, "12345", b"CXR", "chest_xray")
_m, _c = asyncio.run(_cmd(["force"], FakeMsg(), _c))
check("force on an in-domain image adds NO scary banner",
      "ВНЕ ОБЛАСТИ" not in _m.photos[-1][1])

# --- torch missing
sg.available = lambda: False
_m, _c = asyncio.run(_cmd([], FakeMsg(), _c))
check("without torch the command gives install instructions",
      any("torchxrayvision" in r for r in _m.replies))
sg.available = lambda: True

# --- ownership
_seg_calls.clear()
_c = ctx("haiku")
_c.args = []
_m = FakeMsg()
asyncio.run(bot.segment_cmd(upd(_m, chat_id="99999"), _c))
check("stranger's /segment ignored", not _m.replies and not _seg_calls)

# --- handle_photo populates the cache
sg.segment = _rs
sg.available = lambda: False
api_reply["text"] = read_json()
_c = ctx("haiku")
_c.bot_data["profile"] = "off"
_m = FakeMsg(photo=PHOTO)
asyncio.run(bot.handle_photo(upd(_m), _c))
check("analyzing a photo caches it for a later bare /segment",
      _c.bot_data["last_image"]["12345"]["bytes"] == IMG)
check("cached entry records the protocol that was used",
      _c.bot_data["last_image"]["12345"]["profile"] == "generic")
sg.available, sg.segment = _ra, _rs

print(f"\n{'=' * 62}\nALL {len(PASS)} CHECKS PASSED\n{'=' * 62}")
